#!/usr/bin/python
##################################################################################################
#       Name    : RUN ID Generation script. 
#       Desc	: This Script generate custome runid and insert the details into hive table.
#       Date    : 30-05-2016
#       Author  : Mithun Kankal
#       Version : 1.0
##################################################################################################

import impala.dbapi
import pyhs2
import sys
import datetime
import traceback
import time;
import subprocess;
import MySQLdb;

#----------------------------------:: Global Varibale Declration ::----------------------------------------------------------
auth_Mech        = "KERBEROS"
hiveConfigDb     = 'socio_config_db'
hiveUserName     = ""
hivePassCode     = ""
(LocalMysqlHostAddress, LocalMysqlUser, LocalMysqlPass) = ('','','')

#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def getKerberosTicket():
        kinit_command = "/usr/bin/kinit "+hiveUserName;
        #print kinit_command;
        kinit = subprocess.Popen( kinit_command , shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);
        kinit.stdin.write(hivePassCode+"\n" );
        kinit.wait();
#----------------------------------------------------------------------------------------------------------------------------------

def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    mysqlConfigDb = 'socio_config_db';
    mysqlTableName1 = 'common_run_id_tracker';
    mysqlTableName2 = 'process_details';

    try: 
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);
        
        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]
        
        if mysqlTableName1 not in mysqlConfigTables :
            statement=("CREATE TABLE IF NOT EXISTS socio_config_db.common_run_id_tracker (run_id text, start_time timestamp null, end_time timestamp null, job_status text)")
            cur.execute(statement);
        
        if mysqlTableName2 not in mysqlConfigTables :
            statement4=("CREATE TABLE IF NOT EXISTS socio_config_db.process_details(wf_id text, inboxfilenamewithext text, action_name text, date_time timestamp, error_code text, error_type text, error_message text,  file_checksum text, process_status text)");
            cur.execute(statement4);
        
        cur.close();
        conn.close();
    except:
	traceback.print_exc()
        print "ERROR: Mysql Connection not found"
        conn.close();
        sys.exit();
#--------------------------------------:: Start of Main ::-------------------------------------------------------------------
def main():
    global hiveUserName;
    global hivePassCode;
    global LocalMysqlHostAddress;
    global LocalMysqlUser;
    global LocalMysqlPass;    

    date_time = time.strftime('%Y-%m-%d %H:%M:%S')
    print "Start Time:: ",date_time
    #print "RUN ID creation process started";
    try:
        wf_id          = sys.argv[1];
        hiveHostName   = sys.argv[2];
        hivePortNo     = sys.argv[3];
        hiveUserName   = sys.argv[4];
        hivePassCode   = sys.argv[5];
        impalaPortNo   = sys.argv[6]; 
        LocalMysqlHostAddress = sys.argv[7];
        LocalMysqlUser = sys.argv[8];
        LocalMysqlPass = sys.argv[9];
        """
        (LocalMysqlHostAddress, LocalMysqlUser, LocalMysqlPass) = ('10.94.191.202', "root", "password")
        (impalaPortNo) = (21050)
        wf_id = 'Mysql_WF_TEST'
        """        
    except:
        traceback.print_exc();
        print"ERROR: Argument Expected, not given";
        sys.exit();

    #creation of RUN ID, store it in a variable
    file_name = 'NA';
    action_name="RunIdCreation";
    file_checksum = "NA"
    run_id_key = date_time+wf_id;
    start_time = '0000-00-00 00:00:00';
    start_time = date_time;
    end_time   = '0000-00-00 00:00:00';
    job_status = 'STARTED';

    getKerberosTicket();
    ensureMysqlTableCreation();

    if wf_id == "":
        error_code = "WF003";
        error_type = "CRITICAL";
        error_message = "ERROR: Workflow id not generated";
        try:
            conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
            cur = conn.cursor()
            cur.execute("use socio_config_db");
            statement1=("INSERT INTO socio_config_db.process_details values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" % ('NULL', file_name, action_name, date_time, error_code, error_type, error_message, file_checksum, 'FAIL'));
            cur.execute(statement1);
            conn.close();
            print "ERROR: Workflow id not generated";
        except:
            traceback.print_exc()
            print "ERROR: Mysql Connection not found"	
            conn.close();
            sys.exit();
    else:
        try:
            #Mysql connection
            conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass)
            cur = conn.cursor()
            cur.execute("use socio_config_db");
            print "INFO: Inserting RUNID and WFID into common_run_id_tracker hive table";
            statement2=("INSERT INTO socio_config_db.common_run_id_tracker values ('%s', '%s', '%s', '%s')" % (run_id_key, start_time, end_time, job_status))
            cur.execute(statement2);

            print "INFO: Inserting Process Details into process_details hive table";
            statement3=("INSERT INTO socio_config_db.process_details values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" % (wf_id, file_name, action_name, date_time, 'NA', 'INFO', 'INFO: RUN ID generated successfully', 'NA', 'PASS'));
            cur.execute(statement3);
            conn.close();
            print "INFO: RUN ID generated successfully, RUNID and WFID is recorded into hive table";
        except:
            traceback.print_exc()
            print "ERROR: Mysql Connection not found"
            conn.close();
            sys.exit();

    print "RUN ID creation process completed";
    End_time = time.strftime('%Y-%m-%d %H:%M:%S')
    print "End_time :: ", End_time
#-----------------------:: End of Main ::-----------------------------------------------------------------------

if __name__ == "__main__": main()


