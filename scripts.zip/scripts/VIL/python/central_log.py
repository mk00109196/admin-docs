#!/usr/bin/python
##################################################################################################
#	Name    : Central logging script to log error generated from oozie action into hive table
#	Date    : 24-05-2016
#	Author  : Mithun Kankal
#	Version : 1.0
##################################################################################################

import pyhs2
import impala.dbapi
import datetime
import sys;
import re;
import subprocess;
import time;
import traceback;
import datetime;
import base64;
import commands;
import MySQLdb;

hiveConfigDb  = 'socio_config_db'
DateTime      = time.strftime('%Y-%m-%d %H:%M:%S');
auth_Mech     = "KERBEROS"
mysqlConfigDb = "socio_config_db"
StartTime = time.strftime("%Y%m%d-%H:%M:%S")



wf_id         = sys.argv[1];
action_name   = sys.argv[2];
action_status = sys.argv[3];
error_code    = sys.argv[4];
error_message = sys.argv[5];
externalId    = sys.argv[6];
hostName  = sys.argv[7];
hivePortNo    = sys.argv[8];
hiveUserName  = sys.argv[9];
hivePassCode  = sys.argv[10];
impalaPortNo  = sys.argv[11];
#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress = sys.argv[12];
LocalMysqlUser        = sys.argv[13];
LocalMysqlPass        = sys.argv[14];


"""

######################## :: Script Arguments for standalone run :: #########################
(wf_id, databaseType, HostAddress, HostPortNumber, databaseName)      = ("WF_TEST_mysql", "jdbc:mysql", "10.94.191.202", "3306", "mysql_source")
(databaseUserName, databasePassword, databaseDriver, numberOfmapper) = ( "root", base64.b64encode("password"), "com.mysql.jdbc.Driver", "1")
(action_name,action_status,error_code,error_message,externalId) = ("test_action_success","","","","")
#### :: Hive Connection Parameter :: ####
(hostName, hivePortNo, hiveUserName, hivePassCode) = ('10.94.191.203', 10000, "adityak@VIL.COM", "vil123")
impalaPortNo = 21050;

#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress = "10.94.191.202"
LocalMysqlUser = "root"
LocalMysqlPass = "password"
"""





#Creation of log file
Date_Time = datetime.datetime.now().strftime ("%Y%m%d-%H%M%S");
log_file_name = "/data/VIL/log/workflow_"+Date_Time+".log"
#error_file_name = "/data/VIL/log/workflow_error_"+Date_Time+".log"
log_dir_path = "/data/VIL/log"
application_id = re.sub(r'^job_','application_',externalId);

#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def getKerberosTicket():
        kinit_command = "/usr/bin/kinit "+hiveUserName;
        #print kinit_command;
        kinit = subprocess.Popen( kinit_command , shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);
        kinit.stdin.write(hivePassCode+"\n" );
        kinit.wait();
#----------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------
def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    mysqlConfigDb = 'socio_config_db';
    mysqlTableName1 = 'central_log';
    
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);
        
        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]
        if mysqlTableName1 not in mysqlConfigTables :
            st1=("CREATE TABLE IF NOT EXISTS socio_config_db.central_log (wf_id text, action_name text, action_status text, date_time timestamp, error_code text, error_message text)");
            cur.execute(st1);
        
        #print mysqlConfigTables;
        
        cur.close();
        conn.close();
    except:
        traceback.print_exc();
        conn.close();
        print "ERROR: MySql Connection not found";
        raise SystemExit;
    
#-----------------------------------------------------------------------------------------------------------------------------------
getKerberosTicket();
ensureMysqlTableCreation();


if action_status == "":
    action_status = "SUCCEEDED";
    error_code = "NA";
    error_message = "PASS";
else:
    #print"In ERROR Logging";
    ls_proc = subprocess.Popen(['yarn', 'logs', '-applicationId', application_id], stdout=subprocess.PIPE)
    ls_lines = ls_proc.stdout.readlines()

    put = subprocess.Popen(["hadoop", "fs", "-put", "-", log_file_name], stdin=subprocess.PIPE, bufsize=-1)
    #eput = subprocess.Popen(["hadoop", "fs", "-put", "-", error_file_name], stdin=subprocess.PIPE, bufsize=-1)

    #print "Length of list ::",len(ls_lines); 

    message_list = [];
    for index,line in enumerate(ls_lines,start=0):
	put.stdin.write(line);
        matchObj = re.match(r'.*(line [0-9]+)',line);
        if matchObj:
            #print "index :",index;
            #print "line :",line;
            for line1 in ls_lines[index:]:
                #print "message:",line1;
                message_list.append(line1.rstrip());
                matchObj1 = re.match(r'.*Error.*',line1);
                if matchObj1:
                    break;
            #eput.stdin.write(line);

    error_message = ''.join(message_list);
    error_message = error_message.replace('\"',' ');
    error_message = error_message.replace('\'',' ');
    #print error_message;
    put.stdin.close()
    #eput.stdin.close()

try:
    conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
    cur = conn.cursor()
    st2=("INSERT INTO socio_config_db.central_log values ('%s', '%s', '%s', '%s', '%s', '%s')" % (wf_id, action_name, action_status, DateTime, error_code, error_message))
    cur.execute(st2);
    cur.close();
    conn.close();
        
    if action_status == 'FAILED/KILLED': 
        print "Previous_Action=FAILED";
except:

    conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
    cur = conn.cursor()

    st3=("INSERT INTO socio_config_db.central_log values ('%s', '%s', '%s', '%s', '%s', '%s')" % (wf_id, action_name, 'UNKNOWN_STATUS', DateTime, 'ERROR_CODE_MISSING', 'Unexpected error: check logs'));
    cur.execute(st3);
    cur.close();
    conn.close();

    
    
    
    
EndTime = time.strftime("%Y%m%d-%H:%M:%S")    
#print"Start time ::", StartTime  
#print"End time ::", EndTime
