#!/usr/bin/python
##################################################################################################
#	Name    : create Copy of eligible data from source mysql to target  mysql database
#	Date    : 01-01-2017
#	Author  : Ganesh Warkhad
#	Version : 1.0
##################################################################################################

import datetime
import sys;
import re;
import subprocess;
import time;
import traceback;
import datetime;
import base64;
import commands;
import MySQLdb;
import os;
import itertools;

DateTime      = time.strftime('%Y_%m_%d_%H_%M_%S');
auth_Mech     = "KERBEROS"
StartTime = time.strftime("%Y%m%d-%H:%M:%S")

######################## :: Script Comman Line Arguments for standalone run :: #########################
wf_id                  = sys.argv[1];
action_name            = sys.argv[2];

#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress  = sys.argv[3];
LocalMysqlUser         = sys.argv[4];
LocalMysqlPass         = sys.argv[5];

#### :: Mysql Connection Parameter :: ####
MysqldatabaseName      = sys.argv[6];
SourceMysqlHostAddress = sys.argv[7];
MysqlHostPortNumber    = sys.argv[8]; 
SourceMysqlUser        = sys.argv[9];
SourceMysqlPass        = sys.argv[10];
PreArchivalTableNameList = sys.argv[11];
archival_action_value  = sys.argv[12];
archival_interval_value= sys.argv[13];

"""
#-------------------------------------------------------------------------------------------------------------------------------------------

######################## :: Script Arguments for standalone run :: #########################
(wf_id,action_name,MysqldatabaseName,mysql_target_fed,mysql_target,mysqlConfigDb)  = ('0000002-170127172622836-oozie-oozi-W','Archive_Socio_Data','SIT_MYSQL_SOURCE','socio_archive_db_fed_'+DateTime,'socio_archive_db_'+DateTime,'socio_config_db')
#print mysql_target
#print mysql_target_fed
#### :: Mysql Connection Parameter :: ####
(LocalMysqlHostAddress,LocalMysqlUser,LocalMysqlPass) = ("10.94.191.203","root","password")
#### :: Mysql Connection Parameter :: ####
(SourceMysqlHostAddress,SourceMysqlUser,SourceMysqlPass) = ("10.94.191.202","root","password")
MysqlHostPortNumber ="3306"
##################### :: Archival Criteria parameter ::############################
archival_action_value='6'
archival_interval_value='13'

PreArchivalTableNameList="t_workflow_dtls,t_sch_messages,t_circle"

#PreArchivalTableNameList="t_workflow_dtls,t_sr_type_dtls,t_srid_dtls_siebel,t_srid_dtls_siebel_fields,t_srid_dtls_siebel_srdtls,t_lead,t_srid_dtls,t_customer_lead,t_customer_lead_address,t_customer_lead_contact";
"""

#-------------------------------------------------------------------------------------------------------------------------------------------
##################### :: Variable declaration ::############################

MasterTables='t_user', 't_orgname', 't_user_org_rel', 't_brand_profiles', 't_tags_new', 't_workbasket', 't_role', 't_response_types', 't_source', 't_circle', 't_surveys', 't_survey_profile_rel', 't_survey_questions', 't_survey_question_answers', 't_external_data_reporting', 't_survey_respondent_types', 't_workflow_status'
federated_connection=LocalMysqlUser+':'+LocalMysqlPass+'@'+LocalMysqlHostAddress+':'+MysqlHostPortNumber

mysqlConfigTable   ='common_load_conf'
closed_cases_table ='t_workflow_dtls_closed_case_list'
last_load_details  ='last_load_details'
mysql_target_fed   ='socio_archive_db_fed_'+DateTime
mysql_target       ='socio_archive_db_'+DateTime
mysqlConfigDb      ='socio_config_db'

TableList = PreArchivalTableNameList.split(',');

autoIncrementIdList = [];
parentIdList        = [];
actionList          = [];
lastRowValueList    = [];
fromUserIdList = [];
orgIdList = [];
fromBasketIdList = [];
toBasketIdList = [];
surveyIdList = [];
userChannelIdList = [];
msgIdList = [];
tuple_msgIdList  = "";
tuple_autoIncrementIdList  = "";
tuple_userChannelIdList  = "";
tuple_surveyIdList  = "";
tuple_toBasketIdList  = "";
tuple_fromBasketIdList  = "";
tuple_orgIdList  = "";
tuple_parentIdList  = "";
tuple_fromUserIdList = "";
hiveTableName       = "";
maxValueOf_t_workflow_dtls_id = "";
preFileLastColValues= [];
sourceIdList = [];
tuple_sourceIdList = "";
toUserIdList = [];
tuple_toUserIdList = "";
listOfClosedCasesDetails=[]
importQuery         = {};
listOfEntireTableDetails=[]
listLastLoadDetails =[]
last_value_imported=0

OrignalList = [];
tempList    = [];
#--------------------------------:: Start loadClosedCaseList() ::----------------------------------------------------------
def loadClosedCaseList():
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
	qry='SELECT * FROM '+mysql_target+'.'+closed_cases_table;
        cur.execute(qry)
        listOfClosedCasesDetails1=cur.fetchall()
	#print listOfClosedCasesDetails1
        return listOfClosedCasesDetails1
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
	print "loadArchivalData=FAILED";
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: load archival Database Details ::----------------------------------------------------------
def archivalDBDetails():
    try:
	DateTime      = time.strftime('%Y-%m-%d %H:%M:%S');
        status        = 'RUNNING'
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
	statement2=("insert into "+mysqlConfigDb+".pre_archival_db_details(wf_id,pre_archival_db_name,source_federated_db_name,executed_date,status) values('%s','%s','%s','%s','%s')")%(wf_id,mysql_target,mysql_target_fed,DateTime,status)
	cur.execute(statement2);
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection2 not found"
	print "loadArchivalData=FAILED";
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: load archival counts Details ::----------------------------------------------------------
def getPreArchivalCount():
    try:
	DateTime      = time.strftime('%Y-%m-%d %H:%M:%S');
	conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass,db=mysql_target);
        cur = conn.cursor()
	for table in TableList:
            qry='SELECT count(*) FROM '+mysql_target+'.'+table;
            cur.execute(qry)
	    preArchivalCount=cur.fetchone();
            statement2=("insert into "+mysqlConfigDb+".pre_archival_details(wf_id,table_name,pre_archival_count,executed_date) values('%s','%s','%s','%s')")%(wf_id,table,preArchivalCount[0],DateTime)
            cur.execute(statement2);

    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection3 not found"
	print "loadArchivalData=FAILED";
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------- :: Function Definition for ensureMysqlTableCreation :: ------------------------------------
def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    #mysqlConfigDb = 'socio_config_db';
    mysqlTableName1 = 'last_load_details';
    mysqlTableName2 = 'process_details';
    mysqlTableName3 = 'pre_archival_details';
    mysqlTableName4 = 'pre_archival_db_details';

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);

        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]

        if mysqlTableName1 not in mysqlConfigTables :
            create_statement = ("CREATE TABLE IF NOT EXISTS "+mysqlConfigDb+".last_load_details(wf_id text, hive_table_name text, execution_date timestamp NULL, check_column_name text, last_value_imported text, incremental_mode_value text, status text)");
            cur.execute(create_statement);

        if mysqlTableName2 not in mysqlConfigTables :
            statement4=("CREATE TABLE IF NOT EXISTS "+mysqlConfigDb+".process_details(wf_id text, inboxfilenamewithext text, action_name text, date_time timestamp, error_code text, error_type text, error_message text,  file_checksum text, process_status text)");
            cur.execute(statement4);


	if mysqlTableName3 not in mysqlConfigTables :
	    statement1=("CREATE TABLE IF NOT EXISTS "+mysqlConfigDb+".pre_archival_details (wf_id text,table_name text,pre_archival_count bigint,executed_date text)");
            cur.execute(statement1);

        if mysqlTableName4 not in mysqlConfigTables :
            statement4=("CREATE TABLE IF NOT EXISTS "+mysqlConfigDb+".pre_archival_db_details (wf_id text,pre_archival_db_name text,source_federated_db_name text,executed_date text,status text)");
            cur.execute(statement4);

        cur.close();
        conn.close();
    except:
        traceback.print_exc()
        print "ERROR: Mysql Connection4 not found"
	print "loadArchivalData=FAILED";
        raise SystemExit;
#----------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start databaseCommunicator() ::----------------------------------------------------------
def databaseCommunicator():
    global listOfEntireTableDetails;
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor();
        cur.execute("SELECT * FROM "+mysqlConfigDb+"."+mysqlConfigTable)
        listOfEntireTableDetails=cur.fetchall()
        return listOfEntireTableDetails
        cur.close();
        conn.close();
    except Exception as error:
        #traceback.print_exc()
        print "ERROR: MySQL Connection not found"
        print "loadArchivalData=FAILED";
        print error;
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------

#-------------------------------------- :: Function for load data in process detail  :: -----------------------------------------------------
def insertDetailsInToProcessDetailsTable(error_code,error_type,error_message,process_status):
    inboxfilenamewithext = 'NA'
    file_checksum = 'NA'
    Date_Time = time.strftime('%Y-%m-%d %H:%M:%S');

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
        cur  = conn.cursor();    
     
        statement2=("INSERT INTO "+mysqlConfigDb+".process_details values ('%s', '%s', '%s', '%s', '%s', '%s', \"%s\", '%s', '%s')" % (wf_id, inboxfilenamewithext, action_name, Date_Time, error_code, error_type, error_message, file_checksum, process_status));
        #print statement2;
        cur.execute(statement2);
        cur.close();
        conn.close();

    except:
        traceback.print_exc();
        print "ERROR: MySql Connection not found";
        print "loadArchivalData=FAILED";
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------

#------------------------------------ Load last load value in last_load_detail table--------------------------------------------
def StoreLastImportedValueofMasterTable():
    global last_value_imported;
    incrementalModeValue = 'append'
    workflowId           = wf_id
    status               = 'RUNNING'
    execution_date = time.strftime('%Y-%m-%d %H:%M:%S');
    checkColumnName='id'
    hiveTableName=closed_cases_table

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass)
        cur = conn.cursor()
	
	statement1="select max(id) from "+mysql_target+".t_workflow_dtls_closed_case_list";
	cur.execute(statement1);
	lastValueImported=cur.fetchone();
        lastValueImported=lastValueImported[0];
	#print last_value_imported
	if  lastValueImported is None:
		lastValueImported=last_value_imported;
		if last_value_imported == '':
			lastValueImported=0;
	#print ">>>>>>>>>>>>>"+str(lastValueImported)
        statement_1=("INSERT INTO "+mysqlConfigDb+".last_load_details values ('%s', '%s', '%s', '%s', '%s', '%s', '%s')" % (workflowId, hiveTableName, execution_date, checkColumnName, lastValueImported, incrementalModeValue, status));
        cur.execute(statement_1);
        conn.close();
    except Exception as error:
        #traceback.print_exc()
        print "ERROR: MySQL Connection not found"
        print "loadArchivalData=FAILED";
        print error;
        raise SystemExit;

#------------------------------------------------------------------------------------------------------------------------------

#--------------------------------:: Start loadClosedCaseList() ::----------------------------------------------------------
def loadLastLoadDetails():
    global listLastLoadDetails;
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
        #qry='SELECT * FROM '+mysqlConfigDb+'.'+last_load_details;
	qry='select * from '+mysqlConfigDb+'.last_load_details where wf_id =(select distinct wf_id from '+mysqlConfigDb+'.last_load_details where execution_date =(select max(execution_date) from '+mysqlConfigDb+'.last_load_details where status = \'SUCCESS\'))'

        cur.execute(qry)
        listLastLoadDetails=cur.fetchall()
        #print listLastLoadDetails
        return listLastLoadDetails
    except Exception as error:
        #traceback.print_exc()
        print "ERROR: Mysql Connection5 not found"
        print "loadArchivalData=FAILED";
        print error;
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------


#--------------------------------:: Start loadClosedCaseList() ::----------------------------------------------------------
def checkDataCount():
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
        #qry='SELECT * FROM '+mysqlConfigDb+'.'+last_load_details;
	flag=1;
	for table in TableList:
            qry='select count(*) from '+mysql_target+'.'+table
            cur.execute(qry)
            tableCount=cur.fetchone()
	    #print "tableCount==="+str(tableCount[0])
	    if tableCount[0] ==0:
                flag=1 	
	    else:
		flag=0
		break;
	
	if flag==1:
	    print "No Data Found to archive"
	    raise SystemExit;
    except Exception as error:
        #traceback.print_exc()
        print "ERROR: Mysql Connection6 not found"
        print "loadArchivalData=FAILED";
	print error;
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------

#--------------------------------:: Start removeDuplicateEntryFromList() ::------------------------------------------------------------
def removeDuplicateEntryFromList(OrignalList):
    tempList = [];
    for i in OrignalList:
        if i not in tempList:
            tempList.append(i)

    return tempList;
#--------------------------------:: Start prepareMySqlTableData() ::------------------------------------------------------------
def prepareMySqlTableData():
    global maxValueOf_t_workflow_dtls_id;
    global tuple_orgIdList;
    global tuple_fromUserIdList;
    global tuple_parentIdList;
    global tuple_fromBasketIdList;
    global tuple_toBasketIdList;
    global tuple_surveyIdList;
    global tuple_userChannelIdList;
    global tuple_msgIdList;
    global tuple_autoIncrementIdList;
    global tuple_sourceIdList;
    global tuple_toUserIdList;
    
    global msgIdList;
    global autoIncrementIdList;
    global orgIdList;
    global fromUserIdList;
    global fromBasketIdList;
    global toBasketIdList;
    global parentIdList;
    global surveyIdList;
    global userChannelIdList;
    global sourceIdList;
    global toUserIdList;

    for row in range(0, len(listOfEntireTableDetails)):
        importQuery[listOfEntireTableDetails[row][4]] = listOfEntireTableDetails[row][11];
        #print" importQuery tablewise :: ", importQuery ;
    #print listOfClosedCasesDetails;

    for row in range(0, len(listOfClosedCasesDetails)):
        autoIncrementIdList.append(listOfClosedCasesDetails[row][0]);
        msgIdList.append(listOfClosedCasesDetails[row][1]);
        orgIdList.append(listOfClosedCasesDetails[row][3]);
        fromUserIdList.append(listOfClosedCasesDetails[row][4]);
        fromBasketIdList.append(listOfClosedCasesDetails[row][6]);
        toBasketIdList.append(listOfClosedCasesDetails[row][7]);
        actionList.append(listOfClosedCasesDetails[row][16]);
        parentIdList.append(listOfClosedCasesDetails[row][18]);
        surveyIdList.append(listOfClosedCasesDetails[row][44]);
        userChannelIdList.append(listOfClosedCasesDetails[row][49]);
        sourceIdList.append(listOfClosedCasesDetails[row][19]);
        toUserIdList.append(listOfClosedCasesDetails[row][5]);
    
    autoIncrementIdList = removeDuplicateEntryFromList(autoIncrementIdList); 
    msgIdList           = removeDuplicateEntryFromList(msgIdList);
    orgIdList           = removeDuplicateEntryFromList(orgIdList);
    fromUserIdList      = removeDuplicateEntryFromList(fromUserIdList);
    fromBasketIdList    = removeDuplicateEntryFromList(fromBasketIdList);
    toBasketIdList      = removeDuplicateEntryFromList(toBasketIdList);
    parentIdList        = removeDuplicateEntryFromList(parentIdList);
    surveyIdList        = removeDuplicateEntryFromList(surveyIdList);
    userChannelIdList   = removeDuplicateEntryFromList(userChannelIdList);
    sourceIdList        = removeDuplicateEntryFromList(sourceIdList);
    toUserIdList        = removeDuplicateEntryFromList(toUserIdList);
    
    #print "Max value imported for table t_workflow_dtls is :: ", maxValueOf_t_workflow_dtls_id;
    
    tuple_autoIncrementIdList = ",".join(["\'"+str(x)+"\'" for x in autoIncrementIdList]);
    tuple_orgIdList = ",".join(["\'"+str(x)+"\'" for x in orgIdList]);
    tuple_msgIdList = ",".join(["\""+str(x)+"\"" for x in msgIdList]);
    tuple_fromUserIdList = ",".join(["\'"+str(x)+"\'" for x in fromUserIdList]);
    tuple_fromBasketIdList = ",".join(["\'"+str(x)+"\'" for x in fromBasketIdList]);
    tuple_toBasketIdList = ",".join(["\'"+str(x)+"\'" for x in toBasketIdList]);
    tuple_parentIdList = ",".join(["\'"+str(x)+"\'" for x in parentIdList]);
    tuple_surveyIdList = ",".join(["\'"+str(x)+"\'" for x in surveyIdList]);
    tuple_userChannelIdList = ",".join(["\'"+str(x)+"\'" for x in userChannelIdList]);
    tuple_sourceIdList = ",".join(["\'"+str(x)+"\'" for x in sourceIdList]);
    tuple_toUserIdList = ",".join(["\'"+str(x)+"\'" for x in toUserIdList]);

    if not autoIncrementIdList:
        #print"Sqoop_Import=FAILED";
        print "Closed Case List is Empty" ;
	
	tuple_autoIncrementIdList = "null";
    	tuple_orgIdList = "null";
    	tuple_msgIdList = "null";
    	tuple_fromUserIdList = "null";
    	tuple_fromBasketIdList = "null";
    	tuple_toBasketIdList = "null";
    	tuple_parentIdList = "null";
    	tuple_surveyIdList = "null";
    	tuple_userChannelIdList = "null";
    	tuple_sourceIdList = "null";
    	tuple_toUserIdList = "null";
        #raise SystemExit;
    else:
        maxValueOf_t_workflow_dtls_id = max(autoIncrementIdList);



#------------------------------------------Import tables------------------------------------------------------------------
def importMysqlTables():
	global last_value_imported;
	global listOfClosedCasesDetails;
	global listOfEntireTableDetails; 
	try:
	    trgt_con = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
	    trgt_cur = trgt_con.cursor()
	    qry="show databases"
	    trgt_cur.execute(qry);
	    mysqlDatabases = [item[0] for item in trgt_cur.fetchall()]
	    #print mysqlDatabases;
	    if mysql_target not in mysqlDatabases :
		trgt_cur.execute("CREATE DATABASE IF NOT EXISTS "+mysql_target);
	    else:
		trgt_cur.execute("drop DATABASE "+mysql_target);
		#print "DB drop"
		trgt_cur.execute("CREATE DATABASE IF NOT EXISTS "+mysql_target);
		#print "DB create"
	    trgt_cur.close();
	    trgt_con.close();
	    
	    insertDetailsInToProcessDetailsTable('NA','INFO','Mysql eligible archival Database created:'+mysql_target,"PASS");

	    trgt_con = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass,db=mysql_target);
	    trgt_cur = trgt_con.cursor()

	    src_conn = MySQLdb.connect(host=SourceMysqlHostAddress, user=SourceMysqlUser, passwd=SourceMysqlPass,db=MysqldatabaseName);
	    src_cur = src_conn.cursor()

	    qry="show databases"
	    src_cur.execute(qry);
	    mysqlDatabases = [item[0] for item in src_cur.fetchall()]
	    #print mysqlDatabases;
	    if mysql_target_fed not in mysqlDatabases :
		src_cur.execute("CREATE DATABASE IF NOT EXISTS "+mysql_target_fed);
	    else:
		src_cur.execute("drop DATABASE "+mysql_target_fed);
		#print "DB drop"
		src_cur.execute("CREATE DATABASE IF NOT EXISTS "+mysql_target_fed);

	    insertDetailsInToProcessDetailsTable('NA','INFO','Mysql federated Database created:'+mysql_target_fed,"PASS");

            archivalDBDetails();
	    trgt_con_fed = MySQLdb.connect(host=SourceMysqlHostAddress, user=SourceMysqlUser, passwd=SourceMysqlPass,db=mysql_target_fed);
	    trgt_cur_fed = trgt_con_fed.cursor()

	    #qry="show tables"
	    #src_cur.execute(qry);
	    #src_mysqlTables = [item[0] for item in src_cur.fetchall()]
	    #table='t_circle' src_mysqlTables
	    for table in TableList:
		split_schema=[]
		qry="show create table "+table
		#print qry;
		src_cur.execute(qry);
		create_table = [item[1] for item in src_cur.fetchall()]
		#create_table = item[0] for item in create_table
		#print create_table
		#print create_table[0].split('\n');
		trgt_cur.execute(create_table[0]);
		split_schema=create_table[0].split('\n');
		del split_schema[-1]
		#print split_schema
		cr_str=") ENGINE=FEDERATED CONNECTION= 'mysql://"+federated_connection+"/"+mysql_target+"/"+table+"'"
		split_schema.append(cr_str);
		#print split_schema
		cr_table=" ".join(x for x in split_schema)
		#print cr_table
		trgt_cur_fed.execute(cr_table);
		#print create_table
		#trgt_cur.execute(create_table[0]);

	    
	    qry="show create table "+MysqldatabaseName+".t_workflow_dtls"
	    src_cur.execute(qry);
	    create_table = [item[1] for item in src_cur.fetchall()]
	    #print create_table    
	    create_table=create_table[0].replace('t_workflow_dtls', closed_cases_table);
	    #print create_table
	    trgt_cur.execute(create_table);

	    split_schema=create_table.split('\n');
	    del split_schema[-1]
	    cr_str=") ENGINE=FEDERATED CONNECTION= 'mysql://"+federated_connection+"/"+mysql_target+"/"+closed_cases_table+"'"
	    split_schema.append(cr_str);
	    cr_table=" ".join(x for x in split_schema)
	    #print cr_table;
	    trgt_cur_fed.execute(cr_table);
	 
	    trgt_cur_fed.close();
	    trgt_con_fed.close();
            ins_qry="insert into "+mysql_target_fed+"."+closed_cases_table+"  select * from "+MysqldatabaseName+".t_workflow_dtls where action="+archival_action_value+" and createdon < DATE_ADD(Now(), INTERVAL- "+archival_interval_value+" MONTH)"
	    lastLoadList=[];
            lastLoadList=loadLastLoadDetails();    
	    for row in lastLoadList:
		if closed_cases_table in row[1]:
	            lastLoad_wf_id=row[0]
		    check_column_name=row[3]
		    last_value_imported=row[4]
		    #print "check_column_name:"+check_column_name+"   last_value_imported:"+last_value_imported
		    
		    ins_qry="insert into "+mysql_target_fed+"."+closed_cases_table+"  select * from "+MysqldatabaseName+".t_workflow_dtls where action="+archival_action_value+" and createdon < DATE_ADD(Now(), INTERVAL- "+archival_interval_value+" MONTH) and "+check_column_name+">"+last_value_imported

	    #print ins_qry
	    src_cur.execute(ins_qry);    
            insertDetailsInToProcessDetailsTable('NA','INFO','Table created:'+closed_cases_table,"PASS");
	    listOfClosedCasesDetails=loadClosedCaseList();
	    listOfEntireTableDetails=databaseCommunicator();
	    prepareMySqlTableData();

	    for table in TableList:
		insert_qry=''

		if table=='t_workflow_dtls':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+" "+importQuery[table])%(tuple_parentIdList);

		elif table=='t_sch_mess_accts' or table=='t_sch_messages':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_sourceIdList);

		elif table=='t_lead_social_accts':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+" "+importQuery[table])%(tuple_userChannelIdList);

		elif table=='t_message_tag_dtls' or table == 't_sentiment_changed':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_msgIdList);

		elif table=='t_respondents':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+" "+importQuery[table])%(tuple_surveyIdList,tuple_autoIncrementIdList);

		elif table=='t_user_notes':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])% (tuple_autoIncrementIdList);

		elif table=='t_survey_respid_rel':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_surveyIdList);

		elif table == 't_survey_responses':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_surveyIdList);

		elif table=='t_tagged_messages':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_msgIdList,tuple_fromUserIdList,tuple_toUserIdList);

		elif table=='t_workflow_tat_dtls':
		    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_autoIncrementIdList,tuple_parentIdList);
                elif table=='t_srid_dtls':
                    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_autoIncrementIdList);

                elif table=='t_lead':
                    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_fromBasketIdList,tuple_toBasketIdList);
                elif table=='t_sr_type_dtls':
                    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_autoIncrementIdList);					
                elif table=='t_srid_dtls_siebel':
                    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_autoIncrementIdList);

                elif table=='t_srid_dtls_siebel_fields':
                    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_autoIncrementIdList);               

                elif table=='t_srid_dtls_siebel_srdtls':
                    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_autoIncrementIdList);

                elif table=='t_customer_lead':
                    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_fromBasketIdList,tuple_toBasketIdList);
                elif table=='t_customer_lead_address':
                    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_fromBasketIdList,tuple_toBasketIdList);
                elif table=='t_customer_lead_contact':
                    insert_qry=("insert into "+mysql_target_fed+"."+table+"  "+importQuery[table])%(tuple_fromBasketIdList,tuple_toBasketIdList);

		#print qry
		else:
		    if table in MasterTables:
			insert_qry="insert into "+mysql_target_fed+"."+table+" "+importQuery[table];
		        for row in lastLoadList:
			    #print "ROW>>>"+row[1]
                            if table == row[1]:
				#print table+"<<<ROW>>>"+row[1]
                                #lastLoad_wf_id=row[0]
                                check_column_name=row[3]
                                last_value_imported_master=row[4]
                                #print "check_column_name:"+check_column_name+"   last_value_imported:"+last_value_imported
			        insert_qry="insert into "+mysql_target_fed+"."+table+" "+importQuery[table]+" where "+check_column_name+">"+last_value_imported_master; 
                
		#print insert_qry
		src_cur.execute(insert_qry);  

		alt_qry="alter table "+mysql_target+"."+table+" add column archival_flag int,add column archival_date varchar(10)"
		trgt_cur.execute(alt_qry)

                qry1="select * from "+mysqlConfigDb+".common_run_id_tracker where run_id like \'%"+wf_id+"%\'";
                trgt_cur.execute(qry1);
                start_date_time = trgt_cur.fetchone()[1].strftime("%Y%m%d%H");
                upd_qry="update "+table+" set archival_flag=0,archival_date="+start_date_time

		trgt_cur.execute(upd_qry);

	        insertDetailsInToProcessDetailsTable('NA','INFO','Source Table Data copied to archival mysql table:'+table,"PASS");

	    trgt_con.commit();
	    trgt_cur.close();
	    trgt_con.close();
	    src_cur.close();
	    src_conn.close();

	except Exception as e:
		#traceback.print_exc()
		print traceback.print_exc();
		#print "ERROR: Connection error."
	        error_code = 'WF015';
        	error_type = 'Major';
	        process_status = 'FAIL';
	        insertDetailsInToProcessDetailsTable(error_code,error_type,e,process_status);
		print "loadArchivalData=FAILED";
		raise SystemExit;



#---------------------MAIN EXECUTION START------------------------------------------------------------------------------------------
try:
        #ensure mysql table 
        ensureMysqlTableCreation();

        importMysqlTables();


        getPreArchivalCount();

        StoreLastImportedValueofMasterTable();

	checkDataCount();

except Exception as e:
        #traceback.print_exc()
        print e;
        print "ERROR: Connection error."
        print "loadArchivalData=FAILED";
        raise SystemExit;


