#!/usr/bin/python
##################################################################################################
#       Name    : File Level Validation
#       Desc    : This Script load the data from hive table and validate inbox file against it,
#                 It validates file naming convention.
#       Date    : 24-05-2016
#       Author  : Mithun Kankal
#       Version : 1.0
##################################################################################################

import impala.dbapi
import pyhs2
import commands
import subprocess
import time
import sys;
import traceback
import re;
import time;
from pyhs2.error import Pyhs2Exception;
import MySQLdb;

StartTime = time.strftime("%Y%m%d-%H:%M:%S")
execution_date = time.strftime('%Y-%m-%d %H:%M:00');
#print "execution_date ::",execution_date
#----------------------------------:: Global Varibale Declration ::----------------------------------------------------------
auth_Mech="KERBEROS"
databaseName='socio_db'

mysqlConfigDb='socio_config_db'

config_table="common_load_conf "
last_load_tableName='last_load_details '
hostName='';
hivePortNo='';
hiveUserName='';
hivePassCode='';

sysdate=time.strftime("%Y%m%d-%H%M%S")
#hiveFileNamesList = [];
hiveDraFileLocationsList = [];
hiveErrorFileLocationsList = [];
hiveNoOfColumnsInFilesList = [];
hiveFileDelimitersList = [];
#hiveFileExtensionsList = [];
InboxFileNamesWithExtList = [];
hiveInboxFileLocationList = [];
hiveTableNameList = [];
mysqlTableNameList = [];
mysqlTableName = '';

InboxBoxDirEmpty = '';
process_dir = '';
error_dir = '';
error_path = '';
process_path = '';
wf_id = '';
inboxfilenamewithext = '';
inbox_path= '';
folderName = '';
tableNameList = '';

preFileLastColValues = [];
curFileLastColValues = [];
listOfLastLoadDetails = [];
lastLoadTableNameList    = [];
checkCloumnList          = [];
lastValueImportedDic     = {};
incrementalModeValueList = [];
lastWorkflowIdList       = [];
listTableName            = [];

hiveDraFileLocation, hiveErrorFileLocation = '', '';
error_code, error_type, error_message, file_checksum, process_status = '', '', '', '', '';

#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def getKerberosTicket():
        kinit_command = "/usr/bin/kinit "+hiveUserName;
        #print kinit_command;
        kinit = subprocess.Popen( kinit_command , shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);
        kinit.stdin.write(hivePassCode+"\n" );
        kinit.wait();
#----------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------- :: Function Definition for ensureMysqlTableCreation :: ------------------------------------
def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    mysqlConfigDb = 'socio_config_db';
    mysqlTableName1 = 'last_load_details';
    mysqlTableName2 = 'process_details';

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);

        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]

        if mysqlTableName1 not in mysqlConfigTables :
            create_statement = ("CREATE TABLE IF NOT EXISTS socio_config_db.last_load_details(wf_id text, hive_table_name text, execution_date timestamp NULL, check_column_name text, last_value_imported text, incremental_mode_value text, status text)");
            cur.execute(create_statement);

        if mysqlTableName2 not in mysqlConfigTables :
            statement4=("CREATE TABLE IF NOT EXISTS socio_config_db.process_details(wf_id text, inboxfilenamewithext text, action_name text, date_time timestamp, error_code text, error_type text, error_message text,  file_checksum text, process_status text)");
            cur.execute(statement4);

        cur.close();
        conn.close();
    except:
        traceback.print_exc()
        print "ERROR: Mysql Connection not found"
        conn.close();
        sys.exit();

#----------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start databaseCommunicator() ::----------------------------------------------------------
def databaseCommunicator():
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass)
	cur = conn.cursor();
        cur.execute("use "+mysqlConfigDb);
	cur.execute("SELECT * FROM "+mysqlConfigDb+"."+config_table)
	listOfEntireTableDetails=cur.fetchall()
	return listOfEntireTableDetails;
	cur.close();
	conn.close();
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: MySQL Connection not found"
        conn.close();
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start loadLastLoadDetailsTableData() ::----------------------------------------------------------
def loadLastLoadDetailsTableData():
    try:
        global listOfLastLoadDetails;
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor();

        cur.execute("use socio_config_db");
        qry='select * from '+mysqlConfigDb+'.last_load_details where wf_id =(select distinct wf_id from '+mysqlConfigDb+'.last_load_details where execution_date =(select max(execution_date) from '+mysqlConfigDb+'.last_load_details where status = \'SUCCESS\'))'

        cur.execute(qry)
        listOfLastLoadDetails=cur.fetchall()
        return listOfLastLoadDetails;
	cur.close();
	conn.close();
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: MySQL Connection not found"
        conn.close();
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start prepareMySQLConfTableData() ::----------------------------------------------------------
def prepareMySQLConfTableData():

    # Loading the data from common_load_conf table
    for row in range(0, len(listOfEntireTableDetails)):
        #hiveFileNamesList.append(listOfEntireTableDetails[row][0])
        hiveDraFileLocationsList.append(listOfEntireTableDetails[row][1])
        hiveErrorFileLocationsList.append(listOfEntireTableDetails[row][2])
        hiveNoOfColumnsInFilesList.append(listOfEntireTableDetails[row][7])
        hiveFileDelimitersList.append(listOfEntireTableDetails[row][8])
        #hiveFileExtensionsList.append(listOfEntireTableDetails[row][9])
        hiveInboxFileLocationList.append(listOfEntireTableDetails[row][10])
        hiveTableNameList.append(listOfEntireTableDetails[row][4]) 

    # Loading the list of last load details or list of last imported values
    for row in range(0, len(listOfLastLoadDetails)):
        lastValueImportedDic[listOfLastLoadDetails[row][1]] = listOfLastLoadDetails[row][4];

    #print "lastValueImportedDic ::",lastValueImportedDic
    #print" lastLoadTableNameList :: ", lastLoadTableNameList;
    #print" checkCloumnList       :: ", checkCloumnList;
    #print" lastValueImportedList :: ", lastValueImportedList;
    #print" hiveTableNameList  :: ", hiveTableNameList ;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start readInboxFiles() ::----------------------------------------------------------
def readInboxFiles():
    global inbox_path; 
    inbox_path = hiveInboxFileLocationList[0];
    status, InboxBoxDirEmpty=commands.getstatusoutput("hadoop fs -ls "+inbox_path+"/*")

    #print "Mithun InboxBoxDirEmpty ::", InboxBoxDirEmpty;
    #print "status ::", status;

    if InboxBoxDirEmpty != '':

        InboxFileNamesList=commands.getstatusoutput("hadoop fs -ls "+inbox_path+"/* | sed 's/  */ /g' | cut -d\  -f8")
        #print "\n InboxFileNamesList", InboxFileNamesList;
        for y in range(1, len(InboxFileNamesList)):
            InboxFileNamesWithPathList=InboxFileNamesList[y].replace("\n\n",",").replace("\n",",").split(",")
            #print "\n InboxFileNamesWithPathList ::", InboxFileNamesWithPathList

        #print "listTableName ::", listTableName
        for z in range(1, len(InboxFileNamesWithPathList)):
            coreFileName=InboxFileNamesWithPathList[z].split("/")
            #print " coreFileName", coreFileName
            for k in range(0, len(listTableName)):
                if listTableName[k] == coreFileName[-2]:
                   InboxFileNamesWithExtList.append(coreFileName[-1])
                   mysqlTableNameList.append(coreFileName[-2])

	#print"InboxFileNamesWithExtList ::",InboxFileNamesWithExtList;
        #print"mysqlTableNameList ::",mysqlTableNameList;
    else:
        print"There are no files in Inbox";
        return "NOFILES"	
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start StoreLastImportedValueofMasterTable() ::---------------------------------------------
def StoreLastImportedValueofMasterTable(hiveTableName, lastRowValueList):

    incrementalModeValue = 'append'
    workflowId           = wf_id
    lastValueImported    = lastRowValueList[0]; 
    status               = 'RUNNING'

    if len(listOfLastLoadDetails) != 0:
        if lastValueImported == "":
            lastValueImported = lastValueImportedDic[hiveTableName]; 
    else:
        if lastValueImported == "":
            lastValueImported = 0;
 
    if hiveTableName in ('t_circle', 't_source', 't_workflow_status', 't_workflow_dtls'):
        checkColumnName      = 'id';
    elif hiveTableName in ('t_orgname'):
        checkColumnName      = 'orgId';
    elif hiveTableName in ('t_brand_profiles','t_response_types','t_lead_social_accts','t_user_org_rel','t_srid_dtls','t_user_notes','t_workflow_tat_dtls'):
        checkColumnName      = 'id';
    elif hiveTableName in ('t_survey_profile_rel','t_message_tag_dtls','t_survey_responses','t_survey_respid_rel','t_external_data_reporting'):
        checkColumnName      = 'id';
    elif hiveTableName in ('t_sr_type_dtls','t_srid_dtls_siebel','t_customer_lead','t_customer_lead_address','t_customer_lead_contact','t_srid_dtls_siebel_srdtls','t_srid_dtls_siebel_fields'):
        checkColumnName      = 'id';

    elif hiveTableName in ('t_tagged_messages','t_survey_respondent_types','t_sentiment_changed'):
        checkColumnName      = 'id';
    elif hiveTableName in ('t_user'):
        checkColumnName      = 'userId';
    elif hiveTableName in ('t_role'):
        checkColumnName      = 'roleId';
    elif hiveTableName in ('t_workbasket'):
        checkColumnName      = 'basketId';
    elif hiveTableName in ('t_surveys'):
        checkColumnName      = 'surveyId';
    elif hiveTableName in ('t_survey_questions'):
        checkColumnName      = 'questionId';
    elif hiveTableName in ('t_respondents'):
        checkColumnName      = 'respondentId';
    elif hiveTableName in ('t_sch_mess_accts'):
        checkColumnName      = 'schMsgId';
    elif hiveTableName in ('t_sch_messages'):
        checkColumnName      = 'schMsgId';
    elif hiveTableName in ('t_survey_question_answers'):
        checkColumnName      = 'ansId';
    elif hiveTableName in ('t_tags_new'):
        checkColumnName      = 'tagId';
    elif hiveTableName in ('t_lead'):
        checkColumnName      = 'leadId';

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass) 
        cur = conn.cursor()

        statement_1=("INSERT INTO socio_config_db.last_load_details values ('%s', '%s', '%s', '%s', '%s', '%s', '%s')" % (workflowId, hiveTableName, execution_date, checkColumnName, lastValueImported, incrementalModeValue, status));
        cur.execute(statement_1);

        conn.close();
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: MySQL Connection not found"
        conn.close();
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start validateFiles() ::-------------------------------------------------------------------
def validateFiles():
    global inboxfilenamewithext;
    global file_checksum;
    global error_code;
    global error_type;
    global error_message;
    global process_status;
    global hiveErrorFileLocation;
    global hiveDraFileLocation;

    preTableName = '';
    curTableName = '';
    #print "File are Getting.. Moved to PROCESS/ERROR Directory"
    exitFlag = 0;
    lastTableIndex = 0;

    for i in range(0, len(InboxFileNamesWithExtList)):
        lastTableIndex = i;
        #print "Start of Validation for file :: ",time.asctime( time.localtime(time.time()));
        inboxfilenamewithext = InboxFileNamesWithExtList[i];
        mysqlTableName = mysqlTableNameList[i];
        socioErrorFileName = '';
    	curTableName = mysqlTableName;
        if i == 0:
	    preTableName = mysqlTableName;
            preFileLastColValues = [];

        numOfColList = [];
        numOfColInFile = 0;
        field_delimeter = "";
        errorMessage = "";
        hiveNoOfColumns = "";
	try:
            j = hiveTableNameList.index(mysqlTableName.lower());
            #print" j :: ",j
            hiveErrorFileLocation = hiveErrorFileLocationsList[j];
            hiveDraFileLocation =  hiveDraFileLocationsList[j];
			
	    if mysqlTableName.upper() == hiveTableNameList[j].upper():
                if mysqlTableName.upper() == 'T_SOCIO':
                    matchFile = re.match(r'[a-zA-Z]{5}_[0-9]{2}_[0-9]{2}_[0-9]{4}.*.[a-zA-Z]{4}',inboxfilenamewithext.upper(),re.M)
                    if matchFile:
                        print"JSON File ::",inboxfilenamewithext;
                        moveFilesToProcessFolder(inboxfilenamewithext,mysqlTableName,hiveDraFileLocation);
                    else:
                        exitFlag = 1;
                        moveFilesToErrorFolder(inboxfilenamewithext,mysqlTableName,hiveErrorFileLocation);
                        socioErrorFileName = inboxfilenamewithext;
                else:
                    if inboxfilenamewithext == '_SUCCESS':
                        fileMatched = 'NA';
                        readline1="hadoop fs -rm -r -skipTrash "+inbox_path+"/"+mysqlTableName+"/"+inboxfilenamewithext
                        status, output=commands.getstatusoutput(readline1)
                    else:
                        try:
                            readline="hadoop fs -cat "+inbox_path+"/"+mysqlTableName+"/"+inboxfilenamewithext+" | tail -1"
                            status, output=commands.getstatusoutput(readline)

                            #print "output",output 
                            numOfColList = output.split('\b');
                            curFileLastColValues = numOfColList;

                            #print "numOfColList",numOfColList
                            if len(numOfColList) > 1:
                                field_delimeter = "TILDE";
                                numOfColInFile  = len(numOfColList);
                        
                            numOfColList = output.split('\t');
                            if len(numOfColList) > 1:
                                field_delimeter = "TAB";
                                numOfColInFile  = len(numOfColList);
                        
                            hiveNoOfColumns = hiveNoOfColumnsInFilesList[j];
                            if field_delimeter==hiveFileDelimitersList[j]:
                                if numOfColInFile==hiveNoOfColumnsInFilesList[j]:
                                    moveFilesToProcessFolder(inboxfilenamewithext,mysqlTableName,hiveDraFileLocation);
                                elif numOfColInFile == 0:
                                    moveFilesToProcessFolder(inboxfilenamewithext,mysqlTableName,hiveDraFileLocation);
                                else:
                                    error_code = 'WF005';
                                    error_type = 'CRITICAL';
                                    process_status = 'FAIL';
                                    error_message="ERROR: "+mysqlTableName+" : "+inboxfilenamewithext+", Delimiter or Number of col mismatch. From file="+str(numOfColInFile)+" and expected ="+str(hiveNoOfColumns);
                                    #print error_message
                                    moveFilesToErrorFolder(inboxfilenamewithext,mysqlTableName,hiveErrorFileLocation);
                                    insertDetailsInToProcessDetailsTable();
                                    exitFlag = 1;
                            elif numOfColInFile == 0:
                                moveFilesToProcessFolder(inboxfilenamewithext,mysqlTableName,hiveDraFileLocation);
                            else:
                                error_code = 'WF005';
                                error_type = 'CRITICAL';
                                process_status = 'FAIL';
                                moveFilesToErrorFolder(inboxfilenamewithext,mysqlTableName,hiveErrorFileLocation);
                                error_message="ERROR: "+mysqlTableName+" : "+inboxfilenamewithext+", Delimiter or Number of col mismatch. From file="+str(numOfColInFile)+" and expected ="+str(hiveNoOfColumns);
                                #print error_message
                                insertDetailsInToProcessDetailsTable();
                                print "Aborting .... for mismatch del";
                                exitFlag = 1;
      	                except:
                            error_code = 'WF008';
                            error_type = 'CRITICAL';
                            process_status = 'FAIL';
                            errorMessage="Error while reading content of file :"+inboxfilenamewithext;
                            moveFilesToErrorFolder(inboxfilenamewithext,mysqlTableName,hiveErrorFileLocation);
                            #print"unMatchedFileName ::", inboxfilenamewithext;
                            insertDetailsInToProcessDetailsTable();
                            #print"ERROR: ",error_message			
        except:
	    error_code = 'WF009';
            error_type = 'MAJOR';
            process_status = 'FAIL';
            error_message = mysqlTableName+", Table Name does not exists in table name listed in configuration of common_load_conf";
            moveFilesToErrorFolder(inboxfilenamewithext,mysqlTableName,hiveErrorFileLocation);
            #print"unMatchedFileName ::", inboxfilenamewithext;
            inboxfilenamewithext = mysqlTableName;
            insertDetailsInToProcessDetailsTable();
            #print"ERROR: ",error_message
            continue;

        if preTableName != curTableName:
            if preTableName != 'T_SOCIO':
                if exitFlag == 1:
                    error_code = 'WF010';
                    process_status = 'FAIL';
                else:
                    error_code = 'NA';
                    error_type = 'INFO';
                    file_checksum = 'NA';
                    process_status = 'PASS';
                    error_message = "File Validation Completed for files created during import of table :"+preTableName;
                    preFileLastColValues = curFileLastColValues;
                    #print"Length of preFileLastColValues ::", len(curFileLastColValues);

                    StoreLastImportedValueofMasterTable(preTableName,preFileLastColValues);
                    insertDetailsInToProcessDetailsTable();
  
                inboxfilenamewithext = preTableName;
                preTableName = curTableName;
                #print"INFO: ",error_message
	    else:
		if exitFlag == 1:
                    error_code = 'WF011';
                    error_type = 'Major';
                    process_status = 'FAIL';
                    error_message = "ERROR: File Validation process FAILED for T_SOCIO file :"+socioErrorFileName;
                else:
                    error_code = 'NA';
                    error_type = 'INFO';
                    process_status = 'PASS';
                    file_checksum = 'NA';
                    error_message = "File Validation Completed for "+preTableName+" files";

		inboxfilenamewithext = preTableName;
                insertDetailsInToProcessDetailsTable();
                preTableName = curTableName;
				
            if exitFlag == 1:
                print"File_Validation=FAILED";
                print error_message;
                raise SystemExit;

        if i+1 == len(InboxFileNamesWithExtList):
            if curTableName != 'T_SOCIO':
                if exitFlag == 1:
                    error_code = 'WF010';
                    process_status = 'FAIL';
                else:
                    error_code = 'NA';
                    error_type = 'INFO';
                    file_checksum = 'NA';
                    process_status = 'PASS';
                    error_message = "File Validation Completed for files created during import of table :"+curTableName;
                    preFileLastColValues = curFileLastColValues;
                    #print"Length of preFileLastColValues ::", len(curFileLastColValues);

                    StoreLastImportedValueofMasterTable(curTableName,preFileLastColValues);
                    insertDetailsInToProcessDetailsTable(); 

                inboxfilenamewithext = curTableName;
                preTableName = curTableName;
                #print"INFO: ",error_message
	    else:
		if exitFlag == 1:
                    error_code = 'WF011';
                    error_type = 'Major';
                    process_status = 'FAIL';
                    error_message = "ERROR: File Validation process FAILED for T_SOCIO file : "+socioErrorFileName;
                else:
                    error_code = 'NA';
                    error_type = 'INFO';
                    file_checksum = 'NA';
                    process_status = 'PASS';
                    error_message = "File Validation Completed for "+curTableName+" files";
                    #print error_message;

		inboxfilenamewithext = curTableName;
                insertDetailsInToProcessDetailsTable();
                preTableName = curTableName;
				
            if exitFlag == 1:
                print"File_Validation=FAILED";
                print error_message;
                raise SystemExit;

#------------------------------------------------------------------------------------------------------------------------------
#---------------------------------:: start of moveFilesToProcessFolder() ::---------------------------------------------------
def moveFilesToProcessFolder(Processed_files,mySqlTableName,hiveProcessFileLoc):
    global process_dir;
    global process_path;
    global folderName;
    folderName=sysdate;
    process_path=hiveProcessFileLoc;

    new_filename=Processed_files+"_"+folderName;

    try:
        process_dir=process_path+"/"+mySqlTableName;
        #print"process_dir ::", process_dir
        subprocess.call('hadoop fs -mkdir -p '+process_dir, shell=True)
    except:
        print"";

    process_dir=process_path+"/"+mySqlTableName;

    #print"inbox_path ::", inbox_path
    #print"mySqlTableName ::", mySqlTableName
    #print"Processed_files ::", Processed_files
    #print"process_dir ::", process_dir
    #print"new_filename ::", new_filename

    subprocess.call('hadoop fs -mv '+inbox_path+"/"+mySqlTableName+"/"+Processed_files+ ' '+process_dir+"/"+new_filename, shell=True)
    #subprocess.call('hadoop fs -chmod 777 ' +process_dir+"/"+new_filename, shell=True)
    return;
#------------------------------------------------------------------------------------------------------------------------------
#----------------------------:: Start of moveFilesToErrorFolder() ::-----------------------------------------------------------
def moveFilesToErrorFolder(Processed_files,mySqlTableName,hiveErrorFileLoc):
    global error_dir;
    global error_path;
    global folderName;
    folderName=sysdate;
    error_path=hiveErrorFileLoc;

    new_filename=Processed_files+"_"+folderName;

    try:
	error_dir=error_path+"/"+mySqlTableName;
        #print"error_dir ::", error_dir
        subprocess.call('hadoop fs -mkdir -p '+error_dir, shell=True)
    except:
        print"";

    error_dir=error_path+"/"+mySqlTableName;
    subprocess.call('hadoop fs -mv '+inbox_path+"/"+mySqlTableName+"/"+Processed_files+ ' '+error_dir+"/"+new_filename, shell=True)
    #subprocess.call('hadoop fs -chmod 777 ' +error_dir+"/"+new_filename, shell=True)
    return;
#------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------
def insertDetailsInToProcessDetailsTable():
    DateTime = time.strftime("%Y-%m-%d %H:%M:%S")

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();

        cur.execute("use socio_config_db");
        statement1=("INSERT INTO socio_config_db.process_details values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" % (wf_id, inboxfilenamewithext, action_name, DateTime, error_code, error_type, error_message, file_checksum, process_status));
        cur.execute(statement1);
        cur.close();
        conn.close();

    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: MySQL Connection not found"
        conn.close();
        raise SystemExit;

#-----------------------:: Start of Main ::------------------------------------------------------------------------------------
try:
    wf_id          = sys.argv[1];
    hostName       = sys.argv[2];
    hivePortNo     = sys.argv[3];
    hiveUserName   = sys.argv[4];
    hivePassCode   = sys.argv[5];
    impalaPortNo   = sys.argv[6];
    tableNameList  = sys.argv[7];
    LocalMysqlHostAddress = sys.argv[8];
    LocalMysqlUser = sys.argv[9];
    LocalMysqlPass = sys.argv[10];
    action_name    = sys.argv[11];
 
    """
    (wf_id, hostName, hivePortNo, hiveUserName, hivePassCode) = ('WF_kerberos_3', '10.94.191.203', 10000, "adityak@VIL.COM", "vil123")
    impalaPortNo = "21050"
    tableNameList ="t_lead"
    #tableNameList = "t_sr_type_dtls,t_srid_dtls_siebel,t_srid_dtls_siebel_fields,t_srid_dtls_siebel_srdtls,t_customer_lead,t_customer_lead_address,t_customer_lead_contact,t_lead,t_srid_dtls";
    #tableNameList="t_circle,t_orgname,t_source,t_workflow_status,t_workflow_dtls,t_surveys,t_survey_responses,t_survey_respondent_types,t_survey_respid_rel,t_tagged_messages,t_user,t_user_org_rel,t_workbasket,t_workflow_tat_dtls,t_user_notes,t_external_data_reporting,t_respondents,t_message_tag_dtls,t_response_types,t_role,t_sch_mess_accts,t_survey_profile_rel,t_survey_question_answers,t_survey_questions,t_srid_dtls,t_lead_social_accts,t_sch_messages,t_brand_profiles,t_lead,t_tags_new,t_sentiment_changed";
    (LocalMysqlHostAddress, LocalMysqlUser, LocalMysqlPass) = ('10.94.191.203', "root", "password")
    action_name='FileLevelValidation';
    """
except:
    traceback.print_exc();
    print "ERROR: Argument Expected, not given";
    sys.exit();
else:
    getKerberosTicket();
    ensureMysqlTableCreation();

    listOfEntireTableDetails = databaseCommunicator();

    listOfLastLoadDetails = loadLastLoadDetailsTableData();

    prepareMySQLConfTableData();

    listTableName = tableNameList.split(",");

    readInboxFiles();

    validateFiles();

    EndTime  = time.strftime("%Y%m%d-%H:%M:%S")
    #print "StartTime :", StartTime
    #print "EndTime   :", EndTime
