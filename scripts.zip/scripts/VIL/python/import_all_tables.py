#!/usr/bin/python
##################################################################################################
#       Name    : Sqoop import from mysql server( in archival)
#       Date    : 05-01-2017
#       Author  : Sahil Goyal
#       Version : 1.0
##################################################################################################

import impala.dbapi;
import pyhs2;
import subprocess;
import commands;
import sys;
import re;
import os;
import time;
import traceback;
import datetime;
import base64;
import commands
from pyhs2.error import Pyhs2Exception;
from impala.error import OperationalError
import MySQLdb;

StartTime = time.strftime("%Y%m%d-%H:%M:%S")

#### :: Sqoop Parameter List :: ####
wfId                = sys.argv[1];
mysqlDatabaseType   = sys.argv[2];
mysqlHostAddress    = sys.argv[3];
mysqlHostPortNumber = str(sys.argv[4]);
mysqlDatabaseUserName = sys.argv[5];
mysqlDatabasePassword    = base64.b64encode(sys.argv[6]);
mysqlDatabaseDriver      = sys.argv[7];
numberOfmapper      = str(sys.argv[8]);
tableNameList       = sys.argv[9];

#### :: Hive Connection Parameter :: ####
hiveHostName        = sys.argv[10];
hivePortNo          = sys.argv[11];
hiveUserName        = sys.argv[12];
hivePassCode        = sys.argv[13]; 
impalaPortNo        = sys.argv[14];
LocalMysqlHostAddress = sys.argv[15];
LocalMysqlUser      = sys.argv[16];
LocalMysqlPass      = sys.argv[17];
action_name         = sys.argv[18];
"""

#-----------------------------------------------------------------------------------------------------------------------------------
######################## :: Script Arguments for standalone run :: #########################
(wfId, mysqlDatabaseType, mysqlHostAddress, mysqlHostPortNumber) = ("WF_TEST123", "jdbc:mysql", "10.94.191.203", "3306")

(mysqlDatabaseUserName, mysqlDatabasePassword, mysqlDatabaseDriver, numberOfmapper) = ( "root", base64.b64encode("password"), "com.mysql.jdbc.Driver", "1")
#tableNameList = "t_tagged_messages";
tableNameList = "t_workflow_dtls,t_sr_type_dtls,t_srid_dtls_siebel,t_srid_dtls_siebel_fields,t_srid_dtls_siebel_srdtls,t_customer_lead,t_customer_lead_address,t_customer_lead_contact,t_lead,t_srid_dtls";

#### :: Hive Connection Parameter :: ####
(hiveHostName, hivePortNo, hiveUserName, hivePassCode) = ('10.94.191.203', 10000, "adityak@VIL.COM", "vil123")
(LocalMysqlHostAddress, LocalMysqlUser, LocalMysqlPass) = ('10.94.191.203', "root", "password")
(impalaPortNo) = (21050)

action_name  =   'SqoopImport';
"""

#### :: Process Details table Variables :: ####
error_code       = '';
error_type       = '';
process_status   = '';
errorMessage     = '';
targetHomeDir    = "/data/VIL/INBOX/";
auth_Mech        = "KERBEROS"


hiveConfigDb               = 'config_db'
mysqlConfigTable           = 'pre_archival_db_details'
mysqlConfigDb              = 'socio_config_db'
listOfPreArchivalDBDetails = [];




#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def getKerberosTicket():
        kinit_command = "/usr/bin/kinit "+hiveUserName;
        #print kinit_command;
        kinit = subprocess.Popen( kinit_command , shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);
        kinit.stdin.write(hivePassCode+"\n" );
        kinit.wait();
#----------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start databaseCommunicator() ::----------------------------------------------------------
def databaseCommunicator():
    global listOfPreArchivalDBDetails;
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor();
        cur.execute("use "+mysqlConfigDb);
        cur.execute("SELECT * FROM "+mysqlConfigDb+"."+mysqlConfigTable+" where wf_id = '"+wfId+"'")
        listOfPreArchivalDBDetails=cur.fetchone();
        cur.close();
        conn.close();
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: MySQL Connection not found"
        conn.close();
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------- :: Function Definition for ensureMysqlTableCreation :: ------------------------------------
def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    mysqlConfigDb = 'socio_config_db';
    mysqlTableName1 = 'last_load_details';
    mysqlTableName2 = 'process_details';
    mysqlTableName3 = 'pre_archival_db_details';

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);

        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]

        if mysqlTableName1 not in mysqlConfigTables :
            create_statement = ("CREATE TABLE IF NOT EXISTS socio_config_db.last_load_details(wf_id text, hive_table_name text, execution_date timestamp NULL, check_column_name text, last_value_imported text, incremental_mode_value text, status text)");
            cur.execute(create_statement);

        if mysqlTableName2 not in mysqlConfigTables :
            statement4=("CREATE TABLE IF NOT EXISTS socio_config_db.process_details(wf_id text, inboxfilenamewithext text, action_name text, date_time timestamp, error_code text, error_type text, error_message text,  file_checksum text, process_status text)");
            cur.execute(statement4);
            
        if mysqlTableName3 not in mysqlConfigTables :
            statement4=("CREATE TABLE IF NOT EXISTS socio_config_db.pre_archival_db_details (wf_id text,pre_archival_db_name text,source_federated_db_name text,executed_date text)");
            cur.execute(statement4);

        cur.close();
        conn.close();
    except:
        traceback.print_exc()
        print "ERROR: Mysql Connection not found"
        conn.close();
        sys.exit();

#----------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start loadLastLoadDetailsTableData() ::----------------------------------------------------------
def loadLastLoadDetailsTableData():
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor();

        cur.execute("use socio_config_db");
        query = ("select * from "+mysqlConfigDb+".last_load_details where wf_id =(select distinct wf_id from "+mysqlConfigDb+".last_load_details where execution_date =(select max(execution_date) from "+mysqlConfigDb+".last_load_details where status = \'SUCCESS\'))")
        #print query;
	cur.execute(query);
        listOfLastLoadDetails=cur.fetchall();
        #print "listOfLastLoadDetails ::: ",listOfLastLoadDetails;
        return listOfLastLoadDetails;
        cur.close();
        conn.close();
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: MySQL Connection not found"
        raise SystemExit;

#--------------------------------:: HDFSCommunicator() ::----------------------------------------------------------
def checkDirectory(targetDirectory):
    shell_command = "hdfs dfs -test -d "+targetDirectory+" && echo 'dir_exists' || echo 'no_such_dir'";
    #print shell_command;
    return commands.getstatusoutput(shell_command)[1];

#------------------------------------------------------------------------------------------------------------------------------

#--------------------------------:: Start insertDetailsInToProcessDetailsTable () ::-------------------------------------------
def insertDetailsInToProcessDetailsTable():
    DateTime = time.strftime('%Y-%m-%d %H:%M:%S'); 
    inboxfilenamewithext = 'NA'
    file_checksum = 'NA'

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass)
        cur  = conn.cursor();

        cur.execute("use socio_config_db");
        statement2=("INSERT INTO socio_config_db.process_details values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" % (wfId, inboxfilenamewithext, action_name, DateTime, error_code, error_type, error_message, file_checksum, process_status));
        cur.execute(statement2);
        cur.close();
        conn.close();
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: MySQL Connection not found"
        conn.close();
        raise SystemExit;


#------------------------------------------------------------------------------------------------------------------------------
############################################ :: Main Functions :: ##################################################
getKerberosTicket();
ensureMysqlTableCreation();
#print "tableNameList ::", tableNameList
listTableName = tableNameList.split(",");

databaseCommunicator();

if (listOfPreArchivalDBDetails is not None) :
    mysqlDatabaseName = listOfPreArchivalDBDetails[1];

######################## :: Connection Section :: #########################
connectionString = mysqlDatabaseType+"://"+LocalMysqlHostAddress+":"+mysqlHostPortNumber+"/"+mysqlDatabaseName+"?zeroDateTimeBehavior=convertToNull";
#print "mysqlDatabaseName ::",mysqlDatabaseName
#####################################################################################    


for tableName in listTableName:
    targetDirectory = targetHomeDir+tableName;
    Date_Time = datetime.datetime.now().strftime ("%Y%m%d-%H%M%S");
    ls_lines  = "";
    ls_errors = "";

    #### :: Added t_sr_type_dtls,t_srid_dtls_siebel,t_customer_lead,t_customer_lead_address t_customer_lead_contact####
    #### :: t_srid_dtls_siebel_fields and t_srid_dtls_siebel_srdtls need to confirm about extra field 'id'. Not added yet####

    if tableName in ('t_circle', 't_source', 't_workflow_status','t_brand_profiles','t_response_types','t_lead_social_accts','t_user_org_rel','t_srid_dtls','t_user_notes','t_workflow_tat_dtls','t_survey_profile_rel','t_message_tag_dtls','t_survey_responses','t_survey_respid_rel','t_external_data_reporting','t_tagged_messages','t_survey_respondent_types','t_sentiment_changed','t_workflow_dtls','t_sr_type_dtls','t_srid_dtls_siebel','t_customer_lead','t_customer_lead_address','t_customer_lead_contact','t_srid_dtls_siebel_srdtls','t_srid_dtls_siebel_fields'):
        checkColumnName      = 'id';
    elif tableName in ('t_orgname'):
        checkColumnName      = 'orgId';
    elif tableName in ('t_user'):
        checkColumnName      = 'userId';
    elif tableName in ('t_role'):
        checkColumnName      = 'roleId';
    elif tableName in ('t_workbasket'):
        checkColumnName      = 'basketId';
    elif tableName in ('t_surveys'):
        checkColumnName      = 'surveyId';
    elif tableName in ('t_survey_questions'):
        checkColumnName      = 'questionId';
    elif tableName in ('t_respondents'):
        checkColumnName      = 'respondentId';
    elif tableName in ('t_sch_mess_accts'):
        checkColumnName      = 'schMsgId';
    elif tableName in ('t_sch_messages'):
        checkColumnName      = 'schMsgId';
    elif tableName in ('t_survey_question_answers'):
        checkColumnName      = 'ansId';
    elif tableName in ('t_tags_new'):
        checkColumnName      = 'tagId';
    elif tableName in ('t_lead'):
        checkColumnName      = 'leadId';
    
    
    import_command = 'sqoop import --connect '+connectionString+' --username '+LocalMysqlUser+' --hive-drop-import-delims  '+' --query \' select * from '+tableName+' WHERE 1=1 AND $CONDITIONS order by '+checkColumnName+ "\'"+' --target-dir '+targetDirectory+' -m '+numberOfmapper+' --split-by '+checkColumnName+' --driver '+mysqlDatabaseDriver+' --fields-terminated-by '+"\'\b\'";

    dir_status = checkDirectory(targetDirectory);
    #print dir_status;    
    
    
    listOfLastLoadDetails = loadLastLoadDetailsTableData();
    listLastValueDetails = [];
    for row in range(0, len(listOfLastLoadDetails)):
        if tableName == listOfLastLoadDetails[row][1]:
            listLastValueDetails = listOfLastLoadDetails[row];
            #print "listOfLastLoadDetails::", listLastValueDetails;
    
    
    if (dir_status=="dir_exists" and len(listLastValueDetails) != 0):
        if(listLastValueDetails is not None):
            if((listLastValueDetails[4] != '') and 
            (tableName=='t_circle' or 
             tableName=='t_source' or 
             tableName=='t_orgname' or 
             tableName=='t_workflow_status' or             
             tableName=='t_user' or
             tableName=='t_user_org_rel' or
             tableName=='t_brand_profiles' or
             tableName=='t_tags_new' or
             tableName=='t_workbasket' or
             tableName=='t_role' or
             tableName=='t_response_types' or
             tableName=='t_survey_profile_rel' or
             tableName=='t_surveys' or
             tableName=='t_survey_questions' or
             tableName=='t_survey_question_answers' or
             tableName=='t_survey_respondent_types' or
             tableName=='t_external_data_reporting')):

                import_command = import_command+' --incremental '+listLastValueDetails[5]+' --check-column '+listLastValueDetails[3]+' --last-value 0';
            else:
                import_command = import_command+' --incremental '+listLastValueDetails[5]+' --check-column '+listLastValueDetails[3]+' --last-value 0';

    
    import_command = import_command+' --password '+LocalMysqlPass;
    
    ls_proc = subprocess.Popen([import_command], shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE);
    ls_lines = ls_proc.stdout.readlines()
    ls_errors = ls_proc.stderr.readlines()

    errorFlag = 0;
    for line in ls_errors:
        searchObj = re.search( r'.*(ERROR.*)', line)
        if searchObj:
            errorFlag = 1;
            error_message = searchObj.group(1);
            error_message = error_message.replace("\'","");
            #print error_message
            break;


    for line in ls_lines:
        searchObj = re.search( r'.*(ERROR.*)', line)
        if searchObj:
            errorFlag = 1;
            error_message = searchObj.group(1);
            error_message = error_message.replace("\'","");
            #print error_message
            break;

    if errorFlag == 1:
        log_file_name = "/data/VIL/log/workflow_import_"+tableName+"_"+Date_Time+".log"
        put = subprocess.Popen(["hadoop", "fs", "-put", "-", log_file_name], stdin=subprocess.PIPE, bufsize=-1)

        put.stdin.write("import_command :: "+import_command+"\n")
        for line in ls_lines:
            put.stdin.write(line)
        for line in ls_errors:
            put.stdin.write(line)
        put.stdin.close()
        error_code = 'WF004';
        error_type = 'Major';
        process_status = 'FAIL';
        insertDetailsInToProcessDetailsTable();
        print"Sqoop_Import=FAILED";
        print error_message;
        raise SystemExit;


    if errorFlag == 0:
        error_code = 'NA';
        error_type = 'INFO';
        process_status = 'PASS';
        error_message="Import sucessful for table :: "+tableName;
        insertDetailsInToProcessDetailsTable();

    ls_proc.stdout.close(); 
    tableImportTime = time.strftime("%Y%m%d-%H:%M:%S")   
    #print"Import End time for table ::", tableImportTime


   


EndTime  = time.strftime("%Y%m%d-%H:%M:%S") 
#print "StartTime :", StartTime
#print "EndTime   :", EndTime











