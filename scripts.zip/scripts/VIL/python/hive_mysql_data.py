#!/usr/bin/python
##################################################################################################
#       Name    : Hive Script running.
#       Desc    : This Script takes wfid as CLI argument and execute all hive script related to socio data
#       Date    : 05-07-2016
#       Version : 1.0
##################################################################################################

import impala.dbapi
import sys
import commands
import pyhs2 as hive
import getpass
import datetime
import subprocess
import traceback;
import time;
from subprocess import Popen, PIPE, STDOUT
from pyhs2.error import Pyhs2Exception;
import MySQLdb;

### Script Parameter List ###
wf_id          = sys.argv[1];
hostName       = sys.argv[2];
hivePortNo     = sys.argv[3];
hiveUserName   = sys.argv[4];
hivePassCode   = sys.argv[5];
hiveScriptLocation = sys.argv[6];
tableNameList  = sys.argv[7];
impalaPortNo   = sys.argv[8];
beeline_driver = sys.argv[9];
hive_principal = sys.argv[10];

#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress = sys.argv[11];
LocalMysqlUser        = sys.argv[12];
LocalMysqlPass        = sys.argv[13];
action_name           = sys.argv[14];

"""
(wf_id, hostName, hivePortNo, hiveUserName, hivePassCode) = ('0000002-170512185109565-oozie-oozi-W', '10.94.185.240', 10000, "daadmin@VIL.COM", "vil123")
hiveScriptLocation = "../hive" 
impalaPortNo  = 21050;
#tableNameList ="t_circle,t_orgname,t_source,t_workflow_status,t_workflow_dtls,t_surveys,t_survey_responses,t_survey_respondent_types,t_survey_respid_rel,t_tagged_messages,t_user,t_user_org_rel,t_workbasket,t_workflow_tat_dtls,t_user_notes,t_external_data_reporting,t_respondents,t_message_tag_dtls,t_response_types,t_role,t_sch_mess_accts,t_survey_profile_rel,t_survey_question_answers,t_survey_questions,t_srid_dtls,t_lead_social_accts,t_sch_messages,t_brand_profiles,t_lead,t_tags_new,t_sentiment_changed"

#tableNameList ="t_user,t_orgname,t_user_org_rel,t_brand_profiles,t_circle,t_survey_questions,t_lead,t_workflow_dtls"
tableNameList ="t_user"
beeline_driver ="jdbc:hive2://dc3prdgenarc03.internal.vodafone.com:10000"
hive_principal="hive/dc3prdgenarc03.internal.vodafone.com@VIL.COM"

#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress = "10.94.185.240"
LocalMysqlUser = "root"
LocalMysqlPass = "password"
action_name='MysqlDataArchival'
"""

DEFAULT_DB = 'default'
ArchivalDB = 'socio_db';
mysqlConfigDb = 'socio_config_db';
StaggingDB = 'socio_stg_db';


#mysql staging DB
mysqlTarget='mysql_poc'


auth_Mech   = "KERBEROS"

listOfArichivalDBTables = ''; 
start_time = datetime.datetime.now().replace(microsecond=0);
TableList  = [];
stagTableList = [];
process_dir_dic = {};
staging_table_dic = {};
old_archival_table_dic = {};
archival_table_dic = {};
archived_count_dic = {};
checksum_dic = {};
process_path = "/data/VIL/process"
mysqlTableList = tableNameList.split(",");
date_time = time.strftime("%Y%m%d_%H%M%S")

#print mysqlTableList;


#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def getKerberosTicket():
        kinit_command = "/usr/bin/kinit "+hiveUserName;
        #print kinit_command;
        kinit = subprocess.Popen( kinit_command , shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);
        kinit.stdin.write(hivePassCode+"\n" );
        kinit.wait();
#----------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------
def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    mysqlConfigDb = 'socio_config_db';
    mysqlTableName1 = 'process_details';
    mysqlTableName2 = 'socio_dq_summ_table';
    
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);

        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]
        if mysqlTableName1 not in mysqlConfigTables :
            statement1=("CREATE TABLE IF NOT EXISTS "+mysqlConfigDb+".process_details(wf_id text, inboxfilenamewithext text, action_name text, date_time timestamp, error_code text, error_type text, error_message text,  file_checksum text, process_status text)");
            cur.execute(statement1);
        
        if mysqlTableName2 not in mysqlConfigTables :
            statement4 = ("CREATE TABLE IF NOT EXISTS "+mysqlConfigDb+".socio_dq_summ_table (wf_id text, table_name text,file_row_count bigint,  archived_row_count bigint, checksum text)");
            cur.execute(statement4);
            
        cur.close();
        conn.close();
    except:
        traceback.print_exc();
        conn.close();
        print "ERROR: MySql Connection not found";
        raise SystemExit;
#-----------------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------------
# Build the MySql Connection
def databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,status):
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
        cur  = conn.cursor();
        
        statement1=("INSERT INTO "+mysqlConfigDb+".process_details values ('"+wf_id+"','"+file_name+"','"+ action_name+"','"+str(date_time)+"','"+ error_code+"','"+ error_type+"',\""+ error_message+"\",'"+ file_checksum+"','"+status+"')");
        #print statement1;
        cur.execute(statement1);
            
    except Exception as error:
        traceback.print_exc()
        print "ERROR: MySql Connection not found"
        conn.close();
        raise SystemExit;

#--------------------------------:: Start databaseCommunicator() ::----------------------------------------------------------
def databaseCommunicator(databse_name):
    try:
        conn = hive.connect(host=hostName, port=hivePortNo, authMechanism=auth_Mech, user=hiveUserName, password=hivePassCode, database=databse_name); 
        cur  = conn.cursor();
        cur.execute("show tables");
        listOfDBTables=cur.fetchall();
        cur.close();
        conn.close();
        return listOfDBTables;
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: Hive Connection not found"
        conn.close();
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
def executeScript(scriptName):
    #print"INFO: Executing "+scriptName+" Script";
    for_out= "";
    file_name = scriptName;
    date_time = datetime.datetime.now().replace(microsecond=0);
    file_checksum = "NA"
    try:
        cmd = "hive -f "+hiveScriptLocation+"/"+scriptName;
        prc = subprocess.Popen(cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True);
        output = prc.stderr.read();
        for_out = output.split('\n')[-2];
        #print for_out;

        if 'Time taken:' not in for_out:
            raise Execption;

    except:
        error_code = "WF012";
        error_type = "CRITICAL";
        date_time = datetime.datetime.now().replace(microsecond=0);
        message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,for_out,file_checksum,"FAIL");
        print "MySQL_DataArchival=FAILED";
        print for_out;
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------

#------------------------------------------------------------------------------------------------------------------------------
def checkRowCountDraVsDaa():
    global archival_table_dic;
    global archived_count_dic;
    try:
        conn = hive.connect(host=hostName, port=hivePortNo, authMechanism=auth_Mech, user=hiveUserName, password=hivePassCode, database=DEFAULT_DB); 
        cur  = conn.cursor();

        for tableName in mysqlTableList:
            archival_table_row_count = '';

            try :
                
                #To populate archived table new_row_count from hive table
                optimize_statement1 = "set hive.cbo.enable=true"
                cur.execute(optimize_statement1);
                
                optimize_statement2 = "set hive.compute.query.using.stats=true"
                cur.execute(optimize_statement2);
                
                optimize_statement3 = "set hive.stats.fetch.column.stats=true"
                cur.execute(optimize_statement3);
                
                optimize_statement4 = "set hive.stats.fetch.partition.stats=true"
                cur.execute(optimize_statement4);
                
                statement2 = "select count(*) from "+ArchivalDB+"."+tableName;
                #print statement2;
                cur.execute(statement2);
                archival_table_row_count = cur.fetchone()[0];
                #print "Archival table Row Count for table "+tableName+"  :: "+str(archival_table_row_count);
                archival_table_dic[tableName] = archival_table_row_count;
                
                #print "Old Archival table Row Count for table "+tableName+"  :: "+str(old_archival_table_dic[tableName]);
                archived_count_dic[tableName] = (archival_table_row_count-old_archival_table_dic[tableName])
                #print tableName;
                #print str(archived_count_dic[tableName])

                if (process_dir_dic[tableName] == archived_count_dic[tableName])  :
                    continue ;
                else :
                    error_string = "Row Count in external table : "+tableName +" does not match the row count in archival table : "+tableName;
                    cur.close();
                    conn.close();
                    return error_string;
                
            except Pyhs2Exception as error:
                return str(error);
        cur.close();
        conn.close();
        return "SUCCESS";
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: Hive Connection not found"
        conn.close();
        raise SystemExit;

#------------------------------------------------------------------------------------------------------------------------------
def checkRowCountBeforeArchival():
    global old_archival_table_dic;
    global process_dir_dic;
    global checksum_dic;
    date_time = time.strftime("%Y%m%d_%H%M%S")
    for tableName in mysqlTableList:
        try :
            conn = hive.connect(host=hostName, port=hivePortNo, authMechanism=auth_Mech, user=hiveUserName, password=hivePassCode, database=DEFAULT_DB); 
            cur  = conn.cursor();
            date_time = time.strftime("%Y%m%d_%H%M%S") 
            #DQSummaryFile = tableName+"_"+str(date_time);
            #subprocess.Popen("mkdir -p /tmp/DQ_Summary/", shell=True, stdout=subprocess.PIPE)
            #subprocess.Popen("chmod 777 /tmp/DQ_Summary/", shell=True, stdout=subprocess.PIPE)
            #subprocess.Popen("touch /tmp/DQ_Summary/"+DQSummaryFile, shell=True, stdout=subprocess.PIPE)
            #ls_proc = subprocess.Popen(["hadoop", "fs", "-getmerge", "/data/VIL_POC/process/"+tableName+"/", "/tmp/DQ_Summary/"+DQSummaryFile], stdout=subprocess.PIPE)    
            #ls_proc.stdout.readlines();    
            #filePath = "/tmp/DQ_Summary/"+DQSummaryFile;
            ##print "Merged File Path :: ",filePath;
            #ls_lines = int(commands.getoutput("cat "+filePath+" | wc -l"))
            ##print "File Row Count for table "+tableName+"  :: "+str(ls_lines);
            #process_dir_dic[tableName] = ls_lines;
            #
            #checksum = int(commands.getoutput("cksum /tmp/DQ_Summary/"+DQSummaryFile+" | cut -d ' ' -f1"))
            checksum_dic[tableName] = " ";
            #print "CheckSum of File ::", checksum
                
            
            #To populate archived table old_row_count from hive table
            optimize_statement1 = "set hive.cbo.enable=true"
            cur.execute(optimize_statement1);
            
            optimize_statement2 = "set hive.compute.query.using.stats=true"
            cur.execute(optimize_statement2);
            
            optimize_statement3 = "set hive.stats.fetch.column.stats=true"
            cur.execute(optimize_statement3);
            
            optimize_statement4 = "set hive.stats.fetch.partition.stats=true"
            cur.execute(optimize_statement4);
            
            statement3 = "select count(*) from "+StaggingDB+"."+tableName;
            #print statement3;
            cur.execute(statement3);
            ls_lines = cur.fetchone()[0];
            #print "File Row Count for table "+tableName+"  :: "+str(ls_lines);
            
            process_dir_dic[tableName] = ls_lines;
            #print old_archival_table_dic;
            
            
            statement2 = "select count(*) from "+ArchivalDB+"."+tableName;
            #print statement2;
            cur.execute(statement2);
            old_archival_table_row_count = cur.fetchone()[0];
            #print "Archival table Row Count for table "+tableName+"  :: "+str(old_archival_table_row_count);
            
            old_archival_table_dic[tableName] = old_archival_table_row_count;
            #print old_archival_table_dic;
            
            cur.close();
            conn.close();
            
        except Pyhs2Exception as error:
            return str(error); 
            
    return "SUCCESS";
#-------------------------------------------:: Insert Function ::---------------------------------------------------------------------------------
def insertIntoDqSumm() :
    
    try:
        for tableName in mysqlTableList:
            try:
                #print tableName+" : process  : "+ str(process_dir_dic[tableName]);
                #print tableName+" : staging  : "+ str(staging_table_dic[tableName]);
                #print tableName+" : archival : "+ str(archived_count_dic[tableName]);
                #print tableName+" : checksum : "+ str(checksum_dic[tableName]);
                 
                conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
                cur  = conn.cursor();
                statement3 = ("INSERT INTO "+mysqlConfigDb+".socio_dq_summ_table values ( '%s', '%s', %d, %d, '%s')" % (wf_id, tableName, process_dir_dic[tableName], archived_count_dic[tableName], checksum_dic[tableName]));

                #print "Executing Hive Query :: ",statement3;
                cur.execute(statement3);
                cur.close();
                conn.close();
            except:
                traceback.print_exc()
                print "ERROR: MySql Connection not found"
                conn.close();
                raise SystemExit;

        error_code = "NA";
        error_type = "INFO";
        error_message = 'MySql data validated successfully'
        file_checksum = 'NA'; 
        status = 'PASS';
        date_time = time.strftime('%Y-%m-%d %H:%M:%S');

        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
        cur  = conn.cursor();
        statement1=("INSERT INTO "+mysqlConfigDb+".process_details values ('"+wf_id+"','NA','"+ action_name+"','"+str(date_time)+"','"+ error_code+"','"+ error_type+"',\""+ error_message+"\",'"+ file_checksum+"','"+status+"')");
        cur.execute(statement1);
        cur.close();
        conn.close();

    except Exception as error:
        traceback.print_exc()
        print "ERROR: MySql Connection not found"
        conn.close();
        raise SystemExit;
#-------------------------------------------------------------------------------------------------------------------------------------------------    


#----------------------------------------------:: Deleting part files from process Function ::----------------------------------------------------- 
def removePartFilesFromProcess(mysqlTableList) :
    for tableName in mysqlTableList :
        readline1="hadoop fs -rm -r -skipTrash "+process_path+"/"+tableName+"/part-m-*"
        status, output=commands.getstatusoutput(readline1);

#--------------------------------------------------------------------------------------------------------------------------------------------------    
    
#-------------------------------------------:: Main Function ::-------------------------------------------------------------------------------------
getKerberosTicket();
ensureMysqlTableCreation();

scriptName_databases = "create_databases.hql"
executeScript(scriptName_databases);

archivalTableList = databaseCommunicator(ArchivalDB);

for row in range(0, len(archivalTableList)):
    TableList.append(archivalTableList[row][0])

#print "Archival table Name:", TableList


for tableName in mysqlTableList:

    if tableName not in TableList :
        create_table_script = "create_"+tableName+".hql"
        executeScript(create_table_script);
        #print "In ELSE create Part";
        error_message = "Tables corresponding to "+tableName+" created successfully";
        #print error_message;
        file_name = 'NA'
        date_time = datetime.datetime.now().replace(microsecond=0);
        file_checksum = "NA"
        error_code = "NA";
        error_type = "INFO";
        message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,"PASS");
        continue;
    else:
        error_message = "Tables corresponding to "+tableName+" already exists";
        #print error_message;
        file_name = 'NA'
        date_time = datetime.datetime.now().replace(microsecond=0);
        file_checksum = "NA"
        error_code = "WF013";
        error_type = "WARNING";
        message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,"PASS");
        continue;

# save row count of archival table before current archival;
checkRowCountBeforeArchival();

# move data from external tables to final archival tables
for tableName in mysqlTableList:
    scriptName_archival = tableName+".hql"
    print"INFO: Executing "+scriptName_archival+" Script";
    executeScript(scriptName_archival);

file_name = 'NA';
error_code = "NA";
error_type = "INFO";
error_message = "data moved to archival tables successfully";
date_time = datetime.datetime.now().replace(microsecond=0);

#print "INFO:",error_message;

file_checksum = "NA"
message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,"PASS");
#print message;

return_message = checkRowCountDraVsDaa();
#print return_message;
if (return_message == "SUCCESS") :
    error_code = "NA";
    error_type = "INFO";
    error_message = "Row Count from external tables and Archival tables matches ";
    file_name = 'NA';
    date_time = datetime.datetime.now().replace(microsecond=0);
    file_checksum = "NA";
    message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,"PASS");
    
else :
    error_code = "WF014";
    error_type = "MAJOR";
    error_message = return_message;
    file_name = 'NA';
    date_time = datetime.datetime.now().replace(microsecond=0);
    file_checksum = "NA";
    message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,"FAIL");
    print "MySQL_DataArchival=FAILED";
    print return_message;
    raise SystemExit;

            
insertIntoDqSumm();

removePartFilesFromProcess(mysqlTableList);            
end_time = datetime.datetime.now().replace(microsecond=0);

#print"Start Time :: ",start_time
#print"End Time   :: ",end_time










