#!/usr/bin/python
##################################################################################################
#       Name    : Hive Script running.
#       Desc    : This Script takes wfid as CLI argument and execute all hive script related to socio data
#       Date    : 05-07-2016
#       Version : 1.0
##################################################################################################

import impala.dbapi
import sys
import commands
import pyhs2 as hive
import getpass
import datetime
import time;
import traceback;
import datetime;
import base64;
import commands;
import MySQLdb;
import subprocess;
from subprocess import Popen, PIPE, STDOUT
from pyhs2.error import Pyhs2Exception;


StartTime = time.strftime("%Y%m%d-%H:%M:%S")

### Script Parameter List ###
wf_id          = sys.argv[1];
hostName       = sys.argv[2];
hivePortNo     = sys.argv[3];
hiveUserName   = sys.argv[4];
hivePassCode   = sys.argv[5];
hiveScriptLocation = sys.argv[6];
json_jar_path  = sys.argv[7];
impalaPortNo   = sys.argv[8];

#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress = sys.argv[9];
LocalMysqlUser        = sys.argv[10];
LocalMysqlPass        = sys.argv[11];

"""
(wf_id, hostName, hivePortNo, hiveUserName, hivePassCode) = ('WFTest_staging_remove', '10.94.191.203', 10000, "adityak@VIL.COM", "vil123");
json_jar_path = "../lib/hive-hcatalog-core.jar";
hiveScriptLocation = "../hive";
impalaPortNo = 21050;

#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress = "10.94.191.203"
LocalMysqlUser = "root"
LocalMysqlPass = "password"
"""

DEFAULT_DB = 'default'
ArchivalDB = 'socio_db';
mysqlConfigDb = 'socio_config_db';
old_archival_table_count = 0;
listOfArichivalDBTables = '';
socio_tbl  = 't_socio';
auth_Mech   = "KERBEROS"
start_time = datetime.datetime.now().replace(microsecond=0);
TableList  = [];
process_dir_dic = {};
staging_table_dic = {};
archival_table_dic = {};
archived_count_dic = {};
checksum_dic = {};
process_path = "/data/VIL/process"
socioTableList = socio_tbl.split(",");
date_time = time.strftime("%Y%m%d_%H%M%S")
#hiveConfigDb     = 'socio_config_db'

script_name_dic = ["create_socio_dra_table.hql", "create_daa_socio_table.hql","dra_stg_to_daa_socio_data_loading.hql" ]
success_message = ["Socio DRA tables created successfully", "Socio Archival tables created successfully" , "Socio data loaded from external tables to Archival tables successfully" ]

#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def getKerberosTicket():
        kinit_command = "/usr/bin/kinit "+hiveUserName;
        #print kinit_command;
        kinit = subprocess.Popen( kinit_command , shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);
        kinit.stdin.write(hivePassCode+"\n" );
        kinit.wait();
#----------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------
def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    mysqlConfigDb = 'socio_config_db';
    mysqlTableName1 = 'process_details';
    mysqlTableName2 = 'socio_dq_summ_table';
    
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);

        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]
        if mysqlTableName1 not in mysqlConfigTables :
            statement1=("CREATE TABLE IF NOT EXISTS "+mysqlConfigDb+".process_details(wf_id text, inboxfilenamewithext text, action_name text, date_time timestamp, error_code text, error_type text, error_message text,  file_checksum text, process_status text)");
            cur.execute(statement1);
        
        if mysqlTableName2 not in mysqlConfigTables :
            statement4 = ("CREATE TABLE IF NOT EXISTS "+mysqlConfigDb+".socio_dq_summ_table (wf_id text, table_name text,file_row_count bigint, archived_row_count bigint, checksum text)");
            cur.execute(statement4);
            
        cur.close();
        conn.close();
    except:
        traceback.print_exc();
        conn.close();
        print "ERROR: MySql Connection not found";
        raise SystemExit;
#-----------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------------------
# Build the MySql Connection
def databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,status):
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
        cur  = conn.cursor();
        
        statement1=("INSERT INTO "+mysqlConfigDb+".process_details values ('"+wf_id+"','"+file_name+"','"+ action_name+"','"+str(date_time)+"','"+ error_code+"','"+ error_type+"',\""+ error_message+"\",'"+ file_checksum+"','"+status+"')");
        #print statement1;
        cur.execute(statement1);
            
    except Exception as error:
        traceback.print_exc()
        print "ERROR: MySql Connection not found"
        conn.close();
        raise SystemExit;

#--------------------------------:: Start databaseCommunicator() ::----------------------------------------------------------
def databaseCommunicator():
    try:
        conn = hive.connect(host=hostName, port=hivePortNo, authMechanism=auth_Mech, user=hiveUserName, password=hivePassCode, database=ArchivalDB);
        cur  = conn.cursor();
        cur.execute("show tables");
        listOfArichivalDBTables=cur.fetchall();
        cur.close();
        conn.close();
        return listOfArichivalDBTables;
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: Hive Connection not found"
        conn.close();
        raise SystemExit;
        
        
#------------------------------------------------------------------------------------------------------------------------------
def checkRowCountDraVsDaa():

    global archival_table_dic;
    global archived_count_dic;

    try:
        conn = hive.connect(host=hostName, port=hivePortNo, authMechanism=auth_Mech, user=hiveUserName, password=hivePassCode, database=DEFAULT_DB);
        cur  = conn.cursor();
        for tableName in socioTableList:
            archival_table_row_count = '';
            staging_table_row_count = '';
            try :
               
                #To populate archived table row_count from hive table
                statement2 = "select count(*) from "+ArchivalDB+"."+tableName;
                #print statement2;
                cur.execute(statement2);
                archival_table_row_count = cur.fetchone()[0];
                #print "Archival table Row Count for table "+tableName+"  :: "+str(archival_table_row_count);
                archival_table_dic[tableName] = archival_table_row_count;

                archived_count_dic[tableName] = 0;

                #print "Old Archival table Row Count for table "+tableName+"  :: "+str(old_archival_table_count);
                archived_count_dic[tableName] = archival_table_row_count - old_archival_table_count;

                if (process_dir_dic[tableName] == archived_count_dic[tableName] ) :
                    continue ;
                else :
                    error_string = "Row Count in external table : "+tableName+"_stg does not match the row count in archival table : "+tableName;
                    cur.close();
                    conn.close();
                    return error_string;
                
            except Pyhs2Exception as error:
                return str(error);                 
        cur.close();
        conn.close();
        return "SUCCESS";
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: Hive Connection not found"
        conn.close();
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
def checkRowCountBeforeArchival():
    global old_archival_table_count;
    global staging_table_dic;
    global process_dir_dic;
    global checksum_dic;
    
    try:
        conn = hive.connect(host=hostName, port=hivePortNo, authMechanism=auth_Mech, user=hiveUserName, password=hivePassCode, database=DEFAULT_DB);
        cur  = conn.cursor();
        for tableName in socioTableList:
            staging_table_row_count = '';

            try :
           
                date_time = time.strftime("%Y%m%d_%H%M%S");
                
                DQSummaryFile = tableName+"_"+str(date_time);
                subprocess.Popen("mkdir -p /tmp/DQ_Summary/", shell=True, stdout=subprocess.PIPE)
                subprocess.Popen("chmod 777 /tmp/DQ_Summary/", shell=True, stdout=subprocess.PIPE)
                subprocess.Popen("touch /tmp/DQ_Summary/"+DQSummaryFile, shell=True, stdout=subprocess.PIPE)
                ls_proc = subprocess.Popen(["hadoop", "fs", "-getmerge", "/data/VIL/process/"+tableName.upper()+"/", "/tmp/DQ_Summary/"+DQSummaryFile], stdout=subprocess.PIPE)    
                ls_proc.stdout.readlines();    
                filePath = "/tmp/DQ_Summary/"+DQSummaryFile;
                #print "Merged File Path :: ",filePath;
                ls_lines = int(commands.getoutput("cat "+filePath+" | wc -l"))
                #print "File Row Count for table "+tableName+"  :: "+str(ls_lines);
                process_dir_dic[tableName] = ls_lines;
                
                
                checksum = int(commands.getoutput("cksum /tmp/DQ_Summary/"+DQSummaryFile+" | cut -d ' ' -f1"))
                checksum_dic[tableName] = checksum;
                #print "CheckSum of File ::", checksum
                    
                
                #To populate archived table old_row_count from hive table
                statement2 = "select count(*) from "+ArchivalDB+"."+tableName;
                #print statement2;
                cur.execute(statement2);
                old_archival_table_count = cur.fetchone()[0];
                #print "old_archival_table_count :: ",old_archival_table_count;
                
            except Exception as error:
                return str(error);                 
        cur.close();
        conn.close();
        return "SUCCESS";
    except Pyhs2Exception as error:
        traceback.print_exc()
        print "ERROR: Hive Connection not found"
        conn.close();
        raise SystemExit;
#-------------------------------------------:: Insert Function ::---------------------------------------------------------------------------------
def insertIntoDqSumm() :
    
    try:
        for tableName in socioTableList:
            try:
                #print tableName+" : process  : "+ str(process_dir_dic[tableName]);
                #print tableName+" : staging  : "+ str(staging_table_dic[tableName]);
                #print tableName+" : archival : "+ str(archival_table_dic[tableName]);
                #print tableName+" : checksum : "+ str(checksum_dic[tableName]);
                        
                conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
                cur  = conn.cursor();
                statement3 = ("INSERT INTO "+mysqlConfigDb+".socio_dq_summ_table values ( '%s', '%s', %d, %d, '%s')" % (wf_id, tableName, process_dir_dic[tableName], archived_count_dic[tableName], str(checksum_dic[tableName])));
                #print "Executing Hive Query :: ",statement3;
                cur.execute(statement3);
                cur.close();
                conn.close();
            except:
                traceback.print_exc()
                print "ERROR: MySql Connection not found"
                conn.close();
                raise SystemExit;
    
        action_name = 'SocioDataArchival';
        error_code = "NA";
        error_type = "INFO";
        error_message = 'Socio data validated successfully'
        file_checksum = 'NA'; 
        status = 'PASS';
        date_time = time.strftime('%Y-%m-%d %H:%M:%S');

        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
        cur  = conn.cursor();
        statement1=("INSERT INTO "+mysqlConfigDb+".process_details values ('"+wf_id+"','NA','"+ action_name+"','"+str(date_time)+"','"+ error_code+"','"+ error_type+"',\""+ error_message+"\",'"+ file_checksum+"','"+status+"')");
        cur.execute(statement1);
        cur.close();
        conn.close();

    except Exception as error:
        traceback.print_exc()
        print "ERROR: MySql Connection not found"
        conn.close();
        raise SystemExit;
#-------------------------------------------------------------------------------------------------------------------------------------------------    


#----------------------------------------------:: Deleting part files from process Function ::----------------------------------------------------- 
def removePartFilesFromProcess() :
    readline1="hadoop fs -rm -r -skipTrash "+process_path+"/*/*.[jJ][sS][oO][nN]*"
    status, output=commands.getstatusoutput(readline1);

#-------------------------------------------------------------------------------------------------------------------------------------------------- 
#------------------------------------------------------------------------------------------------------------------------------
def executeScript(scriptName):
    for_out= "";
    file_name = 'NA';
    action_name='SocioDataArchival'
    date_time = datetime.datetime.now().replace(microsecond=0);
    file_checksum = "NA"
    try:  
        cmd = "hive -f "+hiveScriptLocation+"/"+scriptName+ " -define jar_path="+json_jar_path;
        prc = subprocess.Popen(cmd, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True);
        output = prc.stderr.read();
        for_out = output.split('\n')[-2];
        #print for_out;

        if 'Time taken:' in for_out:
            error_code = "NA";
            error_type = "INFO";
            error_message = success_message[script_name_dic.index(scriptName)];
            #print "INFO:",error_message;
            message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,"PASS");
            #print message;


        else:
            raise Execption;

    except:
        error_code = "WF012";
        error_type = "ERROR";
        message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,for_out,file_checksum,"FAIL");
        print "Social_DataArchival=FAILED";
        print for_out;
        raise SystemExit;
    

#---------------------------------------------------------------------------------------------
getKerberosTicket();
ensureMysqlTableCreation();
for key in script_name_dic :
    #print"INFO: Executing "+key+" Script";
    if key == "create_daa_socio_table.hql" :
        checkRowCountBeforeArchival();
        archivalTableList = databaseCommunicator();
        for row in range(0, len(archivalTableList)):
            TableList.append(archivalTableList[row][0])
        #print "Archival table Name:", TableList
        try:
            j = TableList.index(socio_tbl);
            if j >= 0:
                #print "j ::", j
                error_message = socio_tbl+" already exists";
                file_name = 'NA'
                action_name='SocioDataArchival'
                date_time = datetime.datetime.now().replace(microsecond=0);
                file_checksum = "NA"
                error_code = "WF013";
                error_type = "WARNING";
                message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,"PASS");
            
        except:
            executeScript(key);
            #print "In Except Part";
    else:
        executeScript(key);
        #print "In ELSE Part";
        
    if key == "dra_stg_to_daa_socio_data_loading.hql" :
        return_message = checkRowCountDraVsDaa();
        if (return_message == "SUCCESS") :
            error_code = "NA";
            error_type = "INFO";
            error_message = "Row Count from external tables and Archival tables matches ";
            file_name = 'NA';
            action_name='SocioDataArchival'
            date_time = datetime.datetime.now().replace(microsecond=0);
            file_checksum = "NA";
            message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,"PASS");
            
        else :
            error_code = "WF014";
            error_type = "MAJOR";
            error_message = return_message;
            file_name = 'NA';
            action_name='SocioDataArchival'
            date_time = datetime.datetime.now().replace(microsecond=0);
            file_checksum = "NA";
            message = databaseInsert(wf_id,file_name,action_name,date_time,error_code,error_type,error_message,file_checksum,"FAIL");
            print "Social_DataArchival=FAILED";
            print return_message;
            raise SystemExit;

            
insertIntoDqSumm();
removePartFilesFromProcess();          


EndTime  = time.strftime("%Y%m%d-%H:%M:%S") 
#print "StartTime :", StartTime
#print "EndTime   :", EndTime






