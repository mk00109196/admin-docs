#!/usr/bin/python
##################################################################################################
#       Name    : checking neccaessary JSON file and mysql credentials
#       Date    : 03-09-2016
#       Author  : Sahil Goyal
#       Version : 1.0
##################################################################################################

 
import pyhs2;
import impala.dbapi;
import subprocess;
import commands;
import sys;
import re;
import os;
import time;
import traceback;
import datetime;
import base64;
import commands;
import MySQLdb;

StartTime = time.strftime("%Y%m%d-%H:%M:%S")


#### :: Sqoop Parameter List :: ####
wfId        	 = sys.argv[1];
MysqlDatabaseType     = sys.argv[2];
MysqlHostAddress      = sys.argv[3];
MysqlHostPortNumber   = str(sys.argv[4]);
MysqldatabaseName     = sys.argv[5];
databaseUserName = sys.argv[6];
databasePassword = base64.b64encode(sys.argv[7]);
databaseDriver   = sys.argv[8];

#### :: Hive Connection Parameter :: ####
hostName         = sys.argv[9];
hivePortNo       = sys.argv[10];
hiveUserName     = sys.argv[11];
hivePassCode     = sys.argv[12]; 
impalaPortNo     = sys.argv[13];

#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress = sys.argv[14];
LocalMysqlUser        = sys.argv[15];
LocalMysqlPass         = sys.argv[16];

"""

######################## :: Script Arguments for standalone run :: #########################
(wfId, MysqlDatabaseType, MysqlHostAddress, MysqlHostPortNumber, MysqldatabaseName)      = ("WF_TEST_mysql", "jdbc:mysql", "10.94.191.202", "3306", "mysql_source")
(databaseUserName, databasePassword, databaseDriver, numberOfmapper) = ( "root", base64.b64encode("password"), "com.mysql.jdbc.Driver", "1")

#### :: Hive Connection Parameter :: ####
(hostName, hivePortNo, hiveUserName, hivePassCode) = ('10.94.191.203', 10000, "adityak@VIL.COM", "vil123")
impalaPortNo = 21050;

#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress = "10.94.191.202"
LocalMysqlUser = "root"
LocalMysqlPass = "password"
"""



################################################################################################

################################# :: MySql Connection String :: #######################################
connectionString = MysqlDatabaseType+"://"+MysqlHostAddress+":"+MysqlHostPortNumber+"/"+MysqldatabaseName+"?zeroDateTimeBehavior=convertToNull";
Date_Time = datetime.datetime.now().strftime ("%Y%m%d-%H%M%S");
mysqlConfigDb    = "socio_config_db"
hiveConfigDb     = 'socio_config_db'
auth_Mech        = "KERBEROS"
########################################################################################################


#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def getKerberosTicket():
        kinit_command = "/usr/bin/kinit "+hiveUserName;
        #print kinit_command;
        kinit = subprocess.Popen( kinit_command , shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);
        kinit.stdin.write(hivePassCode+"\n" );
        kinit.wait();
#----------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------
def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    mysqlConfigDb = 'socio_config_db';
    mysqlTableName1 = 'process_details';
    
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);

        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]
        if mysqlTableName1 not in mysqlConfigTables :
            statement1=("CREATE TABLE IF NOT EXISTS socio_config_db.process_details(wf_id text, inboxfilenamewithext text, action_name text, date_time timestamp, error_code text, error_type text, error_message text,  file_checksum text, process_status text)");
            cur.execute(statement1);

        cur.close();
        conn.close();
    except:
        traceback.print_exc();
        conn.close();
        print "ERROR: MySql Connection not found";
        raise SystemExit;
#-----------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def insertDetailsInToProcessDetailsTable(error_code,error_type,error_message,process_status):
    action_name='CheckPrerequisite';
    inboxfilenamewithext = 'NA'
    file_checksum = 'NA'
    Date_Time = time.strftime('%Y-%m-%d %H:%M:%S');

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass, db=mysqlConfigDb);
        cur  = conn.cursor();    
     
        statement2=("INSERT INTO socio_config_db.process_details values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" % (wfId, inboxfilenamewithext, action_name, Date_Time, error_code, error_type, error_message, file_checksum, process_status));
        #print statement2;
        cur.execute(statement2);
        cur.close();
        conn.close();

    except:
        traceback.print_exc();
        conn.close();
        print "ERROR: MySql Connection not found";
        raise SystemExit;
#---------------------------------------------------------------------------------------------------------------

#################################: MySql checking : ##################################################
def mysqlConnectionCheck() :
    
    import_command = "sqoop list-tables --connect "+connectionString+" --username "+databaseUserName+"  --driver "+databaseDriver;

    import_command = import_command+' --password '+base64.b64decode(databasePassword);
    #print import_command;
    ls_proc = subprocess.Popen(import_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE);
    ls_lines = ls_proc.stdout.readlines()
    ls_errors = ls_proc.stderr.readlines()

    errorFlag = 0;
    for line in ls_errors:
        searchObj = re.search( r'.*(ERROR.*)', line)
        if searchObj:
            errorFlag = 1;
            error_message = line;
            error_message = error_message.replace("\'","");
            error_message = error_message.rstrip();
            #print "ERROR Sqoop Import ::",error_message
            break;

    for line in ls_lines:
        searchObj = re.search( r'.*(ERROR.*)', line)
        if searchObj:
            errorFlag = 1;
            error_message = searchObj.group(1);
            error_message = error_message.replace("\'","");
            #print error_message
            break;

    if errorFlag == 1:
        log_file_name = "/data/VIL/log/checkprerequisite_"+Date_Time+".log"
        put = subprocess.Popen(["hadoop", "fs", "-put", "-", log_file_name], stdin=subprocess.PIPE, bufsize=-1)
        put.stdin.write("import_command :: "+import_command+"\n")
        for line in ls_lines:
            put.stdin.write(line)
        for line in ls_errors:
            put.stdin.write(line)
        put.stdin.close()
        error_code = 'WF002';
        error_type = 'Major';
        process_status = 'FAIL';
        insertDetailsInToProcessDetailsTable(error_code,error_type,error_message,process_status);
        print"Check_Prerequisite=FAILED";
        print error_message;
        raise SystemExit;


    ls_proc.stdout.close(); 
    tableImportTime = time.strftime("%Y%m%d-%H:%M:%S")   
    #print"Import End time for table ::", tableImportTime
##########################################################################################################
#################################: Json file checking : ##################################################
def JSONFileCheck(targetDirectory) :
    shell_command = "hdfs dfs -test -e "+targetDirectory+"*.[jJ][sS][oO][nN]*  && echo 'JSON_file_exists' || echo 'no_JSON_file'";
    #print shell_command;
    return commands.getstatusoutput(shell_command)[1];
########################################################################################################
getKerberosTicket();
ensureMysqlTableCreation();
targetDirectory = '/data/VIL/INBOX/T_SOCIO/'
check_file = JSONFileCheck(targetDirectory);
#print check_file;
if check_file == 'JSON_file_exists' :
    insertDetailsInToProcessDetailsTable('NA','INFO','JSON file exists in directory /data/VIL/INBOX/T_SOCIO/',"PASS");
else :
    insertDetailsInToProcessDetailsTable('WF001','MAJOR','JSON file doesnot exists in directory /data/VIL/INBOX/T_SOCIO/',"FAIL");
    print "Check_Prerequisite=FAILED";
    print "JSON file doesnot exists in directory /data/VIL/INBOX/T_SOCIO/"
    raise SystemExit;
    
mysqlConnectionCheck();

EndTime = time.strftime("%Y%m%d-%H:%M:%S")    
#print"Start time ::", StartTime  
#print"End time ::", EndTime


