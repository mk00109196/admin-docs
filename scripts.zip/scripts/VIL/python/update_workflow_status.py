#!/usr/bin/python
##################################################################################################
#       Name    : RUN ID Generation script. 
#       Desc    : This Script generate custome runid and insert the details into mysql table.
#       Date    : 30-05-2016
#       Author  : Mithun Kankal
#       Version : 1.0
##################################################################################################

import pyhs2
import sys
import datetime
import traceback
import time;
import subprocess;
import MySQLdb;

#----------------------------------:: Global Varibale Declration ::----------------------------------------------------------
auth_Mech        = "KERBEROS"
hiveConfigDb     = 'socio_config_db'
hiveUserName     = ""
hivePassCode     = ""
(LocalMysqlHostAddress, LocalMysqlUser, LocalMysqlPass) = ('','','')
#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def getKerberosTicket():
        kinit_command = "/usr/bin/kinit "+hiveUserName;
        #print kinit_command;
        kinit = subprocess.Popen( kinit_command , shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);
        kinit.stdin.write(hivePassCode+"\n" );
        kinit.wait();
#----------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------- :: Function Definition for ensureMysqlTableCreation :: ------------------------------------
def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    mysqlConfigDb = 'socio_config_db';
    mysqlTableName1 = 'common_run_id_tracker';
    mysqlTableName2 = 'process_details';
    mysqlTableName3 = 'last_load_details';

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);

        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]

        if mysqlTableName1 not in mysqlConfigTables :
            statement=("CREATE TABLE IF NOT EXISTS socio_config_db.common_run_id_tracker (run_id text, start_time timestamp null, end_time timestamp null, job_status text)")
            cur.execute(statement);

        if mysqlTableName2 not in mysqlConfigTables :
            statement4=("CREATE TABLE IF NOT EXISTS socio_config_db.process_details(wf_id text, inboxfilenamewithext text, action_name text, date_time timestamp, error_code text, error_type text, error_message text,  file_checksum text, process_status text)");
            cur.execute(statement4);

        if mysqlTableName3 not in mysqlConfigTables :
            create_statement = ("CREATE TABLE IF NOT EXISTS socio_config_db.last_load_details(wf_id text, hive_table_name text, execution_date timestamp NULL, check_column_name text, last_value_imported text, incremental_mode_value text, status text)");
            cur.execute(create_statement);


        cur.close();
        conn.close();
    except:
        traceback.print_exc()
        print "ERROR: Mysql Connection not found"
        sys.exit();

#----------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------:: Start of Main ::-------------------------------------------------------------------
def main():
    global hiveUserName;
    global hivePassCode;
    global LocalMysqlHostAddress;
    global LocalMysqlUser;
    global LocalMysqlPass;

    date_time = time.strftime('%Y-%m-%d %H:%M:%S')
    print "Start Time:: ",date_time
    print "RUN ID creation process started";
    try:
        wf_id          = sys.argv[1];
        hiveHostName   = sys.argv[2];
        hivePortNo     = sys.argv[3];
        hiveUserName   = sys.argv[4];
        hivePassCode   = sys.argv[5];
        wf_id_key = '%'+wf_id+'%'
        LocalMysqlHostAddress = sys.argv[6];
        LocalMysqlUser = sys.argv[7];
        LocalMysqlPass = sys.argv[8];
        """
        (hiveHostName, hivePortNo, hiveUserName, hivePassCode) = ('10.94.191.203', 10000, "adityak@VIL.COM", "vil123")
        (LocalMysqlHostAddress, LocalMysqlUser, LocalMysqlPass) = ('10.94.191.203', "root", "password")
        wf_id = 'WF_TEST123'
        wf_id_key = '%Mysql_WF_TEST%'
        """
    except:
        traceback.print_exc();
        print"ERROR: Argument Expected, not given";
        sys.exit();

    #creation of RUN ID, store it in a variable
    file_name = 'NA';
    action_name="UpdateWorkflowStatus";
    file_checksum = "NA"
    run_id_key = date_time+wf_id;
    start_time = date_time;
    end_time   = date_time;
    job_status = 'SUCCESS';

    getKerberosTicket();
    ensureMysqlTableCreation();

    if wf_id == "":
        error_code = "WF003";
        error_type = "Major";
        error_message = "ERROR: Workflow id not generated";
        try:
            conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
            cur = conn.cursor();
            cur.execute("use socio_config_db");
            statement1=("INSERT INTO socio_config_db.process_details values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" % ('NULL', file_name, action_name, date_time, error_code, error_type, error_message, file_checksum, 'FAIL'));
            cur.execute(statement1);
            print "ERROR: Workflow status not updated";
        except:
            traceback.print_exc()
            print "ERROR: MySQL Connection not found"
            conn.close();
            raise SystemExit;
    else:
        #Hive connection
        try:
            #Hive connection
            conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
            cur = conn.cursor()

            status = 'SUCCESS'
            print "INFO: Updating last_load_details table";
            statement2=("update socio_config_db.last_load_details set status='%s' where wf_id like '%s'" % (status, wf_id))
            #print statement2;
            cur.execute(statement2);
            print "INFO: last_load_details table successfully with EndTime and Status of workflow";

            print "INFO: Updating pre_archival_db_details table";
            statement4=("update socio_config_db.pre_archival_db_details set status='%s' where wf_id like '%s'" %(status, wf_id));
            cur.execute(statement4);
            print "INFO: pre_archival_db_details table successfully updated with status";

            print "INFO: Updating common_run_id_tracker table";
            statement3=("update socio_config_db.common_run_id_tracker set end_time='%s', job_status='%s' where run_id like '%s'" % (end_time, job_status, wf_id_key))
            #print statement2; 
	    cur.execute(statement3);
            print "INFO: common_run_id_tracker table successfully with EndTime and Status of workflow";

        except:
            traceback.print_exc()
            print "ERROR: MySQL Connection not found"
            conn.close(); 
            raise SystemExit;

    print "RUN ID creation process completed";
    End_time = time.strftime('%Y-%m-%d %H:%M:%S')
    print "End_time :: ", End_time
#-----------------------:: End of Main ::-----------------------------------------------------------------------

if __name__ == "__main__": main()





