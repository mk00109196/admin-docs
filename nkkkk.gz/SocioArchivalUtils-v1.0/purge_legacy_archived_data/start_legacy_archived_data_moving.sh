#!/bin/bash

echo "!!Moving Legacy Archived data!!"
echo
ulimit -u 10240
python purge_archival_data.py ../VIL_DA_workflow/job.properties

echo "!! Legacy Archived data Movement Completed!!"
