#!/bin/bash

echo "!!Executing DELETION Script!!"
echo
ulimit -u 10240
python delete_archived_legacy_data.py ../VIL_DA_workflow/job.properties
echo "!! DELETED !!"
