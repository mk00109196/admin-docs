drop table socio_config_db.common_load_conf;
