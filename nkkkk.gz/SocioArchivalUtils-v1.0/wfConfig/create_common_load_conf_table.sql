CREATE DATABASE if not exists socio_config_db;

CREATE TABLE if not exists socio_config_db.common_load_conf(
  file_name text,
  dra_file_location text,
  error_file_location text,
  schema_name text,
  hive_table_name text,
  load_type text,
  hql_file_with_path text,
  no_of_columns_in_the_file int,
  delimiter text,
  file_extension text,
  inbox_file_location text,
  import_query text);

INSERT INTO socio_config_db.common_load_conf values('t_circle','/data/VIL/process','/data/VIL/error','socio_config_db','t_circle','D','--',10,'TILDE','.txt','/data/VIL/INBOX','select * from t_circle');
INSERT INTO socio_config_db.common_load_conf values('t_orgname','/data/VIL/process','/data/VIL/error','socio_config_db','t_orgname','D','--',13,'TILDE','.txt','/data/VIL/INBOX','select * from t_orgname');
INSERT INTO socio_config_db.common_load_conf values('t_source','/data/VIL/process','/data/VIL/error','socio_config_db','t_source','D','--',4,'TILDE','.txt','/data/VIL/INBOX','select * from t_source');
INSERT INTO socio_config_db.common_load_conf values('t_workflow_status','/data/VIL/process','/data/VIL/error','socio_config_db','t_workflow_status','D','--',4,'TILDE','.txt','/data/VIL/INBOX','select * from t_workflow_status');
INSERT INTO socio_config_db.common_load_conf values('t_user','/data/VIL/process','/data/VIL/error','socio_config_db','t_user','D','--',22,'TILDE','.txt','/data/VIL/INBOX','select * from t_user');
INSERT INTO socio_config_db.common_load_conf values('t_user_org_rel','/data/VIL/process','/data/VIL/error','socio_config_db','t_user_org_rel','D','--',10,'TILDE','.txt','/data/VIL/INBOX','select * from t_user_org_rel');
INSERT INTO socio_config_db.common_load_conf values('t_brand_profiles','/data/VIL/process','/data/VIL/error','socio_config_db','t_brand_profiles','D','--',70,'TILDE','.txt','/data/VIL/INBOX','select * from t_brand_profiles');
INSERT INTO socio_config_db.common_load_conf values('t_tags_new','/data/VIL/process','/data/VIL/error','socio_config_db','t_tags_new','D','--',10,'TILDE','.txt','/data/VIL/INBOX','select * from t_tags_new');
INSERT INTO socio_config_db.common_load_conf values('t_workbasket','/data/VIL/process','/data/VIL/error','socio_config_db','t_workbasket','D','--',13,'TILDE','.txt','/data/VIL/INBOX','select * from t_workbasket');
INSERT INTO socio_config_db.common_load_conf values('t_role','/data/VIL/process','/data/VIL/error','socio_config_db','t_role','D','--',14,'TILDE','.txt','/data/VIL/INBOX','select * from t_role');
INSERT INTO socio_config_db.common_load_conf values('t_response_types','/data/VIL/process','/data/VIL/error','socio_config_db','t_response_types','D','--',9,'TILDE','.txt','/data/VIL/INBOX','select * from t_response_types');
INSERT INTO socio_config_db.common_load_conf values('t_surveys','/data/VIL/process','/data/VIL/error','socio_config_db','t_surveys','D','--',22,'TILDE','.txt','/data/VIL/INBOX','select * from t_surveys');
INSERT INTO socio_config_db.common_load_conf values('t_survey_profile_rel','/data/VIL/process','/data/VIL/error','socio_config_db','t_survey_profile_rel','D','--',5,'TILDE','.txt','/data/VIL/INBOX','select * from t_survey_profile_rel');
INSERT INTO socio_config_db.common_load_conf values('t_survey_questions','/data/VIL/process','/data/VIL/error','socio_config_db','t_survey_questions','D','--',13,'TILDE','.txt','/data/VIL/INBOX','select * from t_survey_questions');
INSERT INTO socio_config_db.common_load_conf values('t_survey_question_answers','/data/VIL/process','/data/VIL/error','socio_config_db','t_survey_question_answers','D','--',7,'TILDE','.txt','/data/VIL/INBOX','select * from t_survey_question_answers');
INSERT INTO socio_config_db.common_load_conf values('t_external_data_reporting','/data/VIL/process','/data/VIL/error','socio_config_db','t_external_data_reporting','D','--',23,'TILDE','.txt','/data/VIL/INBOX','select * from t_external_data_reporting');
INSERT INTO socio_config_db.common_load_conf values('t_survey_respondent_types','/data/VIL/process','/data/VIL/error','socio_config_db','t_survey_respondent_types','D','--',8,'TILDE','.txt','/data/VIL/INBOX','select * from t_survey_respondent_types');
INSERT INTO socio_config_db.common_load_conf values('t_socio','/data/VIL/process','/data/VIL/error','socio_config_db','t_socio','D','--',67,'TILDE','.txt','/data/VIL/INBOX','select * from t_socio');
INSERT INTO socio_config_db.common_load_conf values('t_workflow_dtls','/data/VIL/process','/data/VIL/error','socio_config_db','t_workflow_dtls','D','--',82,'TILDE','.txt','/data/VIL/INBOX','select * from t_workflow_dtls WHERE parentId in (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_sch_mess_accts','/data/VIL/process','/data/VIL/error','socio_config_db','t_sch_mess_accts','D','--',26,'TILDE','.txt','/data/VIL/INBOX','select * from t_sch_mess_accts WHERE schMsgId IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_sch_messages','/data/VIL/process','/data/VIL/error','socio_config_db','t_sch_messages','D','--',43,'TILDE','.txt','/data/VIL/INBOX','select * from t_sch_messages WHERE schMsgId IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_lead_social_accts','/data/VIL/process','/data/VIL/error','socio_config_db','t_lead_social_accts','D','--',13,'TILDE','.txt','/data/VIL/INBOX','select * from t_lead_social_accts WHERE socialid IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_message_tag_dtls','/data/VIL/process','/data/VIL/error','socio_config_db','t_message_tag_dtls','D','--',7,'TILDE','.txt','/data/VIL/INBOX','select * from t_message_tag_dtls WHERE docKey IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_respondents','/data/VIL/process','/data/VIL/error','socio_config_db','t_respondents','D','--',16,'TILDE','.txt','/data/VIL/INBOX','select * from t_respondents WHERE surveyid IN (%s) AND objid IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_sentiment_changed','/data/VIL/process','/data/VIL/error','socio_config_db','t_sentiment_changed','D','--',18,'TILDE','.txt','/data/VIL/INBOX','select * from t_sentiment_changed where docKey IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_user_notes','/data/VIL/process','/data/VIL/error','socio_config_db','t_user_notes','D','--',13,'TILDE','.txt','/data/VIL/INBOX','select * from t_user_notes WHERE refType="WORKFLOW" AND refid IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_survey_respid_rel','/data/VIL/process','/data/VIL/error','socio_config_db','t_survey_respid_rel','D','--',7,'TILDE','.txt','/data/VIL/INBOX','select * from t_survey_respid_rel WHERE (respondentId IN (select Id from t_survey_respondent_types)) AND (surveyid IN (select surveyid from t_surveys where surveyid IN (%s)))');
INSERT INTO socio_config_db.common_load_conf values('t_survey_responses','/data/VIL/process','/data/VIL/error','socio_config_db','t_survey_responses','D','--',8,'TILDE','.txt','/data/VIL/INBOX','select * from t_survey_responses WHERE surveyid IN (select surveyid from t_surveys where surveyid IN (%s))');
INSERT INTO socio_config_db.common_load_conf values('t_tagged_messages','/data/VIL/process','/data/VIL/error','socio_config_db','t_tagged_messages','D','--',16,'TILDE','.txt','/data/VIL/INBOX','select * from t_tagged_messages WHERE docKey IN (%s) AND (userId IN (%s) OR userId IN (%s))');
INSERT INTO socio_config_db.common_load_conf values('t_workflow_tat_dtls','/data/VIL/process','/data/VIL/error','socio_config_db','t_workflow_tat_dtls','D','--',20,'TILDE','.txt','/data/VIL/INBOX','select * from t_workflow_tat_dtls WHERE workId IN (%s) and parent_workId IN (%s)');  

INSERT INTO socio_config_db.common_load_conf values('t_srid_dtls','/data/VIL/process','/data/VIL/error','socio_config_db','t_srid_dtls','D','--',89,'TILDE','.txt','/data/VIL/INBOX','select * from t_srid_dtls WHERE workid IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_sr_type_dtls','/data/VIL/process','/data/VIL/error','socio_config_db','t_sr_type_dtls','D','--',9,'TILDE','.txt','/data/VIL/INBOX','select * from t_sr_type_dtls WHERE workid IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_srid_dtls_siebel','/data/VIL/process','/data/VIL/error','socio_config_db','t_srid_dtls_siebel','D','--',87,'TILDE','.txt','/data/VIL/INBOX','select * from t_srid_dtls_siebel WHERE workid IN (%s)');
INSERT INTO socio_config_db.common_load_conf values('t_srid_dtls_siebel_fields','/data/VIL/process','/data/VIL/error','socio_config_db','t_srid_dtls_siebel_fields','D','--',7,'TILDE','.txt','/data/VIL/INBOX','select * from t_srid_dtls_siebel_fields WHERE sRNumber IN (select sRNumber from t_srid_dtls_siebel where (workid IN (%s)))');
INSERT INTO socio_config_db.common_load_conf values('t_srid_dtls_siebel_srdtls','/data/VIL/process','/data/VIL/error','socio_config_db','t_srid_dtls_siebel_srdtls','D','--',20,'TILDE','.txt','/data/VIL/INBOX','select * from t_srid_dtls_siebel_srdtls WHERE sRNumber IN (select sRNumber from t_srid_dtls_siebel where (workid IN (%s)))');
INSERT INTO socio_config_db.common_load_conf values('t_lead','/data/VIL/process','/data/VIL/error','socio_config_db','t_lead','D','--',49,'TILDE','.txt','/data/VIL/INBOX','select * from t_lead WHERE circle IN (select circleId from t_workbasket where (basketid IN (%s) or basketid IN (%s)))');
INSERT INTO socio_config_db.common_load_conf values('t_customer_lead','/data/VIL/process','/data/VIL/error','socio_config_db','t_customer_lead','D','--',35,'TILDE','.txt','/data/VIL/INBOX','select * from t_customer_lead WHERE leadId IN (select leadId from t_lead where circle IN (select circleId from t_workbasket where (basketid IN (%s) or basketid IN (%s))))');
INSERT INTO socio_config_db.common_load_conf values('t_customer_lead_address','/data/VIL/process','/data/VIL/error','socio_config_db','t_customer_lead_address','D','--',14,'TILDE','.txt','/data/VIL/INBOX','select * from t_customer_lead_address WHERE customerleadId IN (select leadId from t_lead where circle IN (select circleId from t_workbasket where (basketid IN (%s) or basketid IN (%s))))');
INSERT INTO socio_config_db.common_load_conf values('t_customer_lead_contact','/data/VIL/process','/data/VIL/error','socio_config_db','t_customer_lead_contact','D','--',10,'TILDE','.txt','/data/VIL/INBOX','select * from t_customer_lead_contact WHERE customerleadId IN (select leadId from t_lead where circle IN (select circleId from t_workbasket where (basketid IN (%s) or basketid IN (%s))))');

