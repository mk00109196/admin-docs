#!/usr/bin/python
##################################################################################################
#	Name    : Rollback script for failed workflow
#	Date    : 24-01-2017
#	Author  : Sahil Goyal
#	Version : 1.0
##################################################################################################
import datetime
import sys;
import re;
import subprocess;
import time;
import traceback;
import datetime;
import base64;
import commands;
import MySQLdb;
import os;
import itertools;
from warnings import filterwarnings

DateTime      = time.strftime('%Y_%m_%d_%H_%M_%S');
try:
    wf_id                 =   sys.argv[1];
except:
    print "INFO :: Please provide valid  Workflow ID "
    raise SystemExit;

#### :: Hive Connection Parameter :: ####
kTicketUserName       =   "daadmin@VIL.COM"
kTicketPassCode       =   "vil123"
#### :: Mysql Connection Parameter :: ####
LocalMysqlHostAddress =   "10.94.185.240"
LocalMysqlUser        =   "root"
LocalMysqlPass        =   "password"

SourceMysqlHostAddress    = "10.94.185.240"
SourceMysqlUser           = "root"
SourceMysqlPass           = "password"
SourceMysqlHostPortNumber ="3306"

process_path          =   "/data/VIL/process" 
inbox_path            =   "/data/VIL/INBOX"
archive_path          =   "/data/VIL/archive"
mysqlConfigDb         =   'socio_config_db';


#-------------------------------------- :: Function Definition Section :: ---------------------------------------------------------
def getKerberosTicket():
    try:
        kinit_command = "/usr/bin/kinit "+kTicketUserName;
        #print kinit_command;
        kinit = subprocess.Popen( kinit_command , shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);
        kinit.stdin.write(kTicketPassCode+"\n" );
        kinit.wait();
    except:
        traceback.print_exc()
        print "ERROR: Fails to generate kerberos ticket.";
        raise SystemExit;
#----------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------- :: Function Definition for ensureMysqlTableCreation :: ------------------------------------

def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    
    mysqlTableName1 = 'common_run_id_tracker';
    mysqlTableName2 = 'process_details';
    mysqlTableName3 = 'last_load_details';

    try: 
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);
        
        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]
        
        if mysqlTableName1 not in mysqlConfigTables :
            statement=("CREATE TABLE IF NOT EXISTS socio_config_db.common_run_id_tracker (run_id text, start_time timestamp null, end_time timestamp null, job_status text)")
            cur.execute(statement);
        
        if mysqlTableName2 not in mysqlConfigTables :
            statement4=("CREATE TABLE IF NOT EXISTS socio_config_db.process_details(wf_id text, inboxfilenamewithext text, action_name text, date_time timestamp, error_code text, error_type text, error_message text,  file_checksum text, process_status text)");
            cur.execute(statement4);
        
        if mysqlTableName3 not in mysqlConfigTables :
            statement3=("CREATE TABLE IF NOT EXISTS socio_config_db.last_load_details(wf_id text, hive_table_name text, execution_date timestamp NULL, check_column_name text, last_value_imported text, incremental_mode_value text, status text)");
            cur.execute(statement3);
        
        cur.close();
        conn.close();
    except:
	traceback.print_exc()
        print "ERROR: Mysql Connection not found"
        conn.close();
        sys.exit();

#-------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start loadPreArchivedData ::----------------------------------------------------------------
def checkFailedStatus():
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
        qry="select * from socio_config_db.common_run_id_tracker where run_id like '%"+wf_id+"%'"
        cur.execute(qry)
        failedWFdetails=cur.fetchone();
        #print failedWFdetails;
        if failedWFdetails is not None:
            if failedWFdetails[3] == "STARTED":
                print "This workflow was not completed successfully ROLLBACK started"
                return failedWFdetails;
            elif failedWFdetails[3] == "ROLLEDBACK":
                print "INFO :: This workflow was successfully rolled back no further action required"
                raise SystemExit;
            else: 
                print "INFO :: This workflow was successful no rollback required"
                raise SystemExit;
        else:
            print "INFO: Invalid workflow_id or No ROLLBACK required"
            raise SystemExit;
            
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
# This function will update the entry from pre_archival_db_details of work-flow id for which data has been roll backed.
def updateEntryOfDBFromPreArchivalDBDetails():
    try:
        status = "ROLLEDBACK";
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
        qry=("update socio_config_db.pre_archival_db_details set status='%s' where wf_id ='%s'" %(status,wf_id));
        cur.execute(qry);
        cur.fetchall();
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------
# This function will update the entry from last_load_details of work-flow id for which data has been roll backed.
def updateEntryOfLastLoadDetails():
    try:
        status = "ROLLEDBACK";
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
        qry=("update socio_config_db.last_load_details set status='%s' where wf_id ='%s'" %(status,wf_id));
        cur.execute(qry)
        listFederatedDB=cur.fetchall();
        cur.fetchall();
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------
# This function will update the entry from last_load_details of work-flow id for which data has been roll backed.
def updateEntryOfRunIdTracker():
    try:
        status = "ROLLEDBACK";
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
        qry="update socio_config_db.common_run_id_tracker set job_status=\'"+status+"\' where run_id like '%"+wf_id+"%'"
        cur.execute(qry);
        cur.fetchall();
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start loadPreArchivedData ::---------------------------------------------------------------
def removePartFilesFromINBOX():
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor();
        qry='select * from '+mysqlConfigDb+'.last_load_details where wf_id =(select distinct wf_id from '+mysqlConfigDb+'.last_load_details where execution_date =(select max(execution_date) from '+mysqlConfigDb+'.last_load_details where status = \'SUCCESS\'))'

        cur.execute(qry);
        listLastLoadDetails=cur.fetchall()
        #print listLastLoadDetails
        
        if len(listLastLoadDetails) != 0 :
            removePartFilesFromInboxWithoutDirs();
        else :
            removePartFilesFromInboxWithDirs();
        
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start loadPreArchivedData ::---------------------------------------------------------------
def removePartFilesFromArchive(failedWFdetails):
    try:
        #print failedWFdetails;
        wf_start_date = failedWFdetails[1];
        filterwarnings('ignore', category = MySQLdb.Warning);
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor();
        qry="select * from "+mysqlConfigDb+".common_run_id_tracker where job_status = \'SUCCESS\' and start_time like \'%"+wf_start_date.strftime("%Y-%m-%d %H")+"%\'";
        #print qry;
        cur.execute(qry);
        listofSuccessWFonPartitionValue = cur.fetchall();
        #print listofSuccessWFonPartitionValue;
        #print len(listofSuccessWFonPartitionValue);
        
        partition_value =  wf_start_date.strftime("%Y%m%d%H")
        
        if len(listofSuccessWFonPartitionValue)>0:
            removePartFilesFromArchivePartition(partition_value,len(listofSuccessWFonPartitionValue));
        else :
            removePartFilesFromArchivePartitionSingleRun(partition_value);
        
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start loadPreArchivedData ::----------------------------------------------------------------
def dropEligbleArchivalDatabases():
    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
        qry="select * from socio_config_db.pre_archival_db_details where wf_id = '"+wf_id+"'"
        cur.execute(qry)
        dropDBdetails=cur.fetchone();
        #print failedWFdetails;
        
        if dropDBdetails is not None:
            
            sourceFederatedDBName = dropDBdetails[2];
            sourceArchivedDBName  = dropDBdetails[1]
            
            #Drop DB from Source
            src_conn = MySQLdb.connect(host=SourceMysqlHostAddress, user=SourceMysqlUser, passwd=SourceMysqlPass);
            src_cur = src_conn.cursor()
            drop_qry1="drop database "+sourceFederatedDBName
            print "\n\nDropping database "+ sourceFederatedDBName
            src_cur.execute(drop_qry1);
            src_cur.close();	
            src_conn.close();

            loc_conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
            loc_cur = loc_conn.cursor()
            print "\nDropping database "+sourceArchivedDBName 
            drop_qry2="drop database "+sourceArchivedDBName
            loc_cur.execute(drop_qry2);
            loc_cur.close();
            loc_conn.close();
        
        else:
            print "INFO: No temporary database found to drop"
            raise SystemExit;
            
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------:: Deleting part files from Inbox dir ::------------------------------------------ 
def removePartFilesFromInboxWithoutDirs() :
    readline1="hadoop fs -rm -r -skipTrash "+inbox_path+"/*/part-m-*"
    status, output=commands.getstatusoutput(readline1);
    print output;

#--------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------:: Deleting part files from Inbox dir ::------------------------------------------ 
def removePartFilesFromInboxWithDirs() :
    readline1="hadoop fs -rm -r -skipTrash "+inbox_path+"/*"
    status1, output1=commands.getstatusoutput(readline1);
    print output1;
    readline2="hadoop fs -mkdir "+inbox_path+"/T_SOCIO"
    status2, output2=commands.getstatusoutput(readline2);
    print output2;
    
#--------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------:: Deleting part files from process Dir ::--------------------------------------
def removePartFilesFromProcess() :
    readline1="hadoop fs -rm -r -skipTrash "+process_path+"/*/part-m-*"
    status, output=commands.getstatusoutput(readline1);
    print output;

#--------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------:: Deleting part files from Inbox dir ::------------------------------------------ 
def removePartFilesFromArchivePartition(partition_value,copy_no) :
    readline1="hadoop fs -rm -r "+archive_path+"/*/archival_date="+partition_value+"/*_copy_"+str(copy_no);
    status, output=commands.getstatusoutput(readline1);
    print output;
    
#--------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------:: Deleting part files from Inbox dir ::------------------------------------------ 
def removePartFilesFromArchivePartitionSingleRun(partition_value) :
    readline1="hadoop fs -rm -r -skipTrash "+archive_path+"/*/archival_date="+partition_value;
    status, output=commands.getstatusoutput(readline1);
    print output;
    
#--------------------------------------------------------------------------------------------------------------------------------


getKerberosTicket();

ensureMysqlTableCreation();

failedWFdetails = checkFailedStatus();

removePartFilesFromINBOX();

removePartFilesFromProcess();

removePartFilesFromArchive(failedWFdetails);

updateEntryOfDBFromPreArchivalDBDetails();

updateEntryOfLastLoadDetails();

updateEntryOfRunIdTracker();

dropEligbleArchivalDatabases();


