#!/bin/bash

echo "!!Executing ROLLBACK Script!!"
echo 
python start_rollback_failed_changes.py $1
echo 
echo "!!ROLLBACK Completed!!"
