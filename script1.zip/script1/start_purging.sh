#!/bin/bash

echo "!!Executing Purging Script!!"
echo
ulimit -u 10240
python purge_socio.py job.properties

echo
echo "!!END Purging Script!!"


