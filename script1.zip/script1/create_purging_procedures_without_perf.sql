DROP PROCEDURE IF EXISTS purge_table;
DELIMITER //
CREATE PROCEDURE `purge_table`(IN table_name char(100),IN source_db char(100),IN archived_db char(100))
BEGIN
    CASE table_name
    WHEN 't_message_tag_dtls' THEN
    call `purge_t_message_tag_dtls`(source_db,archived_db);
    WHEN 't_lead_social_accts' THEN 
    call `purge_t_lead_social_accts`(source_db,archived_db);
    WHEN 't_respondents' THEN
    call `purge_t_respondents`(source_db,archived_db);
    WHEN 't_sch_mess_accts' THEN
    call `purge_t_sch_mess_accts`(source_db,archived_db);
    WHEN 't_sch_messages' THEN
    call `purge_t_sch_messages`(source_db,archived_db);
    WHEN 't_sentiment_changed' THEN
    call `purge_t_sentiment_changed`(source_db,archived_db);
    WHEN 't_srid_dtls' THEN
    call `purge_t_srid_dtls`(source_db,archived_db);
    WHEN 't_workflow_dtls' THEN
    call `purge_t_workflow_dtls`(source_db,archived_db);
    WHEN 't_lead' THEN
    call `purge_t_lead`(source_db,archived_db);
    WHEN 't_survey_respid_rel' THEN
    call `purge_t_survey_respid_rel`(source_db,archived_db);
    WHEN 't_survey_responses' THEN
    call `purge_t_survey_responses`(source_db,archived_db);
    WHEN 't_tagged_messages' THEN
    call `purge_t_tagged_messages`(source_db,archived_db);
    WHEN 't_user_notes' THEN
    call `purge_t_user_notes`(source_db,archived_db);
    WHEN 't_workflow_tat_dtls' THEN
    call `purge_t_workflow_tat_dtls`(source_db,archived_db);
    WHEN 't_sr_type_dtls' THEN
    call `purge_t_sr_type_dtls`(source_db,archived_db);
    WHEN 't_srid_dtls_siebel' THEN
    call `purge_t_srid_dtls_siebel`(source_db,archived_db);
    WHEN 't_srid_dtls_siebel_fields' THEN
    call `purge_t_srid_dtls_siebel_fields`(source_db,archived_db);
    WHEN 't_srid_dtls_siebel_srdtls' THEN
    call `purge_t_srid_dtls_siebel_srdtls`(source_db,archived_db);
    WHEN 't_customer_lead' THEN
    call `purge_t_customer_lead`(source_db,archived_db);
    WHEN 't_customer_lead_address' THEN
    call `purge_t_customer_lead_address`(source_db,archived_db);
    WHEN 't_customer_lead_contact' THEN
    call `purge_t_customer_lead_contact`(source_db,archived_db);
    END CASE;

END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_message_tag_dtls;

DELIMITER //
CREATE PROCEDURE  `purge_t_message_tag_dtls`(IN source_db char(100),IN archived_db char(100))
BEGIN
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_message_tag_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.tagId,0), COALESCE(r.docKey,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(tagId,0), COALESCE(docKey,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_message_tag_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_message_tag_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.tagId,0), COALESCE(t.docKey,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(tagId,0), COALESCE(docKey,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_message_tag_dtls ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_message_tag_dtls where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_message_tag_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.tagId,0), COALESCE(r.docKey,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(tagId,0), COALESCE(docKey,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_message_tag_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_message_tag_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.tagId,0), COALESCE(t.docKey,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(tagId,0), COALESCE(docKey,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_message_tag_dtls ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_lead_social_accts;

DELIMITER //
CREATE PROCEDURE  `purge_t_lead_social_accts`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_lead_social_accts r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.leadId,0), COALESCE(r.socialId,0), COALESCE(r.name,0), COALESCE(r.picture,0), COALESCE(r.profileUrl,0), COALESCE(r.type,0), COALESCE(r.orgId,0), COALESCE(r.active,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(leadId,0), COALESCE(socialId,0), COALESCE(name,0), COALESCE(picture,0), COALESCE(profileUrl,0), COALESCE(type,0), COALESCE(orgId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_lead_social_accts) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_lead_social_accts t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.leadId,0), COALESCE(t.socialId,0), COALESCE(t.name,0), COALESCE(t.picture,0), COALESCE(t.profileUrl,0), COALESCE(t.type,0), COALESCE(t.orgId,0), COALESCE(t.active,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(leadId,0), COALESCE(socialId,0), COALESCE(name,0), COALESCE(picture,0), COALESCE(profileUrl,0), COALESCE(type,0), COALESCE(orgId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_lead_social_accts ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_lead_social_accts where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_lead_social_accts r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.leadId,0), COALESCE(r.socialId,0), COALESCE(r.name,0), COALESCE(r.picture,0), COALESCE(r.profileUrl,0), COALESCE(r.type,0), COALESCE(r.orgId,0), COALESCE(r.active,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(leadId,0), COALESCE(socialId,0), COALESCE(name,0), COALESCE(picture,0), COALESCE(profileUrl,0), COALESCE(type,0), COALESCE(orgId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_lead_social_accts) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_lead_social_accts t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.leadId,0), COALESCE(t.socialId,0), COALESCE(t.name,0), COALESCE(t.picture,0), COALESCE(t.profileUrl,0), COALESCE(t.type,0), COALESCE(t.orgId,0), COALESCE(t.active,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(leadId,0), COALESCE(socialId,0), COALESCE(name,0), COALESCE(picture,0), COALESCE(profileUrl,0), COALESCE(type,0), COALESCE(orgId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_lead_social_accts ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_respondents;

DELIMITER //
CREATE PROCEDURE  `purge_t_respondents`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.respondentId
    FROM ',source_db,'.t_respondents r
    WHERE   ROW(COALESCE(r.respondentId,0), COALESCE(r.respondentSrcId,0), COALESCE(r.surveyId,0), COALESCE(r.objid,0), COALESCE(r.type,0), COALESCE(r.ipaddress,0), COALESCE(r.city,0), COALESCE(r.country,0), COALESCE(r.state,0), COALESCE(r.firstName,0), COALESCE(r.lastName,0), COALESCE(r.customFormData,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(respondentId,0), COALESCE(respondentSrcId,0), COALESCE(surveyId,0), COALESCE(objid,0), COALESCE(type,0), COALESCE(ipaddress,0), COALESCE(city,0), COALESCE(country,0), COALESCE(state,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(customFormData,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_respondents) 
    UNION
    SELECT  t.respondentId
    FROM    ',archived_db,'.t_respondents t
    WHERE   ROW(COALESCE(t.respondentId,0), COALESCE(t.respondentSrcId,0), COALESCE(t.surveyId,0), COALESCE(t.objid,0), COALESCE(t.type,0), COALESCE(t.ipaddress,0), COALESCE(t.city,0), COALESCE(t.country,0), COALESCE(t.state,0), COALESCE(t.firstName,0), COALESCE(t.lastName,0), COALESCE(t.customFormData,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(respondentId,0), COALESCE(respondentSrcId,0), COALESCE(surveyId,0), COALESCE(objid,0), COALESCE(type,0), COALESCE(ipaddress,0), COALESCE(city,0), COALESCE(country,0), COALESCE(state,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(customFormData,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_respondents ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_respondents where respondentId IN(SELECT * from(
    SELECT  r.respondentId
    FROM ',source_db,'.t_respondents r
    WHERE   ROW(COALESCE(r.respondentId,0), COALESCE(r.respondentSrcId,0), COALESCE(r.surveyId,0), COALESCE(r.objid,0), COALESCE(r.type,0), COALESCE(r.ipaddress,0), COALESCE(r.city,0), COALESCE(r.country,0), COALESCE(r.state,0), COALESCE(r.firstName,0), COALESCE(r.lastName,0), COALESCE(r.customFormData,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(respondentId,0), COALESCE(respondentSrcId,0), COALESCE(surveyId,0), COALESCE(objid,0), COALESCE(type,0), COALESCE(ipaddress,0), COALESCE(city,0), COALESCE(country,0), COALESCE(state,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(customFormData,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_respondents) 
    UNION
    SELECT  t.respondentId
    FROM    ',archived_db,'.t_respondents t
    WHERE   ROW(COALESCE(t.respondentId,0), COALESCE(t.respondentSrcId,0), COALESCE(t.surveyId,0), COALESCE(t.objid,0), COALESCE(t.type,0), COALESCE(t.ipaddress,0), COALESCE(t.city,0), COALESCE(t.country,0), COALESCE(t.state,0), COALESCE(t.firstName,0), COALESCE(t.lastName,0), COALESCE(t.customFormData,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(respondentId,0), COALESCE(respondentSrcId,0), COALESCE(surveyId,0), COALESCE(objid,0), COALESCE(type,0), COALESCE(ipaddress,0), COALESCE(city,0), COALESCE(country,0), COALESCE(state,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(customFormData,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_respondents ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_sch_mess_accts;

DELIMITER //
CREATE PROCEDURE  `purge_t_sch_mess_accts`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.schId
    FROM ',source_db,'.t_sch_mess_accts r
    WHERE   ROW(COALESCE(r.schId,0), COALESCE(r.schMsgId,0), COALESCE(r.accountId,0), COALESCE(r.accountType,0), COALESCE(r.attempted,0), COALESCE(r.status,0), COALESCE(r.active,0), COALESCE(r.usrTime,0), COALESCE(r.gmtTime,0), COALESCE(r.gmtTimeDate,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.targetJson,0), COALESCE(r.imageAlbumId,0), COALESCE(r.postId,0), COALESCE(r.reason,0), COALESCE(r.targetLNC,0), COALESCE(r.targetSeniority,0), COALESCE(r.targetIndustries,0), COALESCE(r.targetJobFunction,0), COALESCE(r.targetGeography,0), COALESCE(r.lastStatsFetched,0), COALESCE(r.error,0), COALESCE(r.schType,0)) IN (
            SELECT  COALESCE(schId,0), COALESCE(schMsgId,0), COALESCE(accountId,0), COALESCE(accountType,0), COALESCE(attempted,0), COALESCE(status,0), COALESCE(active,0), COALESCE(usrTime,0), COALESCE(gmtTime,0), COALESCE(gmtTimeDate,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(targetJson,0), COALESCE(imageAlbumId,0), COALESCE(postId,0), COALESCE(reason,0), COALESCE(targetLNC,0), COALESCE(targetSeniority,0), COALESCE(targetIndustries,0), COALESCE(targetJobFunction,0), COALESCE(targetGeography,0), COALESCE(lastStatsFetched,0), COALESCE(error,0), COALESCE(schType,0)
            FROM ',archived_db,'.t_sch_mess_accts) 
    UNION
    SELECT  t.schId
    FROM    ',archived_db,'.t_sch_mess_accts t
    WHERE   ROW(COALESCE(t.schId,0), COALESCE(t.schMsgId,0), COALESCE(t.accountId,0), COALESCE(t.accountType,0), COALESCE(t.attempted,0), COALESCE(t.status,0), COALESCE(t.active,0), COALESCE(t.usrTime,0), COALESCE(t.gmtTime,0), COALESCE(t.gmtTimeDate,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.targetJson,0), COALESCE(t.imageAlbumId,0), COALESCE(t.postId,0), COALESCE(t.reason,0), COALESCE(t.targetLNC,0), COALESCE(t.targetSeniority,0), COALESCE(t.targetIndustries,0), COALESCE(t.targetJobFunction,0), COALESCE(t.targetGeography,0), COALESCE(t.lastStatsFetched,0), COALESCE(t.error,0), COALESCE(t.schType,0)) 
            IN ( SELECT  COALESCE(schId,0), COALESCE(schMsgId,0), COALESCE(accountId,0), COALESCE(accountType,0), COALESCE(attempted,0), COALESCE(status,0), COALESCE(active,0), COALESCE(usrTime,0), COALESCE(gmtTime,0), COALESCE(gmtTimeDate,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(targetJson,0), COALESCE(imageAlbumId,0), COALESCE(postId,0), COALESCE(reason,0), COALESCE(targetLNC,0), COALESCE(targetSeniority,0), COALESCE(targetIndustries,0), COALESCE(targetJobFunction,0), COALESCE(targetGeography,0), COALESCE(lastStatsFetched,0), COALESCE(error,0), COALESCE(schType,0)
            FROM ',source_db,'.t_sch_mess_accts ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_sch_mess_accts where schId IN(SELECT * from(
    SELECT  r.schId
    FROM ',source_db,'.t_sch_mess_accts r
    WHERE   ROW(COALESCE(r.schId,0), COALESCE(r.schMsgId,0), COALESCE(r.accountId,0), COALESCE(r.accountType,0), COALESCE(r.attempted,0), COALESCE(r.status,0), COALESCE(r.active,0), COALESCE(r.usrTime,0), COALESCE(r.gmtTime,0), COALESCE(r.gmtTimeDate,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.targetJson,0), COALESCE(r.imageAlbumId,0), COALESCE(r.postId,0), COALESCE(r.reason,0), COALESCE(r.targetLNC,0), COALESCE(r.targetSeniority,0), COALESCE(r.targetIndustries,0), COALESCE(r.targetJobFunction,0), COALESCE(r.targetGeography,0), COALESCE(r.lastStatsFetched,0), COALESCE(r.error,0), COALESCE(r.schType,0)) IN (
            SELECT  COALESCE(schId,0), COALESCE(schMsgId,0), COALESCE(accountId,0), COALESCE(accountType,0), COALESCE(attempted,0), COALESCE(status,0), COALESCE(active,0), COALESCE(usrTime,0), COALESCE(gmtTime,0), COALESCE(gmtTimeDate,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(targetJson,0), COALESCE(imageAlbumId,0), COALESCE(postId,0), COALESCE(reason,0), COALESCE(targetLNC,0), COALESCE(targetSeniority,0), COALESCE(targetIndustries,0), COALESCE(targetJobFunction,0), COALESCE(targetGeography,0), COALESCE(lastStatsFetched,0), COALESCE(error,0), COALESCE(schType,0)
            FROM ',archived_db,'.t_sch_mess_accts) 
    UNION
    SELECT  t.schId
    FROM    ',archived_db,'.t_sch_mess_accts t
    WHERE   ROW(COALESCE(t.schId,0), COALESCE(t.schMsgId,0), COALESCE(t.accountId,0), COALESCE(t.accountType,0), COALESCE(t.attempted,0), COALESCE(t.status,0), COALESCE(t.active,0), COALESCE(t.usrTime,0), COALESCE(t.gmtTime,0), COALESCE(t.gmtTimeDate,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.targetJson,0), COALESCE(t.imageAlbumId,0), COALESCE(t.postId,0), COALESCE(t.reason,0), COALESCE(t.targetLNC,0), COALESCE(t.targetSeniority,0), COALESCE(t.targetIndustries,0), COALESCE(t.targetJobFunction,0), COALESCE(t.targetGeography,0), COALESCE(t.lastStatsFetched,0), COALESCE(t.error,0), COALESCE(t.schType,0)) 
            IN ( SELECT  COALESCE(schId,0), COALESCE(schMsgId,0), COALESCE(accountId,0), COALESCE(accountType,0), COALESCE(attempted,0), COALESCE(status,0), COALESCE(active,0), COALESCE(usrTime,0), COALESCE(gmtTime,0), COALESCE(gmtTimeDate,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(targetJson,0), COALESCE(imageAlbumId,0), COALESCE(postId,0), COALESCE(reason,0), COALESCE(targetLNC,0), COALESCE(targetSeniority,0), COALESCE(targetIndustries,0), COALESCE(targetJobFunction,0), COALESCE(targetGeography,0), COALESCE(lastStatsFetched,0), COALESCE(error,0), COALESCE(schType,0)
            FROM ',source_db,'.t_sch_mess_accts ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_sentiment_changed;

DELIMITER //
CREATE PROCEDURE  `purge_t_sentiment_changed`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_sentiment_changed r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.messageId,0), COALESCE(r.messageType,0), COALESCE(r.message,0), COALESCE(r.orignalSentiment,0), COALESCE(r.orignalClassified,0), COALESCE(r.newSentiment,0), COALESCE(r.newClassified,0), COALESCE(r.approved,0), COALESCE(r.changedBy,0), COALESCE(r.orgId,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.docKey,0), COALESCE(r.profileId,0), COALESCE(r.words,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(messageId,0), COALESCE(messageType,0), COALESCE(message,0), COALESCE(orignalSentiment,0), COALESCE(orignalClassified,0), COALESCE(newSentiment,0), COALESCE(newClassified,0), COALESCE(approved,0), COALESCE(changedBy,0), COALESCE(orgId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(docKey,0), COALESCE(profileId,0), COALESCE(words,0)
            FROM ',archived_db,'.t_sentiment_changed) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_sentiment_changed t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.messageId,0), COALESCE(t.messageType,0), COALESCE(t.message,0), COALESCE(t.orignalSentiment,0), COALESCE(t.orignalClassified,0), COALESCE(t.newSentiment,0), COALESCE(t.newClassified,0), COALESCE(t.approved,0), COALESCE(t.changedBy,0), COALESCE(t.orgId,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.docKey,0), COALESCE(t.profileId,0), COALESCE(t.words,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(messageId,0), COALESCE(messageType,0), COALESCE(message,0), COALESCE(orignalSentiment,0), COALESCE(orignalClassified,0), COALESCE(newSentiment,0), COALESCE(newClassified,0), COALESCE(approved,0), COALESCE(changedBy,0), COALESCE(orgId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(docKey,0), COALESCE(profileId,0), COALESCE(words,0)
            FROM ',source_db,'.t_sentiment_changed ) ) AS p ) as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_sentiment_changed where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_sentiment_changed r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.messageId,0), COALESCE(r.messageType,0), COALESCE(r.message,0), COALESCE(r.orignalSentiment,0), COALESCE(r.orignalClassified,0), COALESCE(r.newSentiment,0), COALESCE(r.newClassified,0), COALESCE(r.approved,0), COALESCE(r.changedBy,0), COALESCE(r.orgId,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.docKey,0), COALESCE(r.profileId,0), COALESCE(r.words,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(messageId,0), COALESCE(messageType,0), COALESCE(message,0), COALESCE(orignalSentiment,0), COALESCE(orignalClassified,0), COALESCE(newSentiment,0), COALESCE(newClassified,0), COALESCE(approved,0), COALESCE(changedBy,0), COALESCE(orgId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(docKey,0), COALESCE(profileId,0), COALESCE(words,0)
            FROM ',archived_db,'.t_sentiment_changed) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_sentiment_changed t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.messageId,0), COALESCE(t.messageType,0), COALESCE(t.message,0), COALESCE(t.orignalSentiment,0), COALESCE(t.orignalClassified,0), COALESCE(t.newSentiment,0), COALESCE(t.newClassified,0), COALESCE(t.approved,0), COALESCE(t.changedBy,0), COALESCE(t.orgId,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.docKey,0), COALESCE(t.profileId,0), COALESCE(t.words,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(messageId,0), COALESCE(messageType,0), COALESCE(message,0), COALESCE(orignalSentiment,0), COALESCE(orignalClassified,0), COALESCE(newSentiment,0), COALESCE(newClassified,0), COALESCE(approved,0), COALESCE(changedBy,0), COALESCE(orgId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(docKey,0), COALESCE(profileId,0), COALESCE(words,0)
            FROM ',source_db,'.t_sentiment_changed ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_srid_dtls;

DELIMITER //
CREATE PROCEDURE  `purge_t_srid_dtls`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_srid_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.docKey,0), COALESCE(r.workId,0), COALESCE(r.work_parentId,0), COALESCE(r.srType,0), COALESCE(r.srSubType,0), COALESCE(r.storeName,0), COALESCE(r.Date,0), COALESCE(r.flc,0), COALESCE(r.closedOn,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.SR_NUMBER,0), COALESCE(r.CUSTOMER_CELL_NUMBER,0), COALESCE(r.CUSTOMER_NAME,0), COALESCE(r.SR_CATEGORY,0), COALESCE(r.INITIAL_OUTCOME,0), COALESCE(r.LATEST_OUTCOME,0), COALESCE(r.CLOSE_LOOPING_OUTCOME,0), COALESCE(r.CREATION_DATE,0), COALESCE(r.CREATED_BY_GROUP,0), COALESCE(r.CREATED_BY_USER,0), COALESCE(r.IS_FRONT_LINE_CLOSURE,0), COALESCE(r.LAST_UPDATION_DATE,0), COALESCE(r.SR_SOFT_CLOSURE_DATE_TIME,0), COALESCE(r.LAST_UPDATED_BY_GROUP,0), COALESCE(r.LAST_UPDATED_BY_USER,0), COALESCE(r.CLOSE_LOOPING_DATE,0), COALESCE(r.CLOSE_LOOPING_BY_GROUP,0), COALESCE(r.CLOSE_LOOPING_BY_USER,0), COALESCE(r.EXPECTED_TAT,0), COALESCE(r.SR_DUE_DATE,0), COALESCE(r.ACTUAL_TAT,0), COALESCE(r.SR_STATUS,0), COALESCE(r.ESCALATION_LEVEL,0), COALESCE(r.ASSIGNED_GROUP,0), COALESCE(r.ASSIGNED_USER,0), COALESCE(r.REVISED_DUE_DATE,0), COALESCE(r.REVISED_TAT,0), COALESCE(r.MEDIA,0), COALESCE(r.MOOD_OF_INTERACTION,0), COALESCE(r.CLOSE_LOOPING_MEDIA,0), COALESCE(r.CALLBACK_REQUIRED,0), COALESCE(r.CUSTOMER_SEGMENT,0), COALESCE(r.CUSTOMER_CATEGORY,0), COALESCE(r.CONTRACT_ID,0), COALESCE(r.LOCATION,0), COALESCE(r.DFF1,0), COALESCE(r.DFF2,0), COALESCE(r.DFF3,0), COALESCE(r.DFF4,0), COALESCE(r.DFF5,0), COALESCE(r.DFF6,0), COALESCE(r.DFF7,0), COALESCE(r.DFF8,0), COALESCE(r.DFF9,0), COALESCE(r.DFF10,0), COALESCE(r.DFF11,0), COALESCE(r.DFF12,0), COALESCE(r.DFF14,0), COALESCE(r.DFF15,0), COALESCE(r.DFF13,0), COALESCE(r.ROAMING_USER,0), COALESCE(r.ROAMING_USER_GROUP,0), COALESCE(r.ROAMING_CIRCLE,0), COALESCE(r.ACTIVE_FROM,0), COALESCE(r.REPEAT_INCIDENT_NUMBER,0), COALESCE(r.CORPORATE_ENTERPRISE_CODE,0), COALESCE(r.CORPORATE_ENTERPRISE_DESCRIPTION,0), COALESCE(r.Enterprise_Area_Description,0), COALESCE(r.CITY,0), COALESCE(r.SR_SOFT_CLOSURE_NAME,0), COALESCE(r.SR_SOFT_CLOSURE_GROUP,0), COALESCE(r.BOUNCED_SR,0), COALESCE(r.Circle_ID,0), COALESCE(r.dumpFileName,0), COALESCE(r.dumpRowNumber,0), COALESCE(r.dumpUpdatedOn,0), COALESCE(r.phoneType,0), COALESCE(r.jmsMessageId,0), COALESCE(r.srErrorStatus,0), COALESCE(r.srErrorCode,0), COALESCE(r.srErrorDesc,0), COALESCE(r.srCreatedOn,0), COALESCE(r.srUpdatedOn,0), COALESCE(r.userId,0), COALESCE(r.migrated,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(docKey,0), COALESCE(workId,0), COALESCE(work_parentId,0), COALESCE(srType,0), COALESCE(srSubType,0), COALESCE(storeName,0), COALESCE(Date,0), COALESCE(flc,0), COALESCE(closedOn,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(SR_NUMBER,0), COALESCE(CUSTOMER_CELL_NUMBER,0), COALESCE(CUSTOMER_NAME,0), COALESCE(SR_CATEGORY,0), COALESCE(INITIAL_OUTCOME,0), COALESCE(LATEST_OUTCOME,0), COALESCE(CLOSE_LOOPING_OUTCOME,0), COALESCE(CREATION_DATE,0), COALESCE(CREATED_BY_GROUP,0), COALESCE(CREATED_BY_USER,0), COALESCE(IS_FRONT_LINE_CLOSURE,0), COALESCE(LAST_UPDATION_DATE,0), COALESCE(SR_SOFT_CLOSURE_DATE_TIME,0), COALESCE(LAST_UPDATED_BY_GROUP,0), COALESCE(LAST_UPDATED_BY_USER,0), COALESCE(CLOSE_LOOPING_DATE,0), COALESCE(CLOSE_LOOPING_BY_GROUP,0), COALESCE(CLOSE_LOOPING_BY_USER,0), COALESCE(EXPECTED_TAT,0), COALESCE(SR_DUE_DATE,0), COALESCE(ACTUAL_TAT,0), COALESCE(SR_STATUS,0), COALESCE(ESCALATION_LEVEL,0), COALESCE(ASSIGNED_GROUP,0), COALESCE(ASSIGNED_USER,0), COALESCE(REVISED_DUE_DATE,0), COALESCE(REVISED_TAT,0), COALESCE(MEDIA,0), COALESCE(MOOD_OF_INTERACTION,0), COALESCE(CLOSE_LOOPING_MEDIA,0), COALESCE(CALLBACK_REQUIRED,0), COALESCE(CUSTOMER_SEGMENT,0), COALESCE(CUSTOMER_CATEGORY,0), COALESCE(CONTRACT_ID,0), COALESCE(LOCATION,0), COALESCE(DFF1,0), COALESCE(DFF2,0), COALESCE(DFF3,0), COALESCE(DFF4,0), COALESCE(DFF5,0), COALESCE(DFF6,0), COALESCE(DFF7,0), COALESCE(DFF8,0), COALESCE(DFF9,0), COALESCE(DFF10,0), COALESCE(DFF11,0), COALESCE(DFF12,0), COALESCE(DFF14,0), COALESCE(DFF15,0), COALESCE(DFF13,0), COALESCE(ROAMING_USER,0), COALESCE(ROAMING_USER_GROUP,0), COALESCE(ROAMING_CIRCLE,0), COALESCE(ACTIVE_FROM,0), COALESCE(REPEAT_INCIDENT_NUMBER,0), COALESCE(CORPORATE_ENTERPRISE_CODE,0), COALESCE(CORPORATE_ENTERPRISE_DESCRIPTION,0), COALESCE(Enterprise_Area_Description,0), COALESCE(CITY,0), COALESCE(SR_SOFT_CLOSURE_NAME,0), COALESCE(SR_SOFT_CLOSURE_GROUP,0), COALESCE(BOUNCED_SR,0), COALESCE(Circle_ID,0), COALESCE(dumpFileName,0), COALESCE(dumpRowNumber,0), COALESCE(dumpUpdatedOn,0), COALESCE(phoneType,0), COALESCE(jmsMessageId,0), COALESCE(srErrorStatus,0), COALESCE(srErrorCode,0), COALESCE(srErrorDesc,0), COALESCE(srCreatedOn,0), COALESCE(srUpdatedOn,0), COALESCE(userId,0), COALESCE(migrated,0)
            FROM ',archived_db,'.t_srid_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_srid_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.docKey,0), COALESCE(t.workId,0), COALESCE(t.work_parentId,0), COALESCE(t.srType,0), COALESCE(t.srSubType,0), COALESCE(t.storeName,0), COALESCE(t.Date,0), COALESCE(t.flc,0), COALESCE(t.closedOn,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.SR_NUMBER,0), COALESCE(t.CUSTOMER_CELL_NUMBER,0), COALESCE(t.CUSTOMER_NAME,0), COALESCE(t.SR_CATEGORY,0), COALESCE(t.INITIAL_OUTCOME,0), COALESCE(t.LATEST_OUTCOME,0), COALESCE(t.CLOSE_LOOPING_OUTCOME,0), COALESCE(t.CREATION_DATE,0), COALESCE(t.CREATED_BY_GROUP,0), COALESCE(t.CREATED_BY_USER,0), COALESCE(t.IS_FRONT_LINE_CLOSURE,0), COALESCE(t.LAST_UPDATION_DATE,0), COALESCE(t.SR_SOFT_CLOSURE_DATE_TIME,0), COALESCE(t.LAST_UPDATED_BY_GROUP,0), COALESCE(t.LAST_UPDATED_BY_USER,0), COALESCE(t.CLOSE_LOOPING_DATE,0), COALESCE(t.CLOSE_LOOPING_BY_GROUP,0), COALESCE(t.CLOSE_LOOPING_BY_USER,0), COALESCE(t.EXPECTED_TAT,0), COALESCE(t.SR_DUE_DATE,0), COALESCE(t.ACTUAL_TAT,0), COALESCE(t.SR_STATUS,0), COALESCE(t.ESCALATION_LEVEL,0), COALESCE(t.ASSIGNED_GROUP,0), COALESCE(t.ASSIGNED_USER,0), COALESCE(t.REVISED_DUE_DATE,0), COALESCE(t.REVISED_TAT,0), COALESCE(t.MEDIA,0), COALESCE(t.MOOD_OF_INTERACTION,0), COALESCE(t.CLOSE_LOOPING_MEDIA,0), COALESCE(t.CALLBACK_REQUIRED,0), COALESCE(t.CUSTOMER_SEGMENT,0), COALESCE(t.CUSTOMER_CATEGORY,0), COALESCE(t.CONTRACT_ID,0), COALESCE(t.LOCATION,0), COALESCE(t.DFF1,0), COALESCE(t.DFF2,0), COALESCE(t.DFF3,0), COALESCE(t.DFF4,0), COALESCE(t.DFF5,0), COALESCE(t.DFF6,0), COALESCE(t.DFF7,0), COALESCE(t.DFF8,0), COALESCE(t.DFF9,0), COALESCE(t.DFF10,0), COALESCE(t.DFF11,0), COALESCE(t.DFF12,0), COALESCE(t.DFF14,0), COALESCE(t.DFF15,0), COALESCE(t.DFF13,0), COALESCE(t.ROAMING_USER,0), COALESCE(t.ROAMING_USER_GROUP,0), COALESCE(t.ROAMING_CIRCLE,0), COALESCE(t.ACTIVE_FROM,0), COALESCE(t.REPEAT_INCIDENT_NUMBER,0), COALESCE(t.CORPORATE_ENTERPRISE_CODE,0), COALESCE(t.CORPORATE_ENTERPRISE_DESCRIPTION,0), COALESCE(t.Enterprise_Area_Description,0), COALESCE(t.CITY,0), COALESCE(t.SR_SOFT_CLOSURE_NAME,0), COALESCE(t.SR_SOFT_CLOSURE_GROUP,0), COALESCE(t.BOUNCED_SR,0), COALESCE(t.Circle_ID,0), COALESCE(t.dumpFileName,0), COALESCE(t.dumpRowNumber,0), COALESCE(t.dumpUpdatedOn,0), COALESCE(t.phoneType,0), COALESCE(t.jmsMessageId,0), COALESCE(t.srErrorStatus,0), COALESCE(t.srErrorCode,0), COALESCE(t.srErrorDesc,0), COALESCE(t.srCreatedOn,0), COALESCE(t.srUpdatedOn,0), COALESCE(t.userId,0), COALESCE(t.migrated,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(docKey,0), COALESCE(workId,0), COALESCE(work_parentId,0), COALESCE(srType,0), COALESCE(srSubType,0), COALESCE(storeName,0), COALESCE(Date,0), COALESCE(flc,0), COALESCE(closedOn,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(SR_NUMBER,0), COALESCE(CUSTOMER_CELL_NUMBER,0), COALESCE(CUSTOMER_NAME,0), COALESCE(SR_CATEGORY,0), COALESCE(INITIAL_OUTCOME,0), COALESCE(LATEST_OUTCOME,0), COALESCE(CLOSE_LOOPING_OUTCOME,0), COALESCE(CREATION_DATE,0), COALESCE(CREATED_BY_GROUP,0), COALESCE(CREATED_BY_USER,0), COALESCE(IS_FRONT_LINE_CLOSURE,0), COALESCE(LAST_UPDATION_DATE,0), COALESCE(SR_SOFT_CLOSURE_DATE_TIME,0), COALESCE(LAST_UPDATED_BY_GROUP,0), COALESCE(LAST_UPDATED_BY_USER,0), COALESCE(CLOSE_LOOPING_DATE,0), COALESCE(CLOSE_LOOPING_BY_GROUP,0), COALESCE(CLOSE_LOOPING_BY_USER,0), COALESCE(EXPECTED_TAT,0), COALESCE(SR_DUE_DATE,0), COALESCE(ACTUAL_TAT,0), COALESCE(SR_STATUS,0), COALESCE(ESCALATION_LEVEL,0), COALESCE(ASSIGNED_GROUP,0), COALESCE(ASSIGNED_USER,0), COALESCE(REVISED_DUE_DATE,0), COALESCE(REVISED_TAT,0), COALESCE(MEDIA,0), COALESCE(MOOD_OF_INTERACTION,0), COALESCE(CLOSE_LOOPING_MEDIA,0), COALESCE(CALLBACK_REQUIRED,0), COALESCE(CUSTOMER_SEGMENT,0), COALESCE(CUSTOMER_CATEGORY,0), COALESCE(CONTRACT_ID,0), COALESCE(LOCATION,0), COALESCE(DFF1,0), COALESCE(DFF2,0), COALESCE(DFF3,0), COALESCE(DFF4,0), COALESCE(DFF5,0), COALESCE(DFF6,0), COALESCE(DFF7,0), COALESCE(DFF8,0), COALESCE(DFF9,0), COALESCE(DFF10,0), COALESCE(DFF11,0), COALESCE(DFF12,0), COALESCE(DFF14,0), COALESCE(DFF15,0), COALESCE(DFF13,0), COALESCE(ROAMING_USER,0), COALESCE(ROAMING_USER_GROUP,0), COALESCE(ROAMING_CIRCLE,0), COALESCE(ACTIVE_FROM,0), COALESCE(REPEAT_INCIDENT_NUMBER,0), COALESCE(CORPORATE_ENTERPRISE_CODE,0), COALESCE(CORPORATE_ENTERPRISE_DESCRIPTION,0), COALESCE(Enterprise_Area_Description,0), COALESCE(CITY,0), COALESCE(SR_SOFT_CLOSURE_NAME,0), COALESCE(SR_SOFT_CLOSURE_GROUP,0), COALESCE(BOUNCED_SR,0), COALESCE(Circle_ID,0), COALESCE(dumpFileName,0), COALESCE(dumpRowNumber,0), COALESCE(dumpUpdatedOn,0), COALESCE(phoneType,0), COALESCE(jmsMessageId,0), COALESCE(srErrorStatus,0), COALESCE(srErrorCode,0), COALESCE(srErrorDesc,0), COALESCE(srCreatedOn,0), COALESCE(srUpdatedOn,0), COALESCE(userId,0), COALESCE(migrated,0)
            FROM ',source_db,'.t_srid_dtls ) ) AS p ) as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_srid_dtls where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_srid_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.docKey,0), COALESCE(r.workId,0), COALESCE(r.work_parentId,0), COALESCE(r.srType,0), COALESCE(r.srSubType,0), COALESCE(r.storeName,0), COALESCE(r.Date,0), COALESCE(r.flc,0), COALESCE(r.closedOn,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.SR_NUMBER,0), COALESCE(r.CUSTOMER_CELL_NUMBER,0), COALESCE(r.CUSTOMER_NAME,0), COALESCE(r.SR_CATEGORY,0), COALESCE(r.INITIAL_OUTCOME,0), COALESCE(r.LATEST_OUTCOME,0), COALESCE(r.CLOSE_LOOPING_OUTCOME,0), COALESCE(r.CREATION_DATE,0), COALESCE(r.CREATED_BY_GROUP,0), COALESCE(r.CREATED_BY_USER,0), COALESCE(r.IS_FRONT_LINE_CLOSURE,0), COALESCE(r.LAST_UPDATION_DATE,0), COALESCE(r.SR_SOFT_CLOSURE_DATE_TIME,0), COALESCE(r.LAST_UPDATED_BY_GROUP,0), COALESCE(r.LAST_UPDATED_BY_USER,0), COALESCE(r.CLOSE_LOOPING_DATE,0), COALESCE(r.CLOSE_LOOPING_BY_GROUP,0), COALESCE(r.CLOSE_LOOPING_BY_USER,0), COALESCE(r.EXPECTED_TAT,0), COALESCE(r.SR_DUE_DATE,0), COALESCE(r.ACTUAL_TAT,0), COALESCE(r.SR_STATUS,0), COALESCE(r.ESCALATION_LEVEL,0), COALESCE(r.ASSIGNED_GROUP,0), COALESCE(r.ASSIGNED_USER,0), COALESCE(r.REVISED_DUE_DATE,0), COALESCE(r.REVISED_TAT,0), COALESCE(r.MEDIA,0), COALESCE(r.MOOD_OF_INTERACTION,0), COALESCE(r.CLOSE_LOOPING_MEDIA,0), COALESCE(r.CALLBACK_REQUIRED,0), COALESCE(r.CUSTOMER_SEGMENT,0), COALESCE(r.CUSTOMER_CATEGORY,0), COALESCE(r.CONTRACT_ID,0), COALESCE(r.LOCATION,0), COALESCE(r.DFF1,0), COALESCE(r.DFF2,0), COALESCE(r.DFF3,0), COALESCE(r.DFF4,0), COALESCE(r.DFF5,0), COALESCE(r.DFF6,0), COALESCE(r.DFF7,0), COALESCE(r.DFF8,0), COALESCE(r.DFF9,0), COALESCE(r.DFF10,0), COALESCE(r.DFF11,0), COALESCE(r.DFF12,0), COALESCE(r.DFF14,0), COALESCE(r.DFF15,0), COALESCE(r.DFF13,0), COALESCE(r.ROAMING_USER,0), COALESCE(r.ROAMING_USER_GROUP,0), COALESCE(r.ROAMING_CIRCLE,0), COALESCE(r.ACTIVE_FROM,0), COALESCE(r.REPEAT_INCIDENT_NUMBER,0), COALESCE(r.CORPORATE_ENTERPRISE_CODE,0), COALESCE(r.CORPORATE_ENTERPRISE_DESCRIPTION,0), COALESCE(r.Enterprise_Area_Description,0), COALESCE(r.CITY,0), COALESCE(r.SR_SOFT_CLOSURE_NAME,0), COALESCE(r.SR_SOFT_CLOSURE_GROUP,0), COALESCE(r.BOUNCED_SR,0), COALESCE(r.Circle_ID,0), COALESCE(r.dumpFileName,0), COALESCE(r.dumpRowNumber,0), COALESCE(r.dumpUpdatedOn,0), COALESCE(r.phoneType,0), COALESCE(r.jmsMessageId,0), COALESCE(r.srErrorStatus,0), COALESCE(r.srErrorCode,0), COALESCE(r.srErrorDesc,0), COALESCE(r.srCreatedOn,0), COALESCE(r.srUpdatedOn,0), COALESCE(r.userId,0), COALESCE(r.migrated,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(docKey,0), COALESCE(workId,0), COALESCE(work_parentId,0), COALESCE(srType,0), COALESCE(srSubType,0), COALESCE(storeName,0), COALESCE(Date,0), COALESCE(flc,0), COALESCE(closedOn,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(SR_NUMBER,0), COALESCE(CUSTOMER_CELL_NUMBER,0), COALESCE(CUSTOMER_NAME,0), COALESCE(SR_CATEGORY,0), COALESCE(INITIAL_OUTCOME,0), COALESCE(LATEST_OUTCOME,0), COALESCE(CLOSE_LOOPING_OUTCOME,0), COALESCE(CREATION_DATE,0), COALESCE(CREATED_BY_GROUP,0), COALESCE(CREATED_BY_USER,0), COALESCE(IS_FRONT_LINE_CLOSURE,0), COALESCE(LAST_UPDATION_DATE,0), COALESCE(SR_SOFT_CLOSURE_DATE_TIME,0), COALESCE(LAST_UPDATED_BY_GROUP,0), COALESCE(LAST_UPDATED_BY_USER,0), COALESCE(CLOSE_LOOPING_DATE,0), COALESCE(CLOSE_LOOPING_BY_GROUP,0), COALESCE(CLOSE_LOOPING_BY_USER,0), COALESCE(EXPECTED_TAT,0), COALESCE(SR_DUE_DATE,0), COALESCE(ACTUAL_TAT,0), COALESCE(SR_STATUS,0), COALESCE(ESCALATION_LEVEL,0), COALESCE(ASSIGNED_GROUP,0), COALESCE(ASSIGNED_USER,0), COALESCE(REVISED_DUE_DATE,0), COALESCE(REVISED_TAT,0), COALESCE(MEDIA,0), COALESCE(MOOD_OF_INTERACTION,0), COALESCE(CLOSE_LOOPING_MEDIA,0), COALESCE(CALLBACK_REQUIRED,0), COALESCE(CUSTOMER_SEGMENT,0), COALESCE(CUSTOMER_CATEGORY,0), COALESCE(CONTRACT_ID,0), COALESCE(LOCATION,0), COALESCE(DFF1,0), COALESCE(DFF2,0), COALESCE(DFF3,0), COALESCE(DFF4,0), COALESCE(DFF5,0), COALESCE(DFF6,0), COALESCE(DFF7,0), COALESCE(DFF8,0), COALESCE(DFF9,0), COALESCE(DFF10,0), COALESCE(DFF11,0), COALESCE(DFF12,0), COALESCE(DFF14,0), COALESCE(DFF15,0), COALESCE(DFF13,0), COALESCE(ROAMING_USER,0), COALESCE(ROAMING_USER_GROUP,0), COALESCE(ROAMING_CIRCLE,0), COALESCE(ACTIVE_FROM,0), COALESCE(REPEAT_INCIDENT_NUMBER,0), COALESCE(CORPORATE_ENTERPRISE_CODE,0), COALESCE(CORPORATE_ENTERPRISE_DESCRIPTION,0), COALESCE(Enterprise_Area_Description,0), COALESCE(CITY,0), COALESCE(SR_SOFT_CLOSURE_NAME,0), COALESCE(SR_SOFT_CLOSURE_GROUP,0), COALESCE(BOUNCED_SR,0), COALESCE(Circle_ID,0), COALESCE(dumpFileName,0), COALESCE(dumpRowNumber,0), COALESCE(dumpUpdatedOn,0), COALESCE(phoneType,0), COALESCE(jmsMessageId,0), COALESCE(srErrorStatus,0), COALESCE(srErrorCode,0), COALESCE(srErrorDesc,0), COALESCE(srCreatedOn,0), COALESCE(srUpdatedOn,0), COALESCE(userId,0), COALESCE(migrated,0)
            FROM ',archived_db,'.t_srid_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_srid_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.docKey,0), COALESCE(t.workId,0), COALESCE(t.work_parentId,0), COALESCE(t.srType,0), COALESCE(t.srSubType,0), COALESCE(t.storeName,0), COALESCE(t.Date,0), COALESCE(t.flc,0), COALESCE(t.closedOn,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.SR_NUMBER,0), COALESCE(t.CUSTOMER_CELL_NUMBER,0), COALESCE(t.CUSTOMER_NAME,0), COALESCE(t.SR_CATEGORY,0), COALESCE(t.INITIAL_OUTCOME,0), COALESCE(t.LATEST_OUTCOME,0), COALESCE(t.CLOSE_LOOPING_OUTCOME,0), COALESCE(t.CREATION_DATE,0), COALESCE(t.CREATED_BY_GROUP,0), COALESCE(t.CREATED_BY_USER,0), COALESCE(t.IS_FRONT_LINE_CLOSURE,0), COALESCE(t.LAST_UPDATION_DATE,0), COALESCE(t.SR_SOFT_CLOSURE_DATE_TIME,0), COALESCE(t.LAST_UPDATED_BY_GROUP,0), COALESCE(t.LAST_UPDATED_BY_USER,0), COALESCE(t.CLOSE_LOOPING_DATE,0), COALESCE(t.CLOSE_LOOPING_BY_GROUP,0), COALESCE(t.CLOSE_LOOPING_BY_USER,0), COALESCE(t.EXPECTED_TAT,0), COALESCE(t.SR_DUE_DATE,0), COALESCE(t.ACTUAL_TAT,0), COALESCE(t.SR_STATUS,0), COALESCE(t.ESCALATION_LEVEL,0), COALESCE(t.ASSIGNED_GROUP,0), COALESCE(t.ASSIGNED_USER,0), COALESCE(t.REVISED_DUE_DATE,0), COALESCE(t.REVISED_TAT,0), COALESCE(t.MEDIA,0), COALESCE(t.MOOD_OF_INTERACTION,0), COALESCE(t.CLOSE_LOOPING_MEDIA,0), COALESCE(t.CALLBACK_REQUIRED,0), COALESCE(t.CUSTOMER_SEGMENT,0), COALESCE(t.CUSTOMER_CATEGORY,0), COALESCE(t.CONTRACT_ID,0), COALESCE(t.LOCATION,0), COALESCE(t.DFF1,0), COALESCE(t.DFF2,0), COALESCE(t.DFF3,0), COALESCE(t.DFF4,0), COALESCE(t.DFF5,0), COALESCE(t.DFF6,0), COALESCE(t.DFF7,0), COALESCE(t.DFF8,0), COALESCE(t.DFF9,0), COALESCE(t.DFF10,0), COALESCE(t.DFF11,0), COALESCE(t.DFF12,0), COALESCE(t.DFF14,0), COALESCE(t.DFF15,0), COALESCE(t.DFF13,0), COALESCE(t.ROAMING_USER,0), COALESCE(t.ROAMING_USER_GROUP,0), COALESCE(t.ROAMING_CIRCLE,0), COALESCE(t.ACTIVE_FROM,0), COALESCE(t.REPEAT_INCIDENT_NUMBER,0), COALESCE(t.CORPORATE_ENTERPRISE_CODE,0), COALESCE(t.CORPORATE_ENTERPRISE_DESCRIPTION,0), COALESCE(t.Enterprise_Area_Description,0), COALESCE(t.CITY,0), COALESCE(t.SR_SOFT_CLOSURE_NAME,0), COALESCE(t.SR_SOFT_CLOSURE_GROUP,0), COALESCE(t.BOUNCED_SR,0), COALESCE(t.Circle_ID,0), COALESCE(t.dumpFileName,0), COALESCE(t.dumpRowNumber,0), COALESCE(t.dumpUpdatedOn,0), COALESCE(t.phoneType,0), COALESCE(t.jmsMessageId,0), COALESCE(t.srErrorStatus,0), COALESCE(t.srErrorCode,0), COALESCE(t.srErrorDesc,0), COALESCE(t.srCreatedOn,0), COALESCE(t.srUpdatedOn,0), COALESCE(t.userId,0), COALESCE(t.migrated,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(docKey,0), COALESCE(workId,0), COALESCE(work_parentId,0), COALESCE(srType,0), COALESCE(srSubType,0), COALESCE(storeName,0), COALESCE(Date,0), COALESCE(flc,0), COALESCE(closedOn,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(SR_NUMBER,0), COALESCE(CUSTOMER_CELL_NUMBER,0), COALESCE(CUSTOMER_NAME,0), COALESCE(SR_CATEGORY,0), COALESCE(INITIAL_OUTCOME,0), COALESCE(LATEST_OUTCOME,0), COALESCE(CLOSE_LOOPING_OUTCOME,0), COALESCE(CREATION_DATE,0), COALESCE(CREATED_BY_GROUP,0), COALESCE(CREATED_BY_USER,0), COALESCE(IS_FRONT_LINE_CLOSURE,0), COALESCE(LAST_UPDATION_DATE,0), COALESCE(SR_SOFT_CLOSURE_DATE_TIME,0), COALESCE(LAST_UPDATED_BY_GROUP,0), COALESCE(LAST_UPDATED_BY_USER,0), COALESCE(CLOSE_LOOPING_DATE,0), COALESCE(CLOSE_LOOPING_BY_GROUP,0), COALESCE(CLOSE_LOOPING_BY_USER,0), COALESCE(EXPECTED_TAT,0), COALESCE(SR_DUE_DATE,0), COALESCE(ACTUAL_TAT,0), COALESCE(SR_STATUS,0), COALESCE(ESCALATION_LEVEL,0), COALESCE(ASSIGNED_GROUP,0), COALESCE(ASSIGNED_USER,0), COALESCE(REVISED_DUE_DATE,0), COALESCE(REVISED_TAT,0), COALESCE(MEDIA,0), COALESCE(MOOD_OF_INTERACTION,0), COALESCE(CLOSE_LOOPING_MEDIA,0), COALESCE(CALLBACK_REQUIRED,0), COALESCE(CUSTOMER_SEGMENT,0), COALESCE(CUSTOMER_CATEGORY,0), COALESCE(CONTRACT_ID,0), COALESCE(LOCATION,0), COALESCE(DFF1,0), COALESCE(DFF2,0), COALESCE(DFF3,0), COALESCE(DFF4,0), COALESCE(DFF5,0), COALESCE(DFF6,0), COALESCE(DFF7,0), COALESCE(DFF8,0), COALESCE(DFF9,0), COALESCE(DFF10,0), COALESCE(DFF11,0), COALESCE(DFF12,0), COALESCE(DFF14,0), COALESCE(DFF15,0), COALESCE(DFF13,0), COALESCE(ROAMING_USER,0), COALESCE(ROAMING_USER_GROUP,0), COALESCE(ROAMING_CIRCLE,0), COALESCE(ACTIVE_FROM,0), COALESCE(REPEAT_INCIDENT_NUMBER,0), COALESCE(CORPORATE_ENTERPRISE_CODE,0), COALESCE(CORPORATE_ENTERPRISE_DESCRIPTION,0), COALESCE(Enterprise_Area_Description,0), COALESCE(CITY,0), COALESCE(SR_SOFT_CLOSURE_NAME,0), COALESCE(SR_SOFT_CLOSURE_GROUP,0), COALESCE(BOUNCED_SR,0), COALESCE(Circle_ID,0), COALESCE(dumpFileName,0), COALESCE(dumpRowNumber,0), COALESCE(dumpUpdatedOn,0), COALESCE(phoneType,0), COALESCE(jmsMessageId,0), COALESCE(srErrorStatus,0), COALESCE(srErrorCode,0), COALESCE(srErrorDesc,0), COALESCE(srCreatedOn,0), COALESCE(srUpdatedOn,0), COALESCE(userId,0), COALESCE(migrated,0)
            FROM ',source_db,'.t_srid_dtls ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_workflow_dtls;

DELIMITER //
CREATE PROCEDURE `purge_t_workflow_dtls`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_workflow_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.msgId,0), COALESCE(r.fromOrgId,0), COALESCE(r.orgId,0), COALESCE(r.fromUserId,0), COALESCE(r.toUserId,0), COALESCE(r.fromBasketId,0), COALESCE(r.toBasketId,0), COALESCE(r.ruleId,0), COALESCE(r.lockedBy,0), COALESCE(r.locked,0), COALESCE(r.lockNote,0), COALESCE(r.priority,0), COALESCE(r.message,0), COALESCE(r.responseMsg,0), COALESCE(r.channel,0), COALESCE(r.action,0), COALESCE(r.callerType,0), COALESCE(r.parentId,0), COALESCE(r.sourceId,0), COALESCE(r.profileId,0), COALESCE(r.dataSource,0), COALESCE(r.currentlyActive,0), COALESCE(r.active,0), COALESCE(r.actionDate,0), COALESCE(r.messageCapturedOn,0), COALESCE(r.msgCreatedOn,0), COALESCE(r.actionStartDate,0), COALESCE(r.updatedOn,0), COALESCE(r.createdOn,0), COALESCE(r.sentiment,0), COALESCE(r.classified,0), COALESCE(r.language,0), COALESCE(r.country,0), COALESCE(r.channelId,0), COALESCE(r.a_arank,0), COALESCE(r.a_grank,0), COALESCE(r.kloutscore,0), COALESCE(r.sex,0), COALESCE(r.age,0), COALESCE(r.frenCnt,0), COALESCE(r.follCnt,0), COALESCE(r.listedCnt,0), COALESCE(r.influenceScore,0), COALESCE(r.surveyId,0), COALESCE(r.priorityScore,0), COALESCE(r.scoreJson,0), COALESCE(r.slaId,0), COALESCE(r.slaTriggered,0), COALESCE(r.userChannelId,0), COALESCE(r.attached,0), COALESCE(r.caseAssociated,0), COALESCE(r.detachAllowed,0), COALESCE(r.detachedBy,0), COALESCE(r.detachedFrom,0), COALESCE(r.tatCalculated,0), COALESCE(r.tatValue,0), COALESCE(r.csatSent,0), COALESCE(r.csatResponse,0), COALESCE(r.csatSentDate,0), COALESCE(r.csatRespDate,0), COALESCE(r.followUpOn,0), COALESCE(r.timeZone,0), COALESCE(r.followUpBy,0), COALESCE(r.assignByfollowUp,0), COALESCE(r.csatMessage,0), COALESCE(r.attempted,0), COALESCE(r.csatEligible,0), COALESCE(r.backOfficeType,0), COALESCE(r.recommendation,0), COALESCE(r.satisfaction,0), COALESCE(r.fix,0), COALESCE(r.verbatim,0), COALESCE(r.fromSoAccountId,0), COALESCE(r.inReplyToStatusId,0), COALESCE(r.customerType,0), COALESCE(r.dept,0), COALESCE(r.nonContactable,0), COALESCE(r.action_type,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(msgId,0), COALESCE(fromOrgId,0), COALESCE(orgId,0), COALESCE(fromUserId,0), COALESCE(toUserId,0), COALESCE(fromBasketId,0), COALESCE(toBasketId,0), COALESCE(ruleId,0), COALESCE(lockedBy,0), COALESCE(locked,0), COALESCE(lockNote,0), COALESCE(priority,0), COALESCE(message,0), COALESCE(responseMsg,0), COALESCE(channel,0), COALESCE(action,0), COALESCE(callerType,0), COALESCE(parentId,0), COALESCE(sourceId,0), COALESCE(profileId,0), COALESCE(dataSource,0), COALESCE(currentlyActive,0), COALESCE(active,0), COALESCE(actionDate,0), COALESCE(messageCapturedOn,0), COALESCE(msgCreatedOn,0), COALESCE(actionStartDate,0), COALESCE(updatedOn,0), COALESCE(createdOn,0), COALESCE(sentiment,0), COALESCE(classified,0), COALESCE(language,0), COALESCE(country,0), COALESCE(channelId,0), COALESCE(a_arank,0), COALESCE(a_grank,0), COALESCE(kloutscore,0), COALESCE(sex,0), COALESCE(age,0), COALESCE(frenCnt,0), COALESCE(follCnt,0), COALESCE(listedCnt,0), COALESCE(influenceScore,0), COALESCE(surveyId,0), COALESCE(priorityScore,0), COALESCE(scoreJson,0), COALESCE(slaId,0), COALESCE(slaTriggered,0), COALESCE(userChannelId,0), COALESCE(attached,0), COALESCE(caseAssociated,0), COALESCE(detachAllowed,0), COALESCE(detachedBy,0), COALESCE(detachedFrom,0), COALESCE(tatCalculated,0), COALESCE(tatValue,0), COALESCE(csatSent,0), COALESCE(csatResponse,0), COALESCE(csatSentDate,0), COALESCE(csatRespDate,0), COALESCE(followUpOn,0), COALESCE(timeZone,0), COALESCE(followUpBy,0), COALESCE(assignByfollowUp,0), COALESCE(csatMessage,0), COALESCE(attempted,0), COALESCE(csatEligible,0), COALESCE(backOfficeType,0), COALESCE(recommendation,0), COALESCE(satisfaction,0), COALESCE(fix,0), COALESCE(verbatim,0), COALESCE(fromSoAccountId,0), COALESCE(inReplyToStatusId,0), COALESCE(customerType,0), COALESCE(dept,0), COALESCE(nonContactable,0), COALESCE(action_type,0)
            FROM ',archived_db,'.t_workflow_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_workflow_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.msgId,0), COALESCE(t.fromOrgId,0), COALESCE(t.orgId,0), COALESCE(t.fromUserId,0), COALESCE(t.toUserId,0), COALESCE(t.fromBasketId,0), COALESCE(t.toBasketId,0), COALESCE(t.ruleId,0), COALESCE(t.lockedBy,0), COALESCE(t.locked,0), COALESCE(t.lockNote,0), COALESCE(t.priority,0), COALESCE(t.message,0), COALESCE(t.responseMsg,0), COALESCE(t.channel,0), COALESCE(t.action,0), COALESCE(t.callerType,0), COALESCE(t.parentId,0), COALESCE(t.sourceId,0), COALESCE(t.profileId,0), COALESCE(t.dataSource,0), COALESCE(t.currentlyActive,0), COALESCE(t.active,0), COALESCE(t.actionDate,0), COALESCE(t.messageCapturedOn,0), COALESCE(t.msgCreatedOn,0), COALESCE(t.actionStartDate,0), COALESCE(t.updatedOn,0), COALESCE(t.createdOn,0), COALESCE(t.sentiment,0), COALESCE(t.classified,0), COALESCE(t.language,0), COALESCE(t.country,0), COALESCE(t.channelId,0), COALESCE(t.a_arank,0), COALESCE(t.a_grank,0), COALESCE(t.kloutscore,0), COALESCE(t.sex,0), COALESCE(t.age,0), COALESCE(t.frenCnt,0), COALESCE(t.follCnt,0), COALESCE(t.listedCnt,0), COALESCE(t.influenceScore,0), COALESCE(t.surveyId,0), COALESCE(t.priorityScore,0), COALESCE(t.scoreJson,0), COALESCE(t.slaId,0), COALESCE(t.slaTriggered,0), COALESCE(t.userChannelId,0), COALESCE(t.attached,0), COALESCE(t.caseAssociated,0), COALESCE(t.detachAllowed,0), COALESCE(t.detachedBy,0), COALESCE(t.detachedFrom,0), COALESCE(t.tatCalculated,0), COALESCE(t.tatValue,0), COALESCE(t.csatSent,0), COALESCE(t.csatResponse,0), COALESCE(t.csatSentDate,0), COALESCE(t.csatRespDate,0), COALESCE(t.followUpOn,0), COALESCE(t.timeZone,0), COALESCE(t.followUpBy,0), COALESCE(t.assignByfollowUp,0), COALESCE(t.csatMessage,0), COALESCE(t.attempted,0), COALESCE(t.csatEligible,0), COALESCE(t.backOfficeType,0), COALESCE(t.recommendation,0), COALESCE(t.satisfaction,0), COALESCE(t.fix,0), COALESCE(t.verbatim,0), COALESCE(t.fromSoAccountId,0), COALESCE(t.inReplyToStatusId,0), COALESCE(t.customerType,0), COALESCE(t.dept,0), COALESCE(t.nonContactable,0), COALESCE(t.action_type,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(msgId,0), COALESCE(fromOrgId,0), COALESCE(orgId,0), COALESCE(fromUserId,0), COALESCE(toUserId,0), COALESCE(fromBasketId,0), COALESCE(toBasketId,0), COALESCE(ruleId,0), COALESCE(lockedBy,0), COALESCE(locked,0), COALESCE(lockNote,0), COALESCE(priority,0), COALESCE(message,0), COALESCE(responseMsg,0), COALESCE(channel,0), COALESCE(action,0), COALESCE(callerType,0), COALESCE(parentId,0), COALESCE(sourceId,0), COALESCE(profileId,0), COALESCE(dataSource,0), COALESCE(currentlyActive,0), COALESCE(active,0), COALESCE(actionDate,0), COALESCE(messageCapturedOn,0), COALESCE(msgCreatedOn,0), COALESCE(actionStartDate,0), COALESCE(updatedOn,0), COALESCE(createdOn,0), COALESCE(sentiment,0), COALESCE(classified,0), COALESCE(language,0), COALESCE(country,0), COALESCE(channelId,0), COALESCE(a_arank,0), COALESCE(a_grank,0), COALESCE(kloutscore,0), COALESCE(sex,0), COALESCE(age,0), COALESCE(frenCnt,0), COALESCE(follCnt,0), COALESCE(listedCnt,0), COALESCE(influenceScore,0), COALESCE(surveyId,0), COALESCE(priorityScore,0), COALESCE(scoreJson,0), COALESCE(slaId,0), COALESCE(slaTriggered,0), COALESCE(userChannelId,0), COALESCE(attached,0), COALESCE(caseAssociated,0), COALESCE(detachAllowed,0), COALESCE(detachedBy,0), COALESCE(detachedFrom,0), COALESCE(tatCalculated,0), COALESCE(tatValue,0), COALESCE(csatSent,0), COALESCE(csatResponse,0), COALESCE(csatSentDate,0), COALESCE(csatRespDate,0), COALESCE(followUpOn,0), COALESCE(timeZone,0), COALESCE(followUpBy,0), COALESCE(assignByfollowUp,0), COALESCE(csatMessage,0), COALESCE(attempted,0), COALESCE(csatEligible,0), COALESCE(backOfficeType,0), COALESCE(recommendation,0), COALESCE(satisfaction,0), COALESCE(fix,0), COALESCE(verbatim,0), COALESCE(fromSoAccountId,0), COALESCE(inReplyToStatusId,0), COALESCE(customerType,0), COALESCE(dept,0), COALESCE(nonContactable,0), COALESCE(action_type,0)
            FROM ',source_db,'.t_workflow_dtls ) ) AS p ) as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_workflow_dtls where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_workflow_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.msgId,0), COALESCE(r.fromOrgId,0), COALESCE(r.orgId,0), COALESCE(r.fromUserId,0), COALESCE(r.toUserId,0), COALESCE(r.fromBasketId,0), COALESCE(r.toBasketId,0), COALESCE(r.ruleId,0), COALESCE(r.lockedBy,0), COALESCE(r.locked,0), COALESCE(r.lockNote,0), COALESCE(r.priority,0), COALESCE(r.message,0), COALESCE(r.responseMsg,0), COALESCE(r.channel,0), COALESCE(r.action,0), COALESCE(r.callerType,0), COALESCE(r.parentId,0), COALESCE(r.sourceId,0), COALESCE(r.profileId,0), COALESCE(r.dataSource,0), COALESCE(r.currentlyActive,0), COALESCE(r.active,0), COALESCE(r.actionDate,0), COALESCE(r.messageCapturedOn,0), COALESCE(r.msgCreatedOn,0), COALESCE(r.actionStartDate,0), COALESCE(r.updatedOn,0), COALESCE(r.createdOn,0), COALESCE(r.sentiment,0), COALESCE(r.classified,0), COALESCE(r.language,0), COALESCE(r.country,0), COALESCE(r.channelId,0), COALESCE(r.a_arank,0), COALESCE(r.a_grank,0), COALESCE(r.kloutscore,0), COALESCE(r.sex,0), COALESCE(r.age,0), COALESCE(r.frenCnt,0), COALESCE(r.follCnt,0), COALESCE(r.listedCnt,0), COALESCE(r.influenceScore,0), COALESCE(r.surveyId,0), COALESCE(r.priorityScore,0), COALESCE(r.scoreJson,0), COALESCE(r.slaId,0), COALESCE(r.slaTriggered,0), COALESCE(r.userChannelId,0), COALESCE(r.attached,0), COALESCE(r.caseAssociated,0), COALESCE(r.detachAllowed,0), COALESCE(r.detachedBy,0), COALESCE(r.detachedFrom,0), COALESCE(r.tatCalculated,0), COALESCE(r.tatValue,0), COALESCE(r.csatSent,0), COALESCE(r.csatResponse,0), COALESCE(r.csatSentDate,0), COALESCE(r.csatRespDate,0), COALESCE(r.followUpOn,0), COALESCE(r.timeZone,0), COALESCE(r.followUpBy,0), COALESCE(r.assignByfollowUp,0), COALESCE(r.csatMessage,0), COALESCE(r.attempted,0), COALESCE(r.csatEligible,0), COALESCE(r.backOfficeType,0), COALESCE(r.recommendation,0), COALESCE(r.satisfaction,0), COALESCE(r.fix,0), COALESCE(r.verbatim,0), COALESCE(r.fromSoAccountId,0), COALESCE(r.inReplyToStatusId,0), COALESCE(r.customerType,0), COALESCE(r.dept,0), COALESCE(r.nonContactable,0), COALESCE(r.action_type,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(msgId,0), COALESCE(fromOrgId,0), COALESCE(orgId,0), COALESCE(fromUserId,0), COALESCE(toUserId,0), COALESCE(fromBasketId,0), COALESCE(toBasketId,0), COALESCE(ruleId,0), COALESCE(lockedBy,0), COALESCE(locked,0), COALESCE(lockNote,0), COALESCE(priority,0), COALESCE(message,0), COALESCE(responseMsg,0), COALESCE(channel,0), COALESCE(action,0), COALESCE(callerType,0), COALESCE(parentId,0), COALESCE(sourceId,0), COALESCE(profileId,0), COALESCE(dataSource,0), COALESCE(currentlyActive,0), COALESCE(active,0), COALESCE(actionDate,0), COALESCE(messageCapturedOn,0), COALESCE(msgCreatedOn,0), COALESCE(actionStartDate,0), COALESCE(updatedOn,0), COALESCE(createdOn,0), COALESCE(sentiment,0), COALESCE(classified,0), COALESCE(language,0), COALESCE(country,0), COALESCE(channelId,0), COALESCE(a_arank,0), COALESCE(a_grank,0), COALESCE(kloutscore,0), COALESCE(sex,0), COALESCE(age,0), COALESCE(frenCnt,0), COALESCE(follCnt,0), COALESCE(listedCnt,0), COALESCE(influenceScore,0), COALESCE(surveyId,0), COALESCE(priorityScore,0), COALESCE(scoreJson,0), COALESCE(slaId,0), COALESCE(slaTriggered,0), COALESCE(userChannelId,0), COALESCE(attached,0), COALESCE(caseAssociated,0), COALESCE(detachAllowed,0), COALESCE(detachedBy,0), COALESCE(detachedFrom,0), COALESCE(tatCalculated,0), COALESCE(tatValue,0), COALESCE(csatSent,0), COALESCE(csatResponse,0), COALESCE(csatSentDate,0), COALESCE(csatRespDate,0), COALESCE(followUpOn,0), COALESCE(timeZone,0), COALESCE(followUpBy,0), COALESCE(assignByfollowUp,0), COALESCE(csatMessage,0), COALESCE(attempted,0), COALESCE(csatEligible,0), COALESCE(backOfficeType,0), COALESCE(recommendation,0), COALESCE(satisfaction,0), COALESCE(fix,0), COALESCE(verbatim,0), COALESCE(fromSoAccountId,0), COALESCE(inReplyToStatusId,0), COALESCE(customerType,0), COALESCE(dept,0), COALESCE(nonContactable,0), COALESCE(action_type,0)
            FROM ',archived_db,'.t_workflow_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_workflow_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.msgId,0), COALESCE(t.fromOrgId,0), COALESCE(t.orgId,0), COALESCE(t.fromUserId,0), COALESCE(t.toUserId,0), COALESCE(t.fromBasketId,0), COALESCE(t.toBasketId,0), COALESCE(t.ruleId,0), COALESCE(t.lockedBy,0), COALESCE(t.locked,0), COALESCE(t.lockNote,0), COALESCE(t.priority,0), COALESCE(t.message,0), COALESCE(t.responseMsg,0), COALESCE(t.channel,0), COALESCE(t.action,0), COALESCE(t.callerType,0), COALESCE(t.parentId,0), COALESCE(t.sourceId,0), COALESCE(t.profileId,0), COALESCE(t.dataSource,0), COALESCE(t.currentlyActive,0), COALESCE(t.active,0), COALESCE(t.actionDate,0), COALESCE(t.messageCapturedOn,0), COALESCE(t.msgCreatedOn,0), COALESCE(t.actionStartDate,0), COALESCE(t.updatedOn,0), COALESCE(t.createdOn,0), COALESCE(t.sentiment,0), COALESCE(t.classified,0), COALESCE(t.language,0), COALESCE(t.country,0), COALESCE(t.channelId,0), COALESCE(t.a_arank,0), COALESCE(t.a_grank,0), COALESCE(t.kloutscore,0), COALESCE(t.sex,0), COALESCE(t.age,0), COALESCE(t.frenCnt,0), COALESCE(t.follCnt,0), COALESCE(t.listedCnt,0), COALESCE(t.influenceScore,0), COALESCE(t.surveyId,0), COALESCE(t.priorityScore,0), COALESCE(t.scoreJson,0), COALESCE(t.slaId,0), COALESCE(t.slaTriggered,0), COALESCE(t.userChannelId,0), COALESCE(t.attached,0), COALESCE(t.caseAssociated,0), COALESCE(t.detachAllowed,0), COALESCE(t.detachedBy,0), COALESCE(t.detachedFrom,0), COALESCE(t.tatCalculated,0), COALESCE(t.tatValue,0), COALESCE(t.csatSent,0), COALESCE(t.csatResponse,0), COALESCE(t.csatSentDate,0), COALESCE(t.csatRespDate,0), COALESCE(t.followUpOn,0), COALESCE(t.timeZone,0), COALESCE(t.followUpBy,0), COALESCE(t.assignByfollowUp,0), COALESCE(t.csatMessage,0), COALESCE(t.attempted,0), COALESCE(t.csatEligible,0), COALESCE(t.backOfficeType,0), COALESCE(t.recommendation,0), COALESCE(t.satisfaction,0), COALESCE(t.fix,0), COALESCE(t.verbatim,0), COALESCE(t.fromSoAccountId,0), COALESCE(t.inReplyToStatusId,0), COALESCE(t.customerType,0), COALESCE(t.dept,0), COALESCE(t.nonContactable,0), COALESCE(t.action_type,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(msgId,0), COALESCE(fromOrgId,0), COALESCE(orgId,0), COALESCE(fromUserId,0), COALESCE(toUserId,0), COALESCE(fromBasketId,0), COALESCE(toBasketId,0), COALESCE(ruleId,0), COALESCE(lockedBy,0), COALESCE(locked,0), COALESCE(lockNote,0), COALESCE(priority,0), COALESCE(message,0), COALESCE(responseMsg,0), COALESCE(channel,0), COALESCE(action,0), COALESCE(callerType,0), COALESCE(parentId,0), COALESCE(sourceId,0), COALESCE(profileId,0), COALESCE(dataSource,0), COALESCE(currentlyActive,0), COALESCE(active,0), COALESCE(actionDate,0), COALESCE(messageCapturedOn,0), COALESCE(msgCreatedOn,0), COALESCE(actionStartDate,0), COALESCE(updatedOn,0), COALESCE(createdOn,0), COALESCE(sentiment,0), COALESCE(classified,0), COALESCE(language,0), COALESCE(country,0), COALESCE(channelId,0), COALESCE(a_arank,0), COALESCE(a_grank,0), COALESCE(kloutscore,0), COALESCE(sex,0), COALESCE(age,0), COALESCE(frenCnt,0), COALESCE(follCnt,0), COALESCE(listedCnt,0), COALESCE(influenceScore,0), COALESCE(surveyId,0), COALESCE(priorityScore,0), COALESCE(scoreJson,0), COALESCE(slaId,0), COALESCE(slaTriggered,0), COALESCE(userChannelId,0), COALESCE(attached,0), COALESCE(caseAssociated,0), COALESCE(detachAllowed,0), COALESCE(detachedBy,0), COALESCE(detachedFrom,0), COALESCE(tatCalculated,0), COALESCE(tatValue,0), COALESCE(csatSent,0), COALESCE(csatResponse,0), COALESCE(csatSentDate,0), COALESCE(csatRespDate,0), COALESCE(followUpOn,0), COALESCE(timeZone,0), COALESCE(followUpBy,0), COALESCE(assignByfollowUp,0), COALESCE(csatMessage,0), COALESCE(attempted,0), COALESCE(csatEligible,0), COALESCE(backOfficeType,0), COALESCE(recommendation,0), COALESCE(satisfaction,0), COALESCE(fix,0), COALESCE(verbatim,0), COALESCE(fromSoAccountId,0), COALESCE(inReplyToStatusId,0), COALESCE(customerType,0), COALESCE(dept,0), COALESCE(nonContactable,0), COALESCE(action_type,0)
            FROM ',source_db,'.t_workflow_dtls ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_lead;

DELIMITER //
CREATE PROCEDURE  `purge_t_lead`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.leadId
    FROM ',source_db,'.t_lead r
    WHERE   ROW(COALESCE(r.leadId,0), COALESCE(r.salutation,0), COALESCE(r.firstName,0), COALESCE(r.lastName,0), COALESCE(r.title,0), COALESCE(r.industry,0), COALESCE(r.owner,0), COALESCE(r.description,0), COALESCE(r.phone,0), COALESCE(r.mobile,0), COALESCE(r.altPhone1,0), COALESCE(r.altPhone2,0), COALESCE(r.altPhone3,0), COALESCE(r.altPhone4,0), COALESCE(r.email,0), COALESCE(r.alterEmail,0), COALESCE(r.fax,0), COALESCE(r.profileId,0), COALESCE(r.orgId,0), COALESCE(r.userId,0), COALESCE(r.docKey,0), COALESCE(r.leadTypeId,0), COALESCE(r.leadPriorityId,0), COALESCE(r.active,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.middleName,0), COALESCE(r.status,0), COALESCE(r.category,0), COALESCE(r.customerSegment,0), COALESCE(r.type,0), COALESCE(r.circle,0), COALESCE(r.activationDate,0), COALESCE(r.rmEmailId,0), COALESCE(r.dumpFileName,0), COALESCE(r.dumpRowNumber,0), COALESCE(r.dumpUpdatedOn,0), COALESCE(r.blogUrl,0), COALESCE(r.website,0), COALESCE(r.customerType,0), COALESCE(r.customerId,0), COALESCE(r.addType,0), COALESCE(r.subCategory,0), COALESCE(r.custLeadType,0), COALESCE(r.custLeadSubType,0), COALESCE(r.jmsMessageId,0), COALESCE(r.rootAssetId,0)) IN (
            SELECT  COALESCE(leadId,0), COALESCE(salutation,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(title,0), COALESCE(industry,0), COALESCE(owner,0), COALESCE(description,0), COALESCE(phone,0), COALESCE(mobile,0), COALESCE(altPhone1,0), COALESCE(altPhone2,0), COALESCE(altPhone3,0), COALESCE(altPhone4,0), COALESCE(email,0), COALESCE(alterEmail,0), COALESCE(fax,0), COALESCE(profileId,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(docKey,0), COALESCE(leadTypeId,0), COALESCE(leadPriorityId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(middleName,0), COALESCE(status,0), COALESCE(category,0), COALESCE(customerSegment,0), COALESCE(type,0), COALESCE(circle,0), COALESCE(activationDate,0), COALESCE(rmEmailId,0), COALESCE(dumpFileName,0), COALESCE(dumpRowNumber,0), COALESCE(dumpUpdatedOn,0), COALESCE(blogUrl,0), COALESCE(website,0), COALESCE(customerType,0), COALESCE(customerId,0), COALESCE(addType,0), COALESCE(subCategory,0), COALESCE(custLeadType,0), COALESCE(custLeadSubType,0), COALESCE(jmsMessageId,0), COALESCE(rootAssetId,0)
            FROM ',archived_db,'.t_lead) 
    UNION
    SELECT  t.leadId
    FROM    ',archived_db,'.t_lead t
    WHERE   ROW(COALESCE(t.leadId,0), COALESCE(t.salutation,0), COALESCE(t.firstName,0), COALESCE(t.lastName,0), COALESCE(t.title,0), COALESCE(t.industry,0), COALESCE(t.owner,0), COALESCE(t.description,0), COALESCE(t.phone,0), COALESCE(t.mobile,0), COALESCE(t.altPhone1,0), COALESCE(t.altPhone2,0), COALESCE(t.altPhone3,0), COALESCE(t.altPhone4,0), COALESCE(t.email,0), COALESCE(t.alterEmail,0), COALESCE(t.fax,0), COALESCE(t.profileId,0), COALESCE(t.orgId,0), COALESCE(t.userId,0), COALESCE(t.docKey,0), COALESCE(t.leadTypeId,0), COALESCE(t.leadPriorityId,0), COALESCE(t.active,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.middleName,0), COALESCE(t.status,0), COALESCE(t.category,0), COALESCE(t.customerSegment,0), COALESCE(t.type,0), COALESCE(t.circle,0), COALESCE(t.activationDate,0), COALESCE(t.rmEmailId,0), COALESCE(t.dumpFileName,0), COALESCE(t.dumpRowNumber,0), COALESCE(t.dumpUpdatedOn,0), COALESCE(t.blogUrl,0), COALESCE(t.website,0), COALESCE(t.customerType,0), COALESCE(t.customerId,0), COALESCE(t.addType,0), COALESCE(t.subCategory,0), COALESCE(t.custLeadType,0), COALESCE(t.custLeadSubType,0), COALESCE(t.jmsMessageId,0), COALESCE(t.rootAssetId,0)) 
            IN ( SELECT  COALESCE(leadId,0), COALESCE(salutation,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(title,0), COALESCE(industry,0), COALESCE(owner,0), COALESCE(description,0), COALESCE(phone,0), COALESCE(mobile,0), COALESCE(altPhone1,0), COALESCE(altPhone2,0), COALESCE(altPhone3,0), COALESCE(altPhone4,0), COALESCE(email,0), COALESCE(alterEmail,0), COALESCE(fax,0), COALESCE(profileId,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(docKey,0), COALESCE(leadTypeId,0), COALESCE(leadPriorityId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(middleName,0), COALESCE(status,0), COALESCE(category,0), COALESCE(customerSegment,0), COALESCE(type,0), COALESCE(circle,0), COALESCE(activationDate,0), COALESCE(rmEmailId,0), COALESCE(dumpFileName,0), COALESCE(dumpRowNumber,0), COALESCE(dumpUpdatedOn,0), COALESCE(blogUrl,0), COALESCE(website,0), COALESCE(customerType,0), COALESCE(customerId,0), COALESCE(addType,0), COALESCE(subCategory,0), COALESCE(custLeadType,0), COALESCE(custLeadSubType,0), COALESCE(jmsMessageId,0), COALESCE(rootAssetId,0)
            FROM ',source_db,'.t_lead ) ) AS p ) as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_lead where leadId IN(SELECT * from(
    SELECT  r.leadId
    FROM ',source_db,'.t_lead r
    WHERE   ROW(COALESCE(r.leadId,0), COALESCE(r.salutation,0), COALESCE(r.firstName,0), COALESCE(r.lastName,0), COALESCE(r.title,0), COALESCE(r.industry,0), COALESCE(r.owner,0), COALESCE(r.description,0), COALESCE(r.phone,0), COALESCE(r.mobile,0), COALESCE(r.altPhone1,0), COALESCE(r.altPhone2,0), COALESCE(r.altPhone3,0), COALESCE(r.altPhone4,0), COALESCE(r.email,0), COALESCE(r.alterEmail,0), COALESCE(r.fax,0), COALESCE(r.profileId,0), COALESCE(r.orgId,0), COALESCE(r.userId,0), COALESCE(r.docKey,0), COALESCE(r.leadTypeId,0), COALESCE(r.leadPriorityId,0), COALESCE(r.active,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.middleName,0), COALESCE(r.status,0), COALESCE(r.category,0), COALESCE(r.customerSegment,0), COALESCE(r.type,0), COALESCE(r.circle,0), COALESCE(r.activationDate,0), COALESCE(r.rmEmailId,0), COALESCE(r.dumpFileName,0), COALESCE(r.dumpRowNumber,0), COALESCE(r.dumpUpdatedOn,0), COALESCE(r.blogUrl,0), COALESCE(r.website,0), COALESCE(r.customerType,0), COALESCE(r.customerId,0), COALESCE(r.addType,0), COALESCE(r.subCategory,0), COALESCE(r.custLeadType,0), COALESCE(r.custLeadSubType,0), COALESCE(r.jmsMessageId,0), COALESCE(r.rootAssetId,0)) IN (
            SELECT  COALESCE(leadId,0), COALESCE(salutation,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(title,0), COALESCE(industry,0), COALESCE(owner,0), COALESCE(description,0), COALESCE(phone,0), COALESCE(mobile,0), COALESCE(altPhone1,0), COALESCE(altPhone2,0), COALESCE(altPhone3,0), COALESCE(altPhone4,0), COALESCE(email,0), COALESCE(alterEmail,0), COALESCE(fax,0), COALESCE(profileId,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(docKey,0), COALESCE(leadTypeId,0), COALESCE(leadPriorityId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(middleName,0), COALESCE(status,0), COALESCE(category,0), COALESCE(customerSegment,0), COALESCE(type,0), COALESCE(circle,0), COALESCE(activationDate,0), COALESCE(rmEmailId,0), COALESCE(dumpFileName,0), COALESCE(dumpRowNumber,0), COALESCE(dumpUpdatedOn,0), COALESCE(blogUrl,0), COALESCE(website,0), COALESCE(customerType,0), COALESCE(customerId,0), COALESCE(addType,0), COALESCE(subCategory,0), COALESCE(custLeadType,0), COALESCE(custLeadSubType,0), COALESCE(jmsMessageId,0), COALESCE(rootAssetId,0)
            FROM ',archived_db,'.t_lead) 
    UNION
    SELECT  t.leadId
    FROM    ',archived_db,'.t_lead t
    WHERE   ROW(COALESCE(t.leadId,0), COALESCE(t.salutation,0), COALESCE(t.firstName,0), COALESCE(t.lastName,0), COALESCE(t.title,0), COALESCE(t.industry,0), COALESCE(t.owner,0), COALESCE(t.description,0), COALESCE(t.phone,0), COALESCE(t.mobile,0), COALESCE(t.altPhone1,0), COALESCE(t.altPhone2,0), COALESCE(t.altPhone3,0), COALESCE(t.altPhone4,0), COALESCE(t.email,0), COALESCE(t.alterEmail,0), COALESCE(t.fax,0), COALESCE(t.profileId,0), COALESCE(t.orgId,0), COALESCE(t.userId,0), COALESCE(t.docKey,0), COALESCE(t.leadTypeId,0), COALESCE(t.leadPriorityId,0), COALESCE(t.active,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.middleName,0), COALESCE(t.status,0), COALESCE(t.category,0), COALESCE(t.customerSegment,0), COALESCE(t.type,0), COALESCE(t.circle,0), COALESCE(t.activationDate,0), COALESCE(t.rmEmailId,0), COALESCE(t.dumpFileName,0), COALESCE(t.dumpRowNumber,0), COALESCE(t.dumpUpdatedOn,0), COALESCE(t.blogUrl,0), COALESCE(t.website,0), COALESCE(t.customerType,0), COALESCE(t.customerId,0), COALESCE(t.addType,0), COALESCE(t.subCategory,0), COALESCE(t.custLeadType,0), COALESCE(t.custLeadSubType,0), COALESCE(t.jmsMessageId,0), COALESCE(t.rootAssetId,0)) 
            IN ( SELECT  COALESCE(leadId,0), COALESCE(salutation,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(title,0), COALESCE(industry,0), COALESCE(owner,0), COALESCE(description,0), COALESCE(phone,0), COALESCE(mobile,0), COALESCE(altPhone1,0), COALESCE(altPhone2,0), COALESCE(altPhone3,0), COALESCE(altPhone4,0), COALESCE(email,0), COALESCE(alterEmail,0), COALESCE(fax,0), COALESCE(profileId,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(docKey,0), COALESCE(leadTypeId,0), COALESCE(leadPriorityId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(middleName,0), COALESCE(status,0), COALESCE(category,0), COALESCE(customerSegment,0), COALESCE(type,0), COALESCE(circle,0), COALESCE(activationDate,0), COALESCE(rmEmailId,0), COALESCE(dumpFileName,0), COALESCE(dumpRowNumber,0), COALESCE(dumpUpdatedOn,0), COALESCE(blogUrl,0), COALESCE(website,0), COALESCE(customerType,0), COALESCE(customerId,0), COALESCE(addType,0), COALESCE(subCategory,0), COALESCE(custLeadType,0), COALESCE(custLeadSubType,0), COALESCE(jmsMessageId,0), COALESCE(rootAssetId,0)
            FROM ',source_db,'.t_lead ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_survey_respid_rel;

DELIMITER //
CREATE PROCEDURE  `purge_t_survey_respid_rel`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_survey_respid_rel r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.surveyId,0), COALESCE(r.respondentId,0), COALESCE(r.finished,0), COALESCE(r.percentCompleted,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(surveyId,0), COALESCE(respondentId,0), COALESCE(finished,0), COALESCE(percentCompleted,0)
            FROM ',archived_db,'.t_survey_respid_rel) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_survey_respid_rel t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.surveyId,0), COALESCE(t.respondentId,0), COALESCE(t.finished,0), COALESCE(t.percentCompleted,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(surveyId,0), COALESCE(respondentId,0), COALESCE(finished,0), COALESCE(percentCompleted,0)
            FROM ',source_db,'.t_survey_respid_rel ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_survey_respid_rel where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_survey_respid_rel r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.surveyId,0), COALESCE(r.respondentId,0), COALESCE(r.finished,0), COALESCE(r.percentCompleted,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(surveyId,0), COALESCE(respondentId,0), COALESCE(finished,0), COALESCE(percentCompleted,0)
            FROM ',archived_db,'.t_survey_respid_rel) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_survey_respid_rel t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.surveyId,0), COALESCE(t.respondentId,0), COALESCE(t.finished,0), COALESCE(t.percentCompleted,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(surveyId,0), COALESCE(respondentId,0), COALESCE(finished,0), COALESCE(percentCompleted,0)
            FROM ',source_db,'.t_survey_respid_rel ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_survey_responses;

DELIMITER //
CREATE PROCEDURE  `purge_t_survey_responses`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_survey_responses r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.surveyId,0), COALESCE(r.questionId,0), COALESCE(r.ansId,0), COALESCE(r.freeText,0), COALESCE(r.respondentId,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(surveyId,0), COALESCE(questionId,0), COALESCE(ansId,0), COALESCE(freeText,0), COALESCE(respondentId,0)
            FROM ',archived_db,'.t_survey_responses) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_survey_responses t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.surveyId,0), COALESCE(t.questionId,0), COALESCE(t.ansId,0), COALESCE(t.freeText,0), COALESCE(t.respondentId,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(surveyId,0), COALESCE(questionId,0), COALESCE(ansId,0), COALESCE(freeText,0), COALESCE(respondentId,0)
            FROM ',source_db,'.t_survey_responses ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_survey_responses where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_survey_responses r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.surveyId,0), COALESCE(r.questionId,0), COALESCE(r.ansId,0), COALESCE(r.freeText,0), COALESCE(r.respondentId,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(surveyId,0), COALESCE(questionId,0), COALESCE(ansId,0), COALESCE(freeText,0), COALESCE(respondentId,0)
            FROM ',archived_db,'.t_survey_responses) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_survey_responses t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.surveyId,0), COALESCE(t.questionId,0), COALESCE(t.ansId,0), COALESCE(t.freeText,0), COALESCE(t.respondentId,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(surveyId,0), COALESCE(questionId,0), COALESCE(ansId,0), COALESCE(freeText,0), COALESCE(respondentId,0)
            FROM ',source_db,'.t_survey_responses ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_tagged_messages;

DELIMITER //
CREATE PROCEDURE  `purge_t_tagged_messages`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_tagged_messages r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.tagId,0), COALESCE(r.messageId,0), COALESCE(r.source,0), COALESCE(r.userId,0), COALESCE(r.orgId,0), COALESCE(r.compId,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.docKey,0), COALESCE(r.type,0), COALESCE(r.profileId,0), COALESCE(r.ruleId,0), COALESCE(r.sourceActivity,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(tagId,0), COALESCE(messageId,0), COALESCE(source,0), COALESCE(userId,0), COALESCE(orgId,0), COALESCE(compId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(docKey,0), COALESCE(type,0), COALESCE(profileId,0), COALESCE(ruleId,0), COALESCE(sourceActivity,0)
            FROM ',archived_db,'.t_tagged_messages) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_tagged_messages t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.tagId,0), COALESCE(t.messageId,0), COALESCE(t.source,0), COALESCE(t.userId,0), COALESCE(t.orgId,0), COALESCE(t.compId,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.docKey,0), COALESCE(t.type,0), COALESCE(t.profileId,0), COALESCE(t.ruleId,0), COALESCE(t.sourceActivity,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(tagId,0), COALESCE(messageId,0), COALESCE(source,0), COALESCE(userId,0), COALESCE(orgId,0), COALESCE(compId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(docKey,0), COALESCE(type,0), COALESCE(profileId,0), COALESCE(ruleId,0), COALESCE(sourceActivity,0)
            FROM ',source_db,'.t_tagged_messages ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_tagged_messages where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_tagged_messages r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.tagId,0), COALESCE(r.messageId,0), COALESCE(r.source,0), COALESCE(r.userId,0), COALESCE(r.orgId,0), COALESCE(r.compId,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.docKey,0), COALESCE(r.type,0), COALESCE(r.profileId,0), COALESCE(r.ruleId,0), COALESCE(r.sourceActivity,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(tagId,0), COALESCE(messageId,0), COALESCE(source,0), COALESCE(userId,0), COALESCE(orgId,0), COALESCE(compId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(docKey,0), COALESCE(type,0), COALESCE(profileId,0), COALESCE(ruleId,0), COALESCE(sourceActivity,0)
            FROM ',archived_db,'.t_tagged_messages) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_tagged_messages t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.tagId,0), COALESCE(t.messageId,0), COALESCE(t.source,0), COALESCE(t.userId,0), COALESCE(t.orgId,0), COALESCE(t.compId,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.docKey,0), COALESCE(t.type,0), COALESCE(t.profileId,0), COALESCE(t.ruleId,0), COALESCE(t.sourceActivity,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(tagId,0), COALESCE(messageId,0), COALESCE(source,0), COALESCE(userId,0), COALESCE(orgId,0), COALESCE(compId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(docKey,0), COALESCE(type,0), COALESCE(profileId,0), COALESCE(ruleId,0), COALESCE(sourceActivity,0)
            FROM ',source_db,'.t_tagged_messages ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_user_notes;

DELIMITER //
CREATE PROCEDURE  `purge_t_user_notes`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_user_notes r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.refId,0), COALESCE(r.msgId,0), COALESCE(r.refType,0), COALESCE(r.orgId,0), COALESCE(r.userId,0), COALESCE(r.message,0), COALESCE(r.active,0), COALESCE(r.updatedOn,0), COALESCE(r.createdOn,0), COALESCE(r.profileId,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(refId,0), COALESCE(msgId,0), COALESCE(refType,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(message,0), COALESCE(active,0), COALESCE(updatedOn,0), COALESCE(createdOn,0), COALESCE(profileId,0)
            FROM ',archived_db,'.t_user_notes) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_user_notes t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.refId,0), COALESCE(t.msgId,0), COALESCE(t.refType,0), COALESCE(t.orgId,0), COALESCE(t.userId,0), COALESCE(t.message,0), COALESCE(t.active,0), COALESCE(t.updatedOn,0), COALESCE(t.createdOn,0), COALESCE(t.profileId,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(refId,0), COALESCE(msgId,0), COALESCE(refType,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(message,0), COALESCE(active,0), COALESCE(updatedOn,0), COALESCE(createdOn,0), COALESCE(profileId,0)
            FROM ',source_db,'.t_user_notes ) ) AS p ) as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_user_notes where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_user_notes r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.refId,0), COALESCE(r.msgId,0), COALESCE(r.refType,0), COALESCE(r.orgId,0), COALESCE(r.userId,0), COALESCE(r.message,0), COALESCE(r.active,0), COALESCE(r.updatedOn,0), COALESCE(r.createdOn,0), COALESCE(r.profileId,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(refId,0), COALESCE(msgId,0), COALESCE(refType,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(message,0), COALESCE(active,0), COALESCE(updatedOn,0), COALESCE(createdOn,0), COALESCE(profileId,0)
            FROM ',archived_db,'.t_user_notes) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_user_notes t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.refId,0), COALESCE(t.msgId,0), COALESCE(t.refType,0), COALESCE(t.orgId,0), COALESCE(t.userId,0), COALESCE(t.message,0), COALESCE(t.active,0), COALESCE(t.updatedOn,0), COALESCE(t.createdOn,0), COALESCE(t.profileId,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(refId,0), COALESCE(msgId,0), COALESCE(refType,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(message,0), COALESCE(active,0), COALESCE(updatedOn,0), COALESCE(createdOn,0), COALESCE(profileId,0)
            FROM ',source_db,'.t_user_notes ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_workflow_tat_dtls;

DELIMITER //
CREATE PROCEDURE  `purge_t_workflow_tat_dtls`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_workflow_tat_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.workId,0), COALESCE(r.parent_workId,0), COALESCE(r.t1,0), COALESCE(r.t2,0), COALESCE(r.t3,0), COALESCE(r.t4,0), COALESCE(r.t5,0), COALESCE(r.socialTat,0), COALESCE(r.circleTat,0), COALESCE(r.tatCalculated,0), COALESCE(r.stopTatCalculation,0), COALESCE(r.replied,0), COALESCE(r.column1,0), COALESCE(r.column2,0), COALESCE(r.active,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(workId,0), COALESCE(parent_workId,0), COALESCE(t1,0), COALESCE(t2,0), COALESCE(t3,0), COALESCE(t4,0), COALESCE(t5,0), COALESCE(socialTat,0), COALESCE(circleTat,0), COALESCE(tatCalculated,0), COALESCE(stopTatCalculation,0), COALESCE(replied,0), COALESCE(column1,0), COALESCE(column2,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_workflow_tat_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_workflow_tat_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.workId,0), COALESCE(t.parent_workId,0), COALESCE(t.t1,0), COALESCE(t.t2,0), COALESCE(t.t3,0), COALESCE(t.t4,0), COALESCE(t.t5,0), COALESCE(t.socialTat,0), COALESCE(t.circleTat,0), COALESCE(t.tatCalculated,0), COALESCE(t.stopTatCalculation,0), COALESCE(t.replied,0), COALESCE(t.column1,0), COALESCE(t.column2,0), COALESCE(t.active,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(workId,0), COALESCE(parent_workId,0), COALESCE(t1,0), COALESCE(t2,0), COALESCE(t3,0), COALESCE(t4,0), COALESCE(t5,0), COALESCE(socialTat,0), COALESCE(circleTat,0), COALESCE(tatCalculated,0), COALESCE(stopTatCalculation,0), COALESCE(replied,0), COALESCE(column1,0), COALESCE(column2,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_workflow_tat_dtls ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_workflow_tat_dtls where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_workflow_tat_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.workId,0), COALESCE(r.parent_workId,0), COALESCE(r.t1,0), COALESCE(r.t2,0), COALESCE(r.t3,0), COALESCE(r.t4,0), COALESCE(r.t5,0), COALESCE(r.socialTat,0), COALESCE(r.circleTat,0), COALESCE(r.tatCalculated,0), COALESCE(r.stopTatCalculation,0), COALESCE(r.replied,0), COALESCE(r.column1,0), COALESCE(r.column2,0), COALESCE(r.active,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(workId,0), COALESCE(parent_workId,0), COALESCE(t1,0), COALESCE(t2,0), COALESCE(t3,0), COALESCE(t4,0), COALESCE(t5,0), COALESCE(socialTat,0), COALESCE(circleTat,0), COALESCE(tatCalculated,0), COALESCE(stopTatCalculation,0), COALESCE(replied,0), COALESCE(column1,0), COALESCE(column2,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_workflow_tat_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_workflow_tat_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.workId,0), COALESCE(t.parent_workId,0), COALESCE(t.t1,0), COALESCE(t.t2,0), COALESCE(t.t3,0), COALESCE(t.t4,0), COALESCE(t.t5,0), COALESCE(t.socialTat,0), COALESCE(t.circleTat,0), COALESCE(t.tatCalculated,0), COALESCE(t.stopTatCalculation,0), COALESCE(t.replied,0), COALESCE(t.column1,0), COALESCE(t.column2,0), COALESCE(t.active,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(workId,0), COALESCE(parent_workId,0), COALESCE(t1,0), COALESCE(t2,0), COALESCE(t3,0), COALESCE(t4,0), COALESCE(t5,0), COALESCE(socialTat,0), COALESCE(circleTat,0), COALESCE(tatCalculated,0), COALESCE(stopTatCalculation,0), COALESCE(replied,0), COALESCE(column1,0), COALESCE(column2,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_workflow_tat_dtls ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_sch_messages;

DELIMITER //
CREATE PROCEDURE  `purge_t_sch_messages`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.schMsgId
    FROM ',source_db,'.t_sch_messages r
    WHERE   ROW(COALESCE(r.schMsgId,0), COALESCE(r.userId,0), COALESCE(r.message,0), COALESCE(r.messageTitle,0), COALESCE(r.active,0), COALESCE(r.rptSetting,0), COALESCE(r.repeated,0), COALESCE(r.usrTime,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.createdBy,0), COALESCE(r.campId,0), COALESCE(r.gmtTime,0), COALESCE(r.gmtTimeDate,0), COALESCE(r.inReplyToStatusId,0), COALESCE(r.messageType,0), COALESCE(r.compId,0), COALESCE(r.orgId,0), COALESCE(r.approved,0), COALESCE(r.comment,0), COALESCE(r.actionBy,0), COALESCE(r.picToUpload,0), COALESCE(r.parent,0), COALESCE(r.interactionId,0), COALESCE(r.messageId,0), COALESCE(r.timeZone,0), COALESCE(r.urlTitle,0), COALESCE(r.url,0), COALESCE(r.urlDesc,0), COALESCE(r.urlThumbnail,0), COALESCE(r.urlNoThumbnail,0), COALESCE(r.expandUrl,0), COALESCE(r.userSchedule,0), COALESCE(r.imported,0), COALESCE(r.nonAdmin,0), COALESCE(r.gmtEndTimeDate,0), COALESCE(r.customDates,0), COALESCE(r.type,0), COALESCE(r.responseTypeId,0), COALESCE(r.imageText,0)) IN (
            SELECT  COALESCE(schMsgId,0), COALESCE(userId,0), COALESCE(message,0), COALESCE(messageTitle,0), COALESCE(active,0), COALESCE(rptSetting,0), COALESCE(repeated,0), COALESCE(usrTime,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(createdBy,0), COALESCE(campId,0), COALESCE(gmtTime,0), COALESCE(gmtTimeDate,0), COALESCE(inReplyToStatusId,0), COALESCE(messageType,0), COALESCE(compId,0), COALESCE(orgId,0), COALESCE(approved,0), COALESCE(comment,0), COALESCE(actionBy,0), COALESCE(picToUpload,0), COALESCE(parent,0), COALESCE(interactionId,0), COALESCE(messageId,0), COALESCE(timeZone,0), COALESCE(urlTitle,0), COALESCE(url,0), COALESCE(urlDesc,0), COALESCE(urlThumbnail,0), COALESCE(urlNoThumbnail,0), COALESCE(expandUrl,0), COALESCE(userSchedule,0), COALESCE(imported,0), COALESCE(nonAdmin,0), COALESCE(gmtEndTimeDate,0), COALESCE(customDates,0), COALESCE(type,0), COALESCE(responseTypeId,0), COALESCE(imageText,0)
            FROM ',archived_db,'.t_sch_messages) 
    UNION
    SELECT  t.schMsgId
    FROM    ',archived_db,'.t_sch_messages t
    WHERE   ROW(COALESCE(t.schMsgId,0), COALESCE(t.userId,0), COALESCE(t.message,0), COALESCE(t.messageTitle,0), COALESCE(t.active,0), COALESCE(t.rptSetting,0), COALESCE(t.repeated,0), COALESCE(t.usrTime,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.createdBy,0), COALESCE(t.campId,0), COALESCE(t.gmtTime,0), COALESCE(t.gmtTimeDate,0), COALESCE(t.inReplyToStatusId,0), COALESCE(t.messageType,0), COALESCE(t.compId,0), COALESCE(t.orgId,0), COALESCE(t.approved,0), COALESCE(t.comment,0), COALESCE(t.actionBy,0), COALESCE(t.picToUpload,0), COALESCE(t.parent,0), COALESCE(t.interactionId,0), COALESCE(t.messageId,0), COALESCE(t.timeZone,0), COALESCE(t.urlTitle,0), COALESCE(t.url,0), COALESCE(t.urlDesc,0), COALESCE(t.urlThumbnail,0), COALESCE(t.urlNoThumbnail,0), COALESCE(t.expandUrl,0), COALESCE(t.userSchedule,0), COALESCE(t.imported,0), COALESCE(t.nonAdmin,0), COALESCE(t.gmtEndTimeDate,0), COALESCE(t.customDates,0), COALESCE(t.type,0), COALESCE(t.responseTypeId,0), COALESCE(t.imageText,0)) 
            IN ( SELECT  COALESCE(schMsgId,0), COALESCE(userId,0), COALESCE(message,0), COALESCE(messageTitle,0), COALESCE(active,0), COALESCE(rptSetting,0), COALESCE(repeated,0), COALESCE(usrTime,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(createdBy,0), COALESCE(campId,0), COALESCE(gmtTime,0), COALESCE(gmtTimeDate,0), COALESCE(inReplyToStatusId,0), COALESCE(messageType,0), COALESCE(compId,0), COALESCE(orgId,0), COALESCE(approved,0), COALESCE(comment,0), COALESCE(actionBy,0), COALESCE(picToUpload,0), COALESCE(parent,0), COALESCE(interactionId,0), COALESCE(messageId,0), COALESCE(timeZone,0), COALESCE(urlTitle,0), COALESCE(url,0), COALESCE(urlDesc,0), COALESCE(urlThumbnail,0), COALESCE(urlNoThumbnail,0), COALESCE(expandUrl,0), COALESCE(userSchedule,0), COALESCE(imported,0), COALESCE(nonAdmin,0), COALESCE(gmtEndTimeDate,0), COALESCE(customDates,0), COALESCE(type,0), COALESCE(responseTypeId,0), COALESCE(imageText,0)
            FROM ',source_db,'.t_sch_messages ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_sch_messages where schMsgId IN(SELECT * from(
    SELECT  r.schMsgId
    FROM ',source_db,'.t_sch_messages r
    WHERE   ROW(COALESCE(r.schMsgId,0), COALESCE(r.userId,0), COALESCE(r.message,0), COALESCE(r.messageTitle,0), COALESCE(r.active,0), COALESCE(r.rptSetting,0), COALESCE(r.repeated,0), COALESCE(r.usrTime,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.createdBy,0), COALESCE(r.campId,0), COALESCE(r.gmtTime,0), COALESCE(r.gmtTimeDate,0), COALESCE(r.inReplyToStatusId,0), COALESCE(r.messageType,0), COALESCE(r.compId,0), COALESCE(r.orgId,0), COALESCE(r.approved,0), COALESCE(r.comment,0), COALESCE(r.actionBy,0), COALESCE(r.picToUpload,0), COALESCE(r.parent,0), COALESCE(r.interactionId,0), COALESCE(r.messageId,0), COALESCE(r.timeZone,0), COALESCE(r.urlTitle,0), COALESCE(r.url,0), COALESCE(r.urlDesc,0), COALESCE(r.urlThumbnail,0), COALESCE(r.urlNoThumbnail,0), COALESCE(r.expandUrl,0), COALESCE(r.userSchedule,0), COALESCE(r.imported,0), COALESCE(r.nonAdmin,0), COALESCE(r.gmtEndTimeDate,0), COALESCE(r.customDates,0), COALESCE(r.type,0), COALESCE(r.responseTypeId,0), COALESCE(r.imageText,0)) IN (
            SELECT  COALESCE(schMsgId,0), COALESCE(userId,0), COALESCE(message,0), COALESCE(messageTitle,0), COALESCE(active,0), COALESCE(rptSetting,0), COALESCE(repeated,0), COALESCE(usrTime,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(createdBy,0), COALESCE(campId,0), COALESCE(gmtTime,0), COALESCE(gmtTimeDate,0), COALESCE(inReplyToStatusId,0), COALESCE(messageType,0), COALESCE(compId,0), COALESCE(orgId,0), COALESCE(approved,0), COALESCE(comment,0), COALESCE(actionBy,0), COALESCE(picToUpload,0), COALESCE(parent,0), COALESCE(interactionId,0), COALESCE(messageId,0), COALESCE(timeZone,0), COALESCE(urlTitle,0), COALESCE(url,0), COALESCE(urlDesc,0), COALESCE(urlThumbnail,0), COALESCE(urlNoThumbnail,0), COALESCE(expandUrl,0), COALESCE(userSchedule,0), COALESCE(imported,0), COALESCE(nonAdmin,0), COALESCE(gmtEndTimeDate,0), COALESCE(customDates,0), COALESCE(type,0), COALESCE(responseTypeId,0), COALESCE(imageText,0)
            FROM ',archived_db,'.t_sch_messages) 
    UNION
    SELECT  t.schMsgId
    FROM    ',archived_db,'.t_sch_messages t
    WHERE   ROW(COALESCE(t.schMsgId,0), COALESCE(t.userId,0), COALESCE(t.message,0), COALESCE(t.messageTitle,0), COALESCE(t.active,0), COALESCE(t.rptSetting,0), COALESCE(t.repeated,0), COALESCE(t.usrTime,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.createdBy,0), COALESCE(t.campId,0), COALESCE(t.gmtTime,0), COALESCE(t.gmtTimeDate,0), COALESCE(t.inReplyToStatusId,0), COALESCE(t.messageType,0), COALESCE(t.compId,0), COALESCE(t.orgId,0), COALESCE(t.approved,0), COALESCE(t.comment,0), COALESCE(t.actionBy,0), COALESCE(t.picToUpload,0), COALESCE(t.parent,0), COALESCE(t.interactionId,0), COALESCE(t.messageId,0), COALESCE(t.timeZone,0), COALESCE(t.urlTitle,0), COALESCE(t.url,0), COALESCE(t.urlDesc,0), COALESCE(t.urlThumbnail,0), COALESCE(t.urlNoThumbnail,0), COALESCE(t.expandUrl,0), COALESCE(t.userSchedule,0), COALESCE(t.imported,0), COALESCE(t.nonAdmin,0), COALESCE(t.gmtEndTimeDate,0), COALESCE(t.customDates,0), COALESCE(t.type,0), COALESCE(t.responseTypeId,0), COALESCE(t.imageText,0)) 
            IN ( SELECT  COALESCE(schMsgId,0), COALESCE(userId,0), COALESCE(message,0), COALESCE(messageTitle,0), COALESCE(active,0), COALESCE(rptSetting,0), COALESCE(repeated,0), COALESCE(usrTime,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(createdBy,0), COALESCE(campId,0), COALESCE(gmtTime,0), COALESCE(gmtTimeDate,0), COALESCE(inReplyToStatusId,0), COALESCE(messageType,0), COALESCE(compId,0), COALESCE(orgId,0), COALESCE(approved,0), COALESCE(comment,0), COALESCE(actionBy,0), COALESCE(picToUpload,0), COALESCE(parent,0), COALESCE(interactionId,0), COALESCE(messageId,0), COALESCE(timeZone,0), COALESCE(urlTitle,0), COALESCE(url,0), COALESCE(urlDesc,0), COALESCE(urlThumbnail,0), COALESCE(urlNoThumbnail,0), COALESCE(expandUrl,0), COALESCE(userSchedule,0), COALESCE(imported,0), COALESCE(nonAdmin,0), COALESCE(gmtEndTimeDate,0), COALESCE(customDates,0), COALESCE(type,0), COALESCE(responseTypeId,0), COALESCE(imageText,0)
            FROM ',source_db,'.t_sch_messages ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_sr_type_dtls;

DELIMITER //
CREATE PROCEDURE  `purge_t_sr_type_dtls`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_sr_type_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.workId,0), COALESCE(r.parentId,0), COALESCE(r.type,0), COALESCE(r.requestId,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(workId,0), COALESCE(parentId,0), COALESCE(type,0), COALESCE(requestId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_sr_type_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_sr_type_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.workId,0), COALESCE(t.parentId,0), COALESCE(t.type,0), COALESCE(t.requestId,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(workId,0), COALESCE(parentId,0), COALESCE(type,0), COALESCE(requestId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_sr_type_dtls ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_sr_type_dtls where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_sr_type_dtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.workId,0), COALESCE(r.parentId,0), COALESCE(r.type,0), COALESCE(r.requestId,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(workId,0), COALESCE(parentId,0), COALESCE(type,0), COALESCE(requestId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_sr_type_dtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_sr_type_dtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.workId,0), COALESCE(t.parentId,0), COALESCE(t.type,0), COALESCE(t.requestId,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(workId,0), COALESCE(parentId,0), COALESCE(type,0), COALESCE(requestId,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_sr_type_dtls )) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_srid_dtls_siebel;

DELIMITER //
CREATE PROCEDURE  `purge_t_srid_dtls_siebel`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_srid_dtls_siebel r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.abstractVal,0), COALESCE(r.account,0), COALESCE(r.accountId,0), COALESCE(r.accountIntegrationId,0), COALESCE(r.accountNumber,0), COALESCE(r.additionalInformation,0), COALESCE(r.agentComments,0), COALESCE(r.altContactEmail,0), COALESCE(r.altContactName,0), COALESCE(r.altContactPhone,0), COALESCE(r.amountCharged,0), COALESCE(r.assetId,0), COALESCE(r.assetIntegrationId,0), COALESCE(r.assetNumber,0), COALESCE(r.autoSubmitFlag,0), COALESCE(r.cEMDueDate,0), COALESCE(r.cEMPlannedCompletionDate,0), COALESCE(r.cEMPlannedStartDate,0), COALESCE(r.cEMTimeUnit,0), COALESCE(r.cEMTotalTime,0), COALESCE(r.commitTime,0), COALESCE(r.cSN,0), COALESCE(r.comments,0), COALESCE(r.customerComments,0), COALESCE(r.customerRefNumber,0), COALESCE(r.description,0), COALESCE(r.fee,0), COALESCE(r.handsetMake,0), COALESCE(r.handsetModel,0), COALESCE(r.type,0), COALESCE(r.area,0), COALESCE(r.subarea,0), COALESCE(r.incidentDate,0), COALESCE(r.integrationId,0), COALESCE(r.mSISDN,0), COALESCE(r.networkDetail1,0), COALESCE(r.networkDetail2,0), COALESCE(r.noticeReceivedDate,0), COALESCE(r.numberString,0), COALESCE(r.outcome,0), COALESCE(r.owner,0), COALESCE(r.ownerGroup,0), COALESCE(r.priority,0), COALESCE(r.reason,0), COALESCE(r.resolutionCode,0), COALESCE(r.sIMNumber,0), COALESCE(r.sRId,0), COALESCE(r.sRImpact,0), COALESCE(r.sRNumber,0), COALESCE(r.sROpenDate,0), COALESCE(r.serialNumber,0), COALESCE(r.source,0), COALESCE(r.status,0), COALESCE(r.status1,0), COALESCE(r.status2,0), COALESCE(r.subStatus,0), COALESCE(r.ticketType,0), COALESCE(r.tTSource,0), COALESCE(r.serviceType,0), COALESCE(r.category,0), COALESCE(r.subCategory,0), COALESCE(r.assetStatus,0), COALESCE(r.serviceRegionID,0), COALESCE(r.serviceRegion,0), COALESCE(r.media,0), COALESCE(r.subMedia,0), COALESCE(r.customerSegment,0), COALESCE(r.fieldname1,0), COALESCE(r.fieldvalue1,0), COALESCE(r.fieldname2,0), COALESCE(r.fieldvalue2,0), COALESCE(r.srErrorCode,0), COALESCE(r.srErrorStatus,0), COALESCE(r.srErrorDesc,0), COALESCE(r.srErrorCategory,0), COALESCE(r.srCreatedOn,0), COALESCE(r.srUpdatedOn,0), COALESCE(r.workId,0), COALESCE(r.work_parentId,0), COALESCE(r.userId,0), COALESCE(r.closedDate,0), COALESCE(r.circle,0), COALESCE(r.segment,0), COALESCE(r.updateCounter,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(abstractVal,0), COALESCE(account,0), COALESCE(accountId,0), COALESCE(accountIntegrationId,0), COALESCE(accountNumber,0), COALESCE(additionalInformation,0), COALESCE(agentComments,0), COALESCE(altContactEmail,0), COALESCE(altContactName,0), COALESCE(altContactPhone,0), COALESCE(amountCharged,0), COALESCE(assetId,0), COALESCE(assetIntegrationId,0), COALESCE(assetNumber,0), COALESCE(autoSubmitFlag,0), COALESCE(cEMDueDate,0), COALESCE(cEMPlannedCompletionDate,0), COALESCE(cEMPlannedStartDate,0), COALESCE(cEMTimeUnit,0), COALESCE(cEMTotalTime,0), COALESCE(commitTime,0), COALESCE(cSN,0), COALESCE(comments,0), COALESCE(customerComments,0), COALESCE(customerRefNumber,0), COALESCE(description,0), COALESCE(fee,0), COALESCE(handsetMake,0), COALESCE(handsetModel,0), COALESCE(type,0), COALESCE(area,0), COALESCE(subarea,0), COALESCE(incidentDate,0), COALESCE(integrationId,0), COALESCE(mSISDN,0), COALESCE(networkDetail1,0), COALESCE(networkDetail2,0), COALESCE(noticeReceivedDate,0), COALESCE(numberString,0), COALESCE(outcome,0), COALESCE(owner,0), COALESCE(ownerGroup,0), COALESCE(priority,0), COALESCE(reason,0), COALESCE(resolutionCode,0), COALESCE(sIMNumber,0), COALESCE(sRId,0), COALESCE(sRImpact,0), COALESCE(sRNumber,0), COALESCE(sROpenDate,0), COALESCE(serialNumber,0), COALESCE(source,0), COALESCE(status,0), COALESCE(status1,0), COALESCE(status2,0), COALESCE(subStatus,0), COALESCE(ticketType,0), COALESCE(tTSource,0), COALESCE(serviceType,0), COALESCE(category,0), COALESCE(subCategory,0), COALESCE(assetStatus,0), COALESCE(serviceRegionID,0), COALESCE(serviceRegion,0), COALESCE(media,0), COALESCE(subMedia,0), COALESCE(customerSegment,0), COALESCE(fieldname1,0), COALESCE(fieldvalue1,0), COALESCE(fieldname2,0), COALESCE(fieldvalue2,0), COALESCE(srErrorCode,0), COALESCE(srErrorStatus,0), COALESCE(srErrorDesc,0), COALESCE(srErrorCategory,0), COALESCE(srCreatedOn,0), COALESCE(srUpdatedOn,0), COALESCE(workId,0), COALESCE(work_parentId,0), COALESCE(userId,0), COALESCE(closedDate,0), COALESCE(circle,0), COALESCE(segment,0), COALESCE(updateCounter,0)
            FROM ',archived_db,'.t_srid_dtls_siebel) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_srid_dtls_siebel t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.abstractVal,0), COALESCE(t.account,0), COALESCE(t.accountId,0), COALESCE(t.accountIntegrationId,0), COALESCE(t.accountNumber,0), COALESCE(t.additionalInformation,0), COALESCE(t.agentComments,0), COALESCE(t.altContactEmail,0), COALESCE(t.altContactName,0), COALESCE(t.altContactPhone,0), COALESCE(t.amountCharged,0), COALESCE(t.assetId,0), COALESCE(t.assetIntegrationId,0), COALESCE(t.assetNumber,0), COALESCE(t.autoSubmitFlag,0), COALESCE(t.cEMDueDate,0), COALESCE(t.cEMPlannedCompletionDate,0), COALESCE(t.cEMPlannedStartDate,0), COALESCE(t.cEMTimeUnit,0), COALESCE(t.cEMTotalTime,0), COALESCE(t.commitTime,0), COALESCE(t.cSN,0), COALESCE(t.comments,0), COALESCE(t.customerComments,0), COALESCE(t.customerRefNumber,0), COALESCE(t.description,0), COALESCE(t.fee,0), COALESCE(t.handsetMake,0), COALESCE(t.handsetModel,0), COALESCE(t.type,0), COALESCE(t.area,0), COALESCE(t.subarea,0), COALESCE(t.incidentDate,0), COALESCE(t.integrationId,0), COALESCE(t.mSISDN,0), COALESCE(t.networkDetail1,0), COALESCE(t.networkDetail2,0), COALESCE(t.noticeReceivedDate,0), COALESCE(t.numberString,0), COALESCE(t.outcome,0), COALESCE(t.owner,0), COALESCE(t.ownerGroup,0), COALESCE(t.priority,0), COALESCE(t.reason,0), COALESCE(t.resolutionCode,0), COALESCE(t.sIMNumber,0), COALESCE(t.sRId,0), COALESCE(t.sRImpact,0), COALESCE(t.sRNumber,0), COALESCE(t.sROpenDate,0), COALESCE(t.serialNumber,0), COALESCE(t.source,0), COALESCE(t.status,0), COALESCE(t.status1,0), COALESCE(t.status2,0), COALESCE(t.subStatus,0), COALESCE(t.ticketType,0), COALESCE(t.tTSource,0), COALESCE(t.serviceType,0), COALESCE(t.category,0), COALESCE(t.subCategory,0), COALESCE(t.assetStatus,0), COALESCE(t.serviceRegionID,0), COALESCE(t.serviceRegion,0), COALESCE(t.media,0), COALESCE(t.subMedia,0), COALESCE(t.customerSegment,0), COALESCE(t.fieldname1,0), COALESCE(t.fieldvalue1,0), COALESCE(t.fieldname2,0), COALESCE(t.fieldvalue2,0), COALESCE(t.srErrorCode,0), COALESCE(t.srErrorStatus,0), COALESCE(t.srErrorDesc,0), COALESCE(t.srErrorCategory,0), COALESCE(t.srCreatedOn,0), COALESCE(t.srUpdatedOn,0), COALESCE(t.workId,0), COALESCE(t.work_parentId,0), COALESCE(t.userId,0), COALESCE(t.closedDate,0), COALESCE(t.circle,0), COALESCE(t.segment,0), COALESCE(t.updateCounter,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(abstractVal,0), COALESCE(account,0), COALESCE(accountId,0), COALESCE(accountIntegrationId,0), COALESCE(accountNumber,0), COALESCE(additionalInformation,0), COALESCE(agentComments,0), COALESCE(altContactEmail,0), COALESCE(altContactName,0), COALESCE(altContactPhone,0), COALESCE(amountCharged,0), COALESCE(assetId,0), COALESCE(assetIntegrationId,0), COALESCE(assetNumber,0), COALESCE(autoSubmitFlag,0), COALESCE(cEMDueDate,0), COALESCE(cEMPlannedCompletionDate,0), COALESCE(cEMPlannedStartDate,0), COALESCE(cEMTimeUnit,0), COALESCE(cEMTotalTime,0), COALESCE(commitTime,0), COALESCE(cSN,0), COALESCE(comments,0), COALESCE(customerComments,0), COALESCE(customerRefNumber,0), COALESCE(description,0), COALESCE(fee,0), COALESCE(handsetMake,0), COALESCE(handsetModel,0), COALESCE(type,0), COALESCE(area,0), COALESCE(subarea,0), COALESCE(incidentDate,0), COALESCE(integrationId,0), COALESCE(mSISDN,0), COALESCE(networkDetail1,0), COALESCE(networkDetail2,0), COALESCE(noticeReceivedDate,0), COALESCE(numberString,0), COALESCE(outcome,0), COALESCE(owner,0), COALESCE(ownerGroup,0), COALESCE(priority,0), COALESCE(reason,0), COALESCE(resolutionCode,0), COALESCE(sIMNumber,0), COALESCE(sRId,0), COALESCE(sRImpact,0), COALESCE(sRNumber,0), COALESCE(sROpenDate,0), COALESCE(serialNumber,0), COALESCE(source,0), COALESCE(status,0), COALESCE(status1,0), COALESCE(status2,0), COALESCE(subStatus,0), COALESCE(ticketType,0), COALESCE(tTSource,0), COALESCE(serviceType,0), COALESCE(category,0), COALESCE(subCategory,0), COALESCE(assetStatus,0), COALESCE(serviceRegionID,0), COALESCE(serviceRegion,0), COALESCE(media,0), COALESCE(subMedia,0), COALESCE(customerSegment,0), COALESCE(fieldname1,0), COALESCE(fieldvalue1,0), COALESCE(fieldname2,0), COALESCE(fieldvalue2,0), COALESCE(srErrorCode,0), COALESCE(srErrorStatus,0), COALESCE(srErrorDesc,0), COALESCE(srErrorCategory,0), COALESCE(srCreatedOn,0), COALESCE(srUpdatedOn,0), COALESCE(workId,0), COALESCE(work_parentId,0), COALESCE(userId,0), COALESCE(closedDate,0), COALESCE(circle,0), COALESCE(segment,0), COALESCE(updateCounter,0)
            FROM ',source_db,'.t_srid_dtls_siebel ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_srid_dtls_siebel where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_srid_dtls_siebel r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.abstractVal,0), COALESCE(r.account,0), COALESCE(r.accountId,0), COALESCE(r.accountIntegrationId,0), COALESCE(r.accountNumber,0), COALESCE(r.additionalInformation,0), COALESCE(r.agentComments,0), COALESCE(r.altContactEmail,0), COALESCE(r.altContactName,0), COALESCE(r.altContactPhone,0), COALESCE(r.amountCharged,0), COALESCE(r.assetId,0), COALESCE(r.assetIntegrationId,0), COALESCE(r.assetNumber,0), COALESCE(r.autoSubmitFlag,0), COALESCE(r.cEMDueDate,0), COALESCE(r.cEMPlannedCompletionDate,0), COALESCE(r.cEMPlannedStartDate,0), COALESCE(r.cEMTimeUnit,0), COALESCE(r.cEMTotalTime,0), COALESCE(r.commitTime,0), COALESCE(r.cSN,0), COALESCE(r.comments,0), COALESCE(r.customerComments,0), COALESCE(r.customerRefNumber,0), COALESCE(r.description,0), COALESCE(r.fee,0), COALESCE(r.handsetMake,0), COALESCE(r.handsetModel,0), COALESCE(r.type,0), COALESCE(r.area,0), COALESCE(r.subarea,0), COALESCE(r.incidentDate,0), COALESCE(r.integrationId,0), COALESCE(r.mSISDN,0), COALESCE(r.networkDetail1,0), COALESCE(r.networkDetail2,0), COALESCE(r.noticeReceivedDate,0), COALESCE(r.numberString,0), COALESCE(r.outcome,0), COALESCE(r.owner,0), COALESCE(r.ownerGroup,0), COALESCE(r.priority,0), COALESCE(r.reason,0), COALESCE(r.resolutionCode,0), COALESCE(r.sIMNumber,0), COALESCE(r.sRId,0), COALESCE(r.sRImpact,0), COALESCE(r.sRNumber,0), COALESCE(r.sROpenDate,0), COALESCE(r.serialNumber,0), COALESCE(r.source,0), COALESCE(r.status,0), COALESCE(r.status1,0), COALESCE(r.status2,0), COALESCE(r.subStatus,0), COALESCE(r.ticketType,0), COALESCE(r.tTSource,0), COALESCE(r.serviceType,0), COALESCE(r.category,0), COALESCE(r.subCategory,0), COALESCE(r.assetStatus,0), COALESCE(r.serviceRegionID,0), COALESCE(r.serviceRegion,0), COALESCE(r.media,0), COALESCE(r.subMedia,0), COALESCE(r.customerSegment,0), COALESCE(r.fieldname1,0), COALESCE(r.fieldvalue1,0), COALESCE(r.fieldname2,0), COALESCE(r.fieldvalue2,0), COALESCE(r.srErrorCode,0), COALESCE(r.srErrorStatus,0), COALESCE(r.srErrorDesc,0), COALESCE(r.srErrorCategory,0), COALESCE(r.srCreatedOn,0), COALESCE(r.srUpdatedOn,0), COALESCE(r.workId,0), COALESCE(r.work_parentId,0), COALESCE(r.userId,0), COALESCE(r.closedDate,0), COALESCE(r.circle,0), COALESCE(r.segment,0), COALESCE(r.updateCounter,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(abstractVal,0), COALESCE(account,0), COALESCE(accountId,0), COALESCE(accountIntegrationId,0), COALESCE(accountNumber,0), COALESCE(additionalInformation,0), COALESCE(agentComments,0), COALESCE(altContactEmail,0), COALESCE(altContactName,0), COALESCE(altContactPhone,0), COALESCE(amountCharged,0), COALESCE(assetId,0), COALESCE(assetIntegrationId,0), COALESCE(assetNumber,0), COALESCE(autoSubmitFlag,0), COALESCE(cEMDueDate,0), COALESCE(cEMPlannedCompletionDate,0), COALESCE(cEMPlannedStartDate,0), COALESCE(cEMTimeUnit,0), COALESCE(cEMTotalTime,0), COALESCE(commitTime,0), COALESCE(cSN,0), COALESCE(comments,0), COALESCE(customerComments,0), COALESCE(customerRefNumber,0), COALESCE(description,0), COALESCE(fee,0), COALESCE(handsetMake,0), COALESCE(handsetModel,0), COALESCE(type,0), COALESCE(area,0), COALESCE(subarea,0), COALESCE(incidentDate,0), COALESCE(integrationId,0), COALESCE(mSISDN,0), COALESCE(networkDetail1,0), COALESCE(networkDetail2,0), COALESCE(noticeReceivedDate,0), COALESCE(numberString,0), COALESCE(outcome,0), COALESCE(owner,0), COALESCE(ownerGroup,0), COALESCE(priority,0), COALESCE(reason,0), COALESCE(resolutionCode,0), COALESCE(sIMNumber,0), COALESCE(sRId,0), COALESCE(sRImpact,0), COALESCE(sRNumber,0), COALESCE(sROpenDate,0), COALESCE(serialNumber,0), COALESCE(source,0), COALESCE(status,0), COALESCE(status1,0), COALESCE(status2,0), COALESCE(subStatus,0), COALESCE(ticketType,0), COALESCE(tTSource,0), COALESCE(serviceType,0), COALESCE(category,0), COALESCE(subCategory,0), COALESCE(assetStatus,0), COALESCE(serviceRegionID,0), COALESCE(serviceRegion,0), COALESCE(media,0), COALESCE(subMedia,0), COALESCE(customerSegment,0), COALESCE(fieldname1,0), COALESCE(fieldvalue1,0), COALESCE(fieldname2,0), COALESCE(fieldvalue2,0), COALESCE(srErrorCode,0), COALESCE(srErrorStatus,0), COALESCE(srErrorDesc,0), COALESCE(srErrorCategory,0), COALESCE(srCreatedOn,0), COALESCE(srUpdatedOn,0), COALESCE(workId,0), COALESCE(work_parentId,0), COALESCE(userId,0), COALESCE(closedDate,0), COALESCE(circle,0), COALESCE(segment,0), COALESCE(updateCounter,0)
            FROM ',archived_db,'.t_srid_dtls_siebel) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_srid_dtls_siebel t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.abstractVal,0), COALESCE(t.account,0), COALESCE(t.accountId,0), COALESCE(t.accountIntegrationId,0), COALESCE(t.accountNumber,0), COALESCE(t.additionalInformation,0), COALESCE(t.agentComments,0), COALESCE(t.altContactEmail,0), COALESCE(t.altContactName,0), COALESCE(t.altContactPhone,0), COALESCE(t.amountCharged,0), COALESCE(t.assetId,0), COALESCE(t.assetIntegrationId,0), COALESCE(t.assetNumber,0), COALESCE(t.autoSubmitFlag,0), COALESCE(t.cEMDueDate,0), COALESCE(t.cEMPlannedCompletionDate,0), COALESCE(t.cEMPlannedStartDate,0), COALESCE(t.cEMTimeUnit,0), COALESCE(t.cEMTotalTime,0), COALESCE(t.commitTime,0), COALESCE(t.cSN,0), COALESCE(t.comments,0), COALESCE(t.customerComments,0), COALESCE(t.customerRefNumber,0), COALESCE(t.description,0), COALESCE(t.fee,0), COALESCE(t.handsetMake,0), COALESCE(t.handsetModel,0), COALESCE(t.type,0), COALESCE(t.area,0), COALESCE(t.subarea,0), COALESCE(t.incidentDate,0), COALESCE(t.integrationId,0), COALESCE(t.mSISDN,0), COALESCE(t.networkDetail1,0), COALESCE(t.networkDetail2,0), COALESCE(t.noticeReceivedDate,0), COALESCE(t.numberString,0), COALESCE(t.outcome,0), COALESCE(t.owner,0), COALESCE(t.ownerGroup,0), COALESCE(t.priority,0), COALESCE(t.reason,0), COALESCE(t.resolutionCode,0), COALESCE(t.sIMNumber,0), COALESCE(t.sRId,0), COALESCE(t.sRImpact,0), COALESCE(t.sRNumber,0), COALESCE(t.sROpenDate,0), COALESCE(t.serialNumber,0), COALESCE(t.source,0), COALESCE(t.status,0), COALESCE(t.status1,0), COALESCE(t.status2,0), COALESCE(t.subStatus,0), COALESCE(t.ticketType,0), COALESCE(t.tTSource,0), COALESCE(t.serviceType,0), COALESCE(t.category,0), COALESCE(t.subCategory,0), COALESCE(t.assetStatus,0), COALESCE(t.serviceRegionID,0), COALESCE(t.serviceRegion,0), COALESCE(t.media,0), COALESCE(t.subMedia,0), COALESCE(t.customerSegment,0), COALESCE(t.fieldname1,0), COALESCE(t.fieldvalue1,0), COALESCE(t.fieldname2,0), COALESCE(t.fieldvalue2,0), COALESCE(t.srErrorCode,0), COALESCE(t.srErrorStatus,0), COALESCE(t.srErrorDesc,0), COALESCE(t.srErrorCategory,0), COALESCE(t.srCreatedOn,0), COALESCE(t.srUpdatedOn,0), COALESCE(t.workId,0), COALESCE(t.work_parentId,0), COALESCE(t.userId,0), COALESCE(t.closedDate,0), COALESCE(t.circle,0), COALESCE(t.segment,0), COALESCE(t.updateCounter,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(abstractVal,0), COALESCE(account,0), COALESCE(accountId,0), COALESCE(accountIntegrationId,0), COALESCE(accountNumber,0), COALESCE(additionalInformation,0), COALESCE(agentComments,0), COALESCE(altContactEmail,0), COALESCE(altContactName,0), COALESCE(altContactPhone,0), COALESCE(amountCharged,0), COALESCE(assetId,0), COALESCE(assetIntegrationId,0), COALESCE(assetNumber,0), COALESCE(autoSubmitFlag,0), COALESCE(cEMDueDate,0), COALESCE(cEMPlannedCompletionDate,0), COALESCE(cEMPlannedStartDate,0), COALESCE(cEMTimeUnit,0), COALESCE(cEMTotalTime,0), COALESCE(commitTime,0), COALESCE(cSN,0), COALESCE(comments,0), COALESCE(customerComments,0), COALESCE(customerRefNumber,0), COALESCE(description,0), COALESCE(fee,0), COALESCE(handsetMake,0), COALESCE(handsetModel,0), COALESCE(type,0), COALESCE(area,0), COALESCE(subarea,0), COALESCE(incidentDate,0), COALESCE(integrationId,0), COALESCE(mSISDN,0), COALESCE(networkDetail1,0), COALESCE(networkDetail2,0), COALESCE(noticeReceivedDate,0), COALESCE(numberString,0), COALESCE(outcome,0), COALESCE(owner,0), COALESCE(ownerGroup,0), COALESCE(priority,0), COALESCE(reason,0), COALESCE(resolutionCode,0), COALESCE(sIMNumber,0), COALESCE(sRId,0), COALESCE(sRImpact,0), COALESCE(sRNumber,0), COALESCE(sROpenDate,0), COALESCE(serialNumber,0), COALESCE(source,0), COALESCE(status,0), COALESCE(status1,0), COALESCE(status2,0), COALESCE(subStatus,0), COALESCE(ticketType,0), COALESCE(tTSource,0), COALESCE(serviceType,0), COALESCE(category,0), COALESCE(subCategory,0), COALESCE(assetStatus,0), COALESCE(serviceRegionID,0), COALESCE(serviceRegion,0), COALESCE(media,0), COALESCE(subMedia,0), COALESCE(customerSegment,0), COALESCE(fieldname1,0), COALESCE(fieldvalue1,0), COALESCE(fieldname2,0), COALESCE(fieldvalue2,0), COALESCE(srErrorCode,0), COALESCE(srErrorStatus,0), COALESCE(srErrorDesc,0), COALESCE(srErrorCategory,0), COALESCE(srCreatedOn,0), COALESCE(srUpdatedOn,0), COALESCE(workId,0), COALESCE(work_parentId,0), COALESCE(userId,0), COALESCE(closedDate,0), COALESCE(circle,0), COALESCE(segment,0), COALESCE(updateCounter,0)
            FROM ',source_db,'.t_srid_dtls_siebel ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_srid_dtls_siebel_fields;

DELIMITER //
CREATE PROCEDURE  `purge_t_srid_dtls_siebel_fields`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_srid_dtls_siebel_fields r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.sRNumber,0), COALESCE(r.fieldname,0), COALESCE(r.fieldvalue,0), COALESCE(r.createdOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(sRNumber,0), COALESCE(fieldname,0), COALESCE(fieldvalue,0), COALESCE(createdOn,0)
            FROM ',archived_db,'.t_srid_dtls_siebel_fields) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_srid_dtls_siebel_fields t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.sRNumber,0), COALESCE(t.fieldname,0), COALESCE(t.fieldvalue,0), COALESCE(t.createdOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(sRNumber,0), COALESCE(fieldname,0), COALESCE(fieldvalue,0), COALESCE(createdOn,0)
            FROM ',source_db,'.t_srid_dtls_siebel_fields ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_srid_dtls_siebel_fields where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_srid_dtls_siebel_fields r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.sRNumber,0), COALESCE(r.fieldname,0), COALESCE(r.fieldvalue,0), COALESCE(r.createdOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(sRNumber,0), COALESCE(fieldname,0), COALESCE(fieldvalue,0), COALESCE(createdOn,0)
            FROM ',archived_db,'.t_srid_dtls_siebel_fields) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_srid_dtls_siebel_fields t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.sRNumber,0), COALESCE(t.fieldname,0), COALESCE(t.fieldvalue,0), COALESCE(t.createdOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(sRNumber,0), COALESCE(fieldname,0), COALESCE(fieldvalue,0), COALESCE(createdOn,0)
            FROM ',source_db,'.t_srid_dtls_siebel_fields ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_srid_dtls_siebel_srdtls;

DELIMITER //
CREATE PROCEDURE  `purge_t_srid_dtls_siebel_srdtls`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_srid_dtls_siebel_srdtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.sRNumber,0), COALESCE(r.type,0), COALESCE(r.ref,0), COALESCE(r.detail1,0), COALESCE(r.detail2,0), COALESCE(r.detail3,0), COALESCE(r.moreinfo,0), COALESCE(r.comments,0), COALESCE(r.num1,0), COALESCE(r.num2,0), COALESCE(r.num3,0), COALESCE(r.num4,0), COALESCE(r.datetime1,0), COALESCE(r.datetime2,0), COALESCE(r.datetime3,0), COALESCE(r.datetime4,0), COALESCE(r.createdOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(sRNumber,0), COALESCE(type,0), COALESCE(ref,0), COALESCE(detail1,0), COALESCE(detail2,0), COALESCE(detail3,0), COALESCE(moreinfo,0), COALESCE(comments,0), COALESCE(num1,0), COALESCE(num2,0), COALESCE(num3,0), COALESCE(num4,0), COALESCE(datetime1,0), COALESCE(datetime2,0), COALESCE(datetime3,0), COALESCE(datetime4,0), COALESCE(createdOn,0)
            FROM ',archived_db,'.t_srid_dtls_siebel_srdtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_srid_dtls_siebel_srdtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.sRNumber,0), COALESCE(t.type,0), COALESCE(t.ref,0), COALESCE(t.detail1,0), COALESCE(t.detail2,0), COALESCE(t.detail3,0), COALESCE(t.moreinfo,0), COALESCE(t.comments,0), COALESCE(t.num1,0), COALESCE(t.num2,0), COALESCE(t.num3,0), COALESCE(t.num4,0), COALESCE(t.datetime1,0), COALESCE(t.datetime2,0), COALESCE(t.datetime3,0), COALESCE(t.datetime4,0), COALESCE(t.createdOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(sRNumber,0), COALESCE(type,0), COALESCE(ref,0), COALESCE(detail1,0), COALESCE(detail2,0), COALESCE(detail3,0), COALESCE(moreinfo,0), COALESCE(comments,0), COALESCE(num1,0), COALESCE(num2,0), COALESCE(num3,0), COALESCE(num4,0), COALESCE(datetime1,0), COALESCE(datetime2,0), COALESCE(datetime3,0), COALESCE(datetime4,0), COALESCE(createdOn,0)
            FROM ',source_db,'.t_srid_dtls_siebel_srdtls ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_srid_dtls_siebel_srdtls where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_srid_dtls_siebel_srdtls r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.sRNumber,0), COALESCE(r.type,0), COALESCE(r.ref,0), COALESCE(r.detail1,0), COALESCE(r.detail2,0), COALESCE(r.detail3,0), COALESCE(r.moreinfo,0), COALESCE(r.comments,0), COALESCE(r.num1,0), COALESCE(r.num2,0), COALESCE(r.num3,0), COALESCE(r.num4,0), COALESCE(r.datetime1,0), COALESCE(r.datetime2,0), COALESCE(r.datetime3,0), COALESCE(r.datetime4,0), COALESCE(r.createdOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(sRNumber,0), COALESCE(type,0), COALESCE(ref,0), COALESCE(detail1,0), COALESCE(detail2,0), COALESCE(detail3,0), COALESCE(moreinfo,0), COALESCE(comments,0), COALESCE(num1,0), COALESCE(num2,0), COALESCE(num3,0), COALESCE(num4,0), COALESCE(datetime1,0), COALESCE(datetime2,0), COALESCE(datetime3,0), COALESCE(datetime4,0), COALESCE(createdOn,0)
            FROM ',archived_db,'.t_srid_dtls_siebel_srdtls) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_srid_dtls_siebel_srdtls t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.sRNumber,0), COALESCE(t.type,0), COALESCE(t.ref,0), COALESCE(t.detail1,0), COALESCE(t.detail2,0), COALESCE(t.detail3,0), COALESCE(t.moreinfo,0), COALESCE(t.comments,0), COALESCE(t.num1,0), COALESCE(t.num2,0), COALESCE(t.num3,0), COALESCE(t.num4,0), COALESCE(t.datetime1,0), COALESCE(t.datetime2,0), COALESCE(t.datetime3,0), COALESCE(t.datetime4,0), COALESCE(t.createdOn,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(sRNumber,0), COALESCE(type,0), COALESCE(ref,0), COALESCE(detail1,0), COALESCE(detail2,0), COALESCE(detail3,0), COALESCE(moreinfo,0), COALESCE(comments,0), COALESCE(num1,0), COALESCE(num2,0), COALESCE(num3,0), COALESCE(num4,0), COALESCE(datetime1,0), COALESCE(datetime2,0), COALESCE(datetime3,0), COALESCE(datetime4,0), COALESCE(createdOn,0)
            FROM ',source_db,'.t_srid_dtls_siebel_srdtls )  ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_customer_lead;

DELIMITER //
CREATE PROCEDURE  `purge_t_customer_lead`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_customer_lead r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.leadId,0), COALESCE(r.siebelLeadId,0), COALESCE(r.segment,0), COALESCE(r.msISDN,0), COALESCE(r.circleId,0), COALESCE(r.product,0), COALESCE(r.numberReservationPIN,0), COALESCE(r.priceQuoted,0), COALESCE(r.leadStatus,0), COALESCE(r.leadChannel,0), COALESCE(r.leadRating,0), COALESCE(r.leadType,0), COALESCE(r.customerType,0), COALESCE(r.productType,0), COALESCE(r.reason,0), COALESCE(r.description,0), COALESCE(r.externalLeadRef,0), COALESCE(r.opportunityId,0), COALESCE(r.orgId,0), COALESCE(r.userId,0), COALESCE(r.active,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.jmsMessageId,0), COALESCE(r.leadErrorStatus,0), COALESCE(r.leadErrorCode,0), COALESCE(r.leadErrorDesc,0), COALESCE(r.leadErrorCategory,0), COALESCE(r.leadErrorSpcCode,0), COALESCE(r.leadErrorSpcMessage,0), COALESCE(r.leadUpdatedOn,0), COALESCE(r.shortCode,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(leadId,0), COALESCE(siebelLeadId,0), COALESCE(segment,0), COALESCE(msISDN,0), COALESCE(circleId,0), COALESCE(product,0), COALESCE(numberReservationPIN,0), COALESCE(priceQuoted,0), COALESCE(leadStatus,0), COALESCE(leadChannel,0), COALESCE(leadRating,0), COALESCE(leadType,0), COALESCE(customerType,0), COALESCE(productType,0), COALESCE(reason,0), COALESCE(description,0), COALESCE(externalLeadRef,0), COALESCE(opportunityId,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(jmsMessageId,0), COALESCE(leadErrorStatus,0), COALESCE(leadErrorCode,0), COALESCE(leadErrorDesc,0), COALESCE(leadErrorCategory,0), COALESCE(leadErrorSpcCode,0), COALESCE(leadErrorSpcMessage,0), COALESCE(leadUpdatedOn,0), COALESCE(shortCode,0)
            FROM ',archived_db,'.t_customer_lead) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_customer_lead t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.leadId,0), COALESCE(t.siebelLeadId,0), COALESCE(t.segment,0), COALESCE(t.msISDN,0), COALESCE(t.circleId,0), COALESCE(t.product,0), COALESCE(t.numberReservationPIN,0), COALESCE(t.priceQuoted,0), COALESCE(t.leadStatus,0), COALESCE(t.leadChannel,0), COALESCE(t.leadRating,0), COALESCE(t.leadType,0), COALESCE(t.customerType,0), COALESCE(t.productType,0), COALESCE(t.reason,0), COALESCE(t.description,0), COALESCE(t.externalLeadRef,0), COALESCE(t.opportunityId,0), COALESCE(t.orgId,0), COALESCE(t.userId,0), COALESCE(t.active,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.jmsMessageId,0), COALESCE(t.leadErrorStatus,0), COALESCE(t.leadErrorCode,0), COALESCE(t.leadErrorDesc,0), COALESCE(t.leadErrorCategory,0), COALESCE(t.leadErrorSpcCode,0), COALESCE(t.leadErrorSpcMessage,0), COALESCE(t.leadUpdatedOn,0), COALESCE(t.shortCode,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(leadId,0), COALESCE(siebelLeadId,0), COALESCE(segment,0), COALESCE(msISDN,0), COALESCE(circleId,0), COALESCE(product,0), COALESCE(numberReservationPIN,0), COALESCE(priceQuoted,0), COALESCE(leadStatus,0), COALESCE(leadChannel,0), COALESCE(leadRating,0), COALESCE(leadType,0), COALESCE(customerType,0), COALESCE(productType,0), COALESCE(reason,0), COALESCE(description,0), COALESCE(externalLeadRef,0), COALESCE(opportunityId,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(jmsMessageId,0), COALESCE(leadErrorStatus,0), COALESCE(leadErrorCode,0), COALESCE(leadErrorDesc,0), COALESCE(leadErrorCategory,0), COALESCE(leadErrorSpcCode,0), COALESCE(leadErrorSpcMessage,0), COALESCE(leadUpdatedOn,0), COALESCE(shortCode,0)
            FROM ',source_db,'.t_customer_lead ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_customer_lead where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_customer_lead r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.leadId,0), COALESCE(r.siebelLeadId,0), COALESCE(r.segment,0), COALESCE(r.msISDN,0), COALESCE(r.circleId,0), COALESCE(r.product,0), COALESCE(r.numberReservationPIN,0), COALESCE(r.priceQuoted,0), COALESCE(r.leadStatus,0), COALESCE(r.leadChannel,0), COALESCE(r.leadRating,0), COALESCE(r.leadType,0), COALESCE(r.customerType,0), COALESCE(r.productType,0), COALESCE(r.reason,0), COALESCE(r.description,0), COALESCE(r.externalLeadRef,0), COALESCE(r.opportunityId,0), COALESCE(r.orgId,0), COALESCE(r.userId,0), COALESCE(r.active,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0), COALESCE(r.jmsMessageId,0), COALESCE(r.leadErrorStatus,0), COALESCE(r.leadErrorCode,0), COALESCE(r.leadErrorDesc,0), COALESCE(r.leadErrorCategory,0), COALESCE(r.leadErrorSpcCode,0), COALESCE(r.leadErrorSpcMessage,0), COALESCE(r.leadUpdatedOn,0), COALESCE(r.shortCode,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(leadId,0), COALESCE(siebelLeadId,0), COALESCE(segment,0), COALESCE(msISDN,0), COALESCE(circleId,0), COALESCE(product,0), COALESCE(numberReservationPIN,0), COALESCE(priceQuoted,0), COALESCE(leadStatus,0), COALESCE(leadChannel,0), COALESCE(leadRating,0), COALESCE(leadType,0), COALESCE(customerType,0), COALESCE(productType,0), COALESCE(reason,0), COALESCE(description,0), COALESCE(externalLeadRef,0), COALESCE(opportunityId,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(jmsMessageId,0), COALESCE(leadErrorStatus,0), COALESCE(leadErrorCode,0), COALESCE(leadErrorDesc,0), COALESCE(leadErrorCategory,0), COALESCE(leadErrorSpcCode,0), COALESCE(leadErrorSpcMessage,0), COALESCE(leadUpdatedOn,0), COALESCE(shortCode,0)
            FROM ',archived_db,'.t_customer_lead) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_customer_lead t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.leadId,0), COALESCE(t.siebelLeadId,0), COALESCE(t.segment,0), COALESCE(t.msISDN,0), COALESCE(t.circleId,0), COALESCE(t.product,0), COALESCE(t.numberReservationPIN,0), COALESCE(t.priceQuoted,0), COALESCE(t.leadStatus,0), COALESCE(t.leadChannel,0), COALESCE(t.leadRating,0), COALESCE(t.leadType,0), COALESCE(t.customerType,0), COALESCE(t.productType,0), COALESCE(t.reason,0), COALESCE(t.description,0), COALESCE(t.externalLeadRef,0), COALESCE(t.opportunityId,0), COALESCE(t.orgId,0), COALESCE(t.userId,0), COALESCE(t.active,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0), COALESCE(t.jmsMessageId,0), COALESCE(t.leadErrorStatus,0), COALESCE(t.leadErrorCode,0), COALESCE(t.leadErrorDesc,0), COALESCE(t.leadErrorCategory,0), COALESCE(t.leadErrorSpcCode,0), COALESCE(t.leadErrorSpcMessage,0), COALESCE(t.leadUpdatedOn,0), COALESCE(t.shortCode,0)) 
            IN ( SELECT  COALESCE(id,0), COALESCE(leadId,0), COALESCE(siebelLeadId,0), COALESCE(segment,0), COALESCE(msISDN,0), COALESCE(circleId,0), COALESCE(product,0), COALESCE(numberReservationPIN,0), COALESCE(priceQuoted,0), COALESCE(leadStatus,0), COALESCE(leadChannel,0), COALESCE(leadRating,0), COALESCE(leadType,0), COALESCE(customerType,0), COALESCE(productType,0), COALESCE(reason,0), COALESCE(description,0), COALESCE(externalLeadRef,0), COALESCE(opportunityId,0), COALESCE(orgId,0), COALESCE(userId,0), COALESCE(active,0), COALESCE(createdOn,0), COALESCE(updatedOn,0), COALESCE(jmsMessageId,0), COALESCE(leadErrorStatus,0), COALESCE(leadErrorCode,0), COALESCE(leadErrorDesc,0), COALESCE(leadErrorCategory,0), COALESCE(leadErrorSpcCode,0), COALESCE(leadErrorSpcMessage,0), COALESCE(leadUpdatedOn,0), COALESCE(shortCode,0)
            FROM ',source_db,'.t_customer_lead ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_customer_lead_address;

DELIMITER //
CREATE PROCEDURE  `purge_t_customer_lead_address`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_customer_lead_address r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.customerLeadId,0), COALESCE(r.addressLine1,0), COALESCE(r.addressLine2,0), COALESCE(r.addressLine3,0), COALESCE(r.addressLine4,0), COALESCE(r.city,0), COALESCE(r.pin,0), COALESCE(r.state,0), COALESCE(r.country,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(customerLeadId,0), COALESCE(addressLine1,0), COALESCE(addressLine2,0), COALESCE(addressLine3,0), COALESCE(addressLine4,0), COALESCE(city,0), COALESCE(pin,0), COALESCE(state,0), COALESCE(country,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_customer_lead_address) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_customer_lead_address t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.customerLeadId,0), COALESCE(t.addressLine1,0), COALESCE(t.addressLine2,0), COALESCE(t.addressLine3,0), COALESCE(t.addressLine4,0), COALESCE(t.city,0), COALESCE(t.pin,0), COALESCE(t.state,0), COALESCE(t.country,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT COALESCE(id,0), COALESCE(customerLeadId,0), COALESCE(addressLine1,0), COALESCE(addressLine2,0), COALESCE(addressLine3,0), COALESCE(addressLine4,0), COALESCE(city,0), COALESCE(pin,0), COALESCE(state,0), COALESCE(country,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_customer_lead_address ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_customer_lead_address where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_customer_lead_address r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.customerLeadId,0), COALESCE(r.addressLine1,0), COALESCE(r.addressLine2,0), COALESCE(r.addressLine3,0), COALESCE(r.addressLine4,0), COALESCE(r.city,0), COALESCE(r.pin,0), COALESCE(r.state,0), COALESCE(r.country,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(customerLeadId,0), COALESCE(addressLine1,0), COALESCE(addressLine2,0), COALESCE(addressLine3,0), COALESCE(addressLine4,0), COALESCE(city,0), COALESCE(pin,0), COALESCE(state,0), COALESCE(country,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_customer_lead_address) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_customer_lead_address t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.customerLeadId,0), COALESCE(t.addressLine1,0), COALESCE(t.addressLine2,0), COALESCE(t.addressLine3,0), COALESCE(t.addressLine4,0), COALESCE(t.city,0), COALESCE(t.pin,0), COALESCE(t.state,0), COALESCE(t.country,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT COALESCE(id,0), COALESCE(customerLeadId,0), COALESCE(addressLine1,0), COALESCE(addressLine2,0), COALESCE(addressLine3,0), COALESCE(addressLine4,0), COALESCE(city,0), COALESCE(pin,0), COALESCE(state,0), COALESCE(country,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_customer_lead_address ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS purge_t_customer_lead_contact;

DELIMITER //
CREATE PROCEDURE  `purge_t_customer_lead_contact`(IN source_db char(100),IN archived_db char(100))
BEGIN
    
    SET @sql1 = CONCAT('SELECT COUNT(*) from (SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_customer_lead_contact r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.customerLeadId,0), COALESCE(r.firstName,0), COALESCE(r.lastName,0), COALESCE(r.emailId,0), COALESCE(r.contactNumber,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(customerLeadId,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(emailId,0), COALESCE(contactNumber,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_customer_lead_contact) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_customer_lead_contact t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.customerLeadId,0), COALESCE(t.firstName,0), COALESCE(t.lastName,0), COALESCE(t.emailId,0), COALESCE(t.contactNumber,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT COALESCE(id,0), COALESCE(customerLeadId,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(emailId,0), COALESCE(contactNumber,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_customer_lead_contact ) ) AS p )as count;');         
    PREPARE s1 from @sql1;
    EXECUTE s1;
    
    SET @sql2 = CONCAT('delete FROM ',source_db,'.t_customer_lead_contact where id IN(SELECT * from(
    SELECT  r.id
    FROM ',source_db,'.t_customer_lead_contact r
    WHERE   ROW(COALESCE(r.id,0), COALESCE(r.customerLeadId,0), COALESCE(r.firstName,0), COALESCE(r.lastName,0), COALESCE(r.emailId,0), COALESCE(r.contactNumber,0), COALESCE(r.createdOn,0), COALESCE(r.updatedOn,0)) IN (
            SELECT  COALESCE(id,0), COALESCE(customerLeadId,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(emailId,0), COALESCE(contactNumber,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',archived_db,'.t_customer_lead_contact) 
    UNION
    SELECT  t.id
    FROM    ',archived_db,'.t_customer_lead_contact t
    WHERE   ROW(COALESCE(t.id,0), COALESCE(t.customerLeadId,0), COALESCE(t.firstName,0), COALESCE(t.lastName,0), COALESCE(t.emailId,0), COALESCE(t.contactNumber,0), COALESCE(t.createdOn,0), COALESCE(t.updatedOn,0)) 
            IN ( SELECT COALESCE(id,0), COALESCE(customerLeadId,0), COALESCE(firstName,0), COALESCE(lastName,0), COALESCE(emailId,0), COALESCE(contactNumber,0), COALESCE(createdOn,0), COALESCE(updatedOn,0)
            FROM ',source_db,'.t_customer_lead_contact ) ) AS p );');         
    PREPARE s2 from @sql2;
    EXECUTE s2;
END //
DELIMITER ;