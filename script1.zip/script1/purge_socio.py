#!/usr/bin/python
##################################################################################################
#	Name    : Purge mysql source SOCIO data according to data archival
#	Date    : 06-01-2017
#	Author  : Ganesh Warkhad
#	Version : 1.0
##################################################################################################
import datetime
import sys;
import re;
import subprocess;
import time;
import traceback;
import datetime;
import base64;
import commands;
import MySQLdb;
import os;
import itertools;

DateTime      = time.strftime('%Y_%m_%d_%H_%M_%S');
wf_id         = '';
#--------------------------------:: Start loadPreArchivedData ::----------------------------------------------------------
def loadFederatedDB():
    try:
        status = "SUCCESS"; 
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
        qry=("select wf_id, source_federated_db_name from socio_config_db.pre_archival_db_details where status='%s'" %(status));
        cur.execute(qry)
        listFederatedDB=cur.fetchall()
        #print listFederatedDB
        return listFederatedDB
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
# This function will delete the entry from pre_archival_db_details of workflow id for which data has been purged.
def updateEntryOfDBFromPreArchivalDBDetails():
    try:
        status = "PURGED";
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur = conn.cursor()
        qry=("update socio_config_db.pre_archival_db_details set status='%s' where wf_id ='%s'" %(status,wf_id));
        cur.execute(qry)
        listFederatedDB=cur.fetchall()
        #print listFederatedDB
        return listFederatedDB
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;

#-------------------------------------- :: Function Definition for ensureMysqlTableCreation :: ------------------------------------
def ensureMysqlTableCreation():
    mysqlDatabases = [];
    mysqlConfigTables  = [];

    #mysqlConfigDb = 'socio_config_db';
    mysqlTableName3='purge_details';
    mysqlConfigDb='socio_config_db'

    try:
        conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        cur  = conn.cursor();
        cur.execute("show databases");
        mysqlDatabases = [item[0] for item in cur.fetchall()]
        if mysqlConfigDb not in mysqlDatabases :
            cur.execute("CREATE DATABASE IF NOT EXISTS "+mysqlConfigDb);

        cur.execute("use "+mysqlConfigDb);
        cur.execute("show tables");
        mysqlConfigTables = [item[0] for item in cur.fetchall()]

	if mysqlTableName3 not in mysqlConfigTables :
	    statement1=("CREATE TABLE IF NOT EXISTS "+mysqlConfigDb+".purge_details (wf_id text,dbname text,table_name text,purged_count bigint,executed_date text)");
            cur.execute(statement1);

        cur.close();
        conn.close();
    except:
        traceback.print_exc()
        print "ERROR: Mysql Connection not found"
        conn.close();
        sys.exit();

#----------------------------------------------------------------------------------------------------------------------------------



#--------------------------------:: Start loadPreArchivedData ::----------------------------------------------------------
def getUserInput():
    global federatedListMysql;	
    global sourceFederatedDBName;
    global wf_id;
    try:
        federatedListMysql = ",".join([str(x[1]) for x in listFederatedDBFromMysql]);
        workflowIdListMysql = ",".join([str(x[0]) for x in listFederatedDBFromMysql]);
        federatedListMysql=federatedListMysql.split(",")
        workflowIdListMysql=workflowIdListMysql.split(",")
	dictDB={}
        dictWF={}
	listDBID=[]
        i=1
	DBID=''

        #for db_name in federatedListMysql:
        if federatedListMysql != ['']:
            print "------------------------------------------------------------------------------------------------------";
            print "| DB ID | DB Name                                    | Workflow Id ";
            for j in range(0, len(federatedListMysql)):
		dictDB[i]=federatedListMysql[j];
                dictWF[i]=workflowIdListMysql[j];
		if DBID =='':
		     DBID=str(i)
		else:
		     DBID=DBID+','+str(i)
		print "------------------------------------------------------------------------------------------------------"	
                print "|   "+str(i)+"   | "+federatedListMysql[j]+"   | "+workflowIdListMysql[j];
		i=i+1
        else:
            print "\n\nINFO: There is no database available for Purging please run workflow for archival and try again....";
            print "Exiting.......\n\n";
            sys.exit();
        print "------------------------------------------------------------------------------------------------------"
	listDBID=DBID.split(",")
	listDBID = map(int, listDBID)
	#print listDBID
	var = raw_input("\n\nPlease enter DB id to Purge:")
	try:
		number = int(var)
		while number not in listDBID:
			 var = raw_input("\n\nPlease enter Valid DB id to Purge:")
                number = int(var)
		print "You Entered   : ", dictDB[number]
		sourceFederatedDBName=dictDB[number]
                wf_id = dictWF[number];
		var1 = raw_input("\nPress Y/N to continue : ")
		if var1 not in ["Y","y"]:
                    print"Exiting........"
		    sys.exit();

	except ValueError:
    		print("Invalid number")
		raise SystemExit;
	#print sourceFederatedDBName
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
def loadTablesFromDB(dbname):
    try:
        conn = MySQLdb.connect(host=SourceMysqlHostAddress, user=SourceMysqlUser, passwd=SourceMysqlPass,db=dbname);
        cur = conn.cursor()
        qry='show tables';
        cur.execute(qry)
        listTable=cur.fetchall()
        listTable = ",".join([str(x[0]) for x in listTable])
        listTable=listTable.split(",");
        return listTable;
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;
	

#-------------------------------------:: Start loadPreArchivedData ::----------------------------------------------------------
def purgeDataFromSource():
    try:
	#print listPreArchivedDB
	#print listFederatedDB
        targetDBlist=[]
	federatedDBList=[]
	listTableFromDB=[]


	#print federatedListMysql
	#mysql_source='mysql_poc_source'


	#print federatedListMysql
	federatedListMysql=[sourceFederatedDBName]
	#listTableFromDB=loadTablesFromDB(sourceFederatedDBName)
	#print listTableFromDB
	#listTableFromDB=['t_lead']
	print "No. of rows purged";
	for table in TableList:
		if table not in MasterTables:
			#print table;
        		conn = MySQLdb.connect(host=SourceMysqlHostAddress, user=SourceMysqlUser, passwd=SourceMysqlPass,db=mysql_source);
			cur  =conn.cursor();
			#procedure_call="call purge_table('"+table+"','"+mysql_source+"','"+db_name+"')"
			#print procedure_call
			#cur.execute(procedure_call);

			#cnt_qry="select count(1) from "+mysql_source+"."+table
			#cur.execute(cnt_qry);
			#pre_count=cur.fetchone();
			
			args=(table,mysql_source,sourceFederatedDBName)
			#print args
			#print table,mysql_source,sourceFederatedDBName

                        #procedure_call="call purge_table('"+table+"','"+mysql_source+"','"+sourceFederatedDBName+"')"
                        #print procedure_call
                        #cur.execute(procedure_call);
			#result=cur.fetchone();

			procedure_call=cur.callproc('purge_table',args)
			result=cur.fetchone();
			#while result is not None:
			#	print(result[0])
				# close the communication with the PostgreSQL database server
				#cur.close()
			#print cur.stored_results();
			count = str(result[0])
			print table+" = "+ str(result[0])
			
			cur.close();
			conn.commit();
			conn.close();
	
			loc_conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
        		loc_cur = loc_conn.cursor()
                        statement2=("insert into "+mysqlConfigDb+".purge_details(wf_id, dbname, table_name, purged_count, executed_date) values('%s','%s','%s','%s','%s')") %(wf_id, sourceFederatedDBName,table,count,DateTime)
                        loc_cur.execute(statement2);

			loc_cur.close();
			loc_conn.commit();
			loc_conn.close();

                        #cnt_qry="select count(1) from "+mysql_source+"."+table
                        #cur.execute(cnt_qry);
                        #post_count=cur.fetchone();
                        #statement3=("update "+mysqlConfigDb+".purge_details set purge_count_after="+str(post_count[0])+" where table_name='"+table+"' and dbname='"+sourceFederatedDBName+"'")
                        #loc_cur.execute(statement3);
			#    print(result.fetchall())
			#loc_conn.commit()				
	#Drop DB from Source
	src_conn = MySQLdb.connect(host=SourceMysqlHostAddress, user=SourceMysqlUser, passwd=SourceMysqlPass);
	src_cur = src_conn.cursor()
	drop_qry1="drop database "+sourceFederatedDBName
	print "\n\nDropping database "+ sourceFederatedDBName
#----------------------------------------------------------------------
	src_cur.execute(drop_qry1);
#----------------------------------------------------------------------
	src_cur.close();	
	src_conn.close();

	loc_conn = MySQLdb.connect(host=LocalMysqlHostAddress, user=LocalMysqlUser, passwd=LocalMysqlPass);
	loc_cur = loc_conn.cursor()
        select_database = "select pre_archival_db_name from socio_config_db.pre_archival_db_details where source_federated_db_name = '"+sourceFederatedDBName+"'"
        loc_cur.execute(select_database);
        sourceArchivedDBName = loc_cur.fetchone()[0];
	print "\nDropping database "+sourceArchivedDBName 
	drop_qry2="drop database "+sourceArchivedDBName
#----------------------------------------------------------------------
	loc_cur.execute(drop_qry2);
#----------------------------------------------------------------------
	loc_cur.close();
	loc_conn.close();
	
        updateEntryOfDBFromPreArchivalDBDetails();								
	print ""
	print "Purging from Source completed successfully" 
	#print sourceFederatedDBListFromTable
	#print federatedListMysql
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Mysql Connection1 not found"
        raise SystemExit;

#------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------Property file loading class -------------------------------------------------------------
class IllegalArgumentException(Exception):

    def __init__(self, lineno, msg):
        self.lineno = lineno
        self.msg = msg

    def __str__(self):
        s='Exception at line number %d => %s' % (self.lineno, self.msg)
        return s
                 
class Properties(object):
    """ A Python replacement for java.util.Properties """
    
    def __init__(self, props=None):

        self._props = {}
        self._origprops = {}

        self._keymap = {}
        
        self.othercharre = re.compile(r'(?<!\\)(\s*\=)|(?<!\\)(\s*\:)')
        self.othercharre2 = re.compile(r'(\s*\=)|(\s*\:)')
        self.bspacere = re.compile(r'\\(?!\s$)')
        
    def __str__(self):
        s='{'
        for key,value in self._props.items():
            s = ''.join((s,key,'=',value,', '))

        s=''.join((s[:-2],'}'))
        return s

    def __parse(self, lines):
        """ Parse a list of lines and create
        an internal property dictionary """
        lineno=0
        i = iter(lines)

        for line in i:
            lineno += 1
            line = line.strip()
            if not line: continue
            if line[0] == '#': continue
            escaped=False
            sepidx = -1
            flag = 0
            m = self.othercharre.search(line)
            if m:
                first, last = m.span()
                start, end = 0, first
                flag = 1
                wspacere = re.compile(r'(?<![\\\=\:])(\s)')        
            else:
                if self.othercharre2.search(line):
                    wspacere = re.compile(r'(?<![\\])(\s)')        
                start, end = 0, len(line)
                
            m2 = wspacere.search(line, start, end)
            if m2:
                first, last = m2.span()
                sepidx = first
            elif m:
                first, last = m.span()
                sepidx = last - 1
                
                
            while line[-1] == '\\':
                nextline = i.next()
                nextline = nextline.strip()
                lineno += 1
                line = line[:-1] + nextline

            if sepidx != -1:
                key, value = line[:sepidx], line[sepidx+1:]
            else:
                key,value = line,''

            self.processPair(key, value)
            
    def processPair(self, key, value):
        """ Process a (key, value) pair """

        oldkey = key
        oldvalue = value
        
        keyparts = self.bspacere.split(key)

        strippable = False
        lastpart = keyparts[-1]

        if lastpart.find('\\ ') != -1:
            keyparts[-1] = lastpart.replace('\\','')

        elif lastpart and lastpart[-1] == ' ':
            strippable = True

        key = ''.join(keyparts)
        if strippable:
            key = key.strip()
            oldkey = oldkey.strip()
        
        oldvalue = self.unescape(oldvalue)
        value = self.unescape(value)
        
        self._props[key] = value.strip()

        if self._keymap.has_key(key):
            oldkey = self._keymap.get(key)
            self._origprops[oldkey] = oldvalue.strip()
        else:
            self._origprops[oldkey] = oldvalue.strip()
            self._keymap[key] = oldkey
        
    def escape(self, value):

        newvalue = value.replace(':','\:')
        newvalue = newvalue.replace('=','\=')

        return newvalue

    def unescape(self, value):

        newvalue = value.replace('\:',':')
        newvalue = newvalue.replace('\=','=')

        return newvalue    
        
    def load(self, stream):
        """ Load properties from an open file stream """
        
        if type(stream) is not file:
            raise TypeError,'Argument should be a file object!'
        if stream.mode != 'r':
            raise ValueError,'Stream should be opened in read-only mode!'

        try:
            lines = stream.readlines()
            self.__parse(lines)
        except IOError, e:
            raise

    def getProperty(self, key):
        """ Return a property for the given key """
        
        return self._props.get(key,'')

    def setProperty(self, key, value):
        """ Set the property for the given key """

        if type(key) is str and type(value) is str:
            self.processPair(key, value)
        else:
            raise TypeError,'both key and value should be strings!'

    def propertyNames(self):
        """ Return an iterator over all the keys of the property
        dictionary, i.e the names of the properties """

        return self._props.keys()

    def list(self, out=sys.stdout):
        """ Prints a listing of the properties to the
        stream 'out' which defaults to the standard output """

        out.write('-- listing properties --\n')
        for key,value in self._props.items():
            out.write(''.join((key,'=',value,'\n')))

    def store(self, out, header=""):
        """ Write the properties list to the stream 'out' along
        with the optional 'header' """

        if out.mode[0] != 'w':
            raise ValueError,'Steam should be opened in write mode!'

        try:
            out.write(''.join(('#',header,'\n')))
            tstamp = time.strftime('%a %b %d %H:%M:%S %Z %Y', time.localtime())
            out.write(''.join(('#',tstamp,'\n')))
            for prop, val in self._origprops.items():
                out.write(''.join((prop,'=',self.escape(val),'\n')))
                
            out.close()
        except IOError, e:
            raise

    def getPropertyDict(self):
        return self._props

    def __getitem__(self, name):
        """ To support direct dictionary like access """

        return self.getProperty(name)

    def __setitem__(self, name, value):
        """ To support direct dictionary like access """

        self.setProperty(name, value)
        
    def __getattr__(self, name):
        """ For attributes not found in self, redirect
        to the properties dictionary """

        try:
            return self.__dict__[name]
        except KeyError:
            if hasattr(self._props,name):
                return getattr(self._props, name)
#----------------------------------------------------------------------------------------------------------------------------------

#--------------------------------:: Start loadPreArchivedData ::----------------------------------------------------------
def createStoredProcedures():
    try:
        qry="mysql --user="+SourceMysqlUser+" --password="+SourceMysqlPass+" -h "+SourceMysqlHostAddress+" "+mysql_source+" < create_purging_procedures.sql" 
	os.system(qry)
    except Exception as error:
        traceback.print_exc()
        print "ERROR: Stored Procedure not executed."
        raise SystemExit;
#------------------------------------------------------------------------------------------------------------------------------
#--------------------------------:: Start loadPreArchivedData ::----------------------------------------------------------
def generatePostPurgingReport():
    generate_report_command = "java -jar startworkflow.jar "+propertiesFileName+' R6 '+wf_id;
    print "generate_report_command ::",generate_report_command;    
    ls_proc = subprocess.Popen([generate_report_command], shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE);
    ls_lines = ls_proc.stdout.readlines()
    ls_errors = ls_proc.stderr.readlines()

    for line in ls_errors:
        print line;

    for line in ls_lines:
        print line;


#------------------------------------------------------------------------------------------------------------------------------
#----------------MAIN EXECUTION START------------------------------------------------------------------------------------------
try:
    propertiesFileName = sys.argv[1];
    #propertiesFileName = '/home/adityak/job.properties';
    importParameter = Properties();
    importParameter.load(open(propertiesFileName));
    
    ######################## :: Script Comman Line Arguments for standalone run :: #########################
    #### :: Mysql Connection Parameter :: ####
    LocalMysqlHostAddress  = importParameter['LocalMysqlHostAddress'];
    LocalMysqlUser         = importParameter['LocalMysqlUser'];
    LocalMysqlPass         = importParameter['LocalMysqlPass'];
    
    #### :: Mysql Connection Parameter :: ####
    mysql_source             = importParameter['MysqldatabaseName'];
    SourceMysqlHostAddress   = importParameter['MysqlHostAddress'];
    SOurceMysqlHostPortNumber= importParameter['MysqlHostPortNumber'];
    SourceMysqlUser          = importParameter['MysqldatabaseUserName'];
    SourceMysqlPass          = importParameter['MysqldatabasePassword'];
    PreArchivalTableNameList = importParameter['PreArchivalTableNameList'];
    PostPurgingReportJar     = importParameter['PostPurgingReportJar']; 
    #print"LocalMysqlHostAddress ::",LocalMysqlHostAddress 
except:
    print"Please kindly provide the job.property file path as an Argument to script...\n";
    sys.exit();

"""
######################## :: Script Arguments for standalone run :: #########################
(mysql_source)  = ('mysql_poc_source')
#### :: Mysql Connection Parameter :: ####
(LocalMysqlHostAddress,LocalMysqlUser,LocalMysqlPass) = ("10.94.191.203","root","password")
#### :: Mysql Connection Parameter :: ####
(SourceMysqlHostAddress,SourceMysqlUser,SourceMysqlPass) = ("10.94.191.202","root","password")
SourceMysqlHostPortNumber ="3306"
##################### :: Archival Criteria parameter ::############################

PreArchivalTableNameList="t_user,t_orgname,t_user_org_rel,t_brand_profiles,t_circle,t_survey_questions,t_tags_new,t_source,t_workbasket,t_workflow_status,t_survey_question_answers,t_role,t_surveys,t_response_types,t_survey_respondent_types,t_survey_profile_rel,t_external_data_reporting,t_workflow_dtls,t_lead,t_user_notes,t_lead_social_accts,t_survey_responses,t_respondents,t_sch_messages,t_survey_respid_rel,t_sch_mess_accts,t_tagged_messages,t_workflow_tat_dtls,t_message_tag_dtls,t_srid_dtls,t_sentiment_changed"

"""

#------------------------:: Master table list to skip purging ::----------------------------------------------------------------
MasterTables='t_user,t_orgname,t_user_org_rel,t_brand_profiles,t_tags_new,t_workbasket,t_role,t_response_types,t_source,t_circle,t_surveys,t_survey_profile_rel,t_survey_questions,t_survey_question_answers,t_external_data_reporting,t_survey_respondent_types,t_workflow_status'

mysqlConfigDb      ='socio_config_db'
TableList          = PreArchivalTableNameList.split(',');
MasterTables       = MasterTables.split(',');


#TableList          =['t_lead']

listPreArchivedDB=[]
listFederatedDBFromMysql=[]

sourceFederatedDBName=''


try:

	#listPreArchivedDB=loadPreArchivedDBList();
	createStoredProcedures();

	ensureMysqlTableCreation();

	listFederatedDBFromMysql=loadFederatedDB();
	
	getUserInput();

	#loadTablesFromDB()
	purgeDataFromSource();

        generatePostPurgingReport();

except Exception as e:
        traceback.print_exc()
        print e;
        print "ERROR: Connection error in main function"

#------------------------------------------------------------------------------------------------------------------------------
